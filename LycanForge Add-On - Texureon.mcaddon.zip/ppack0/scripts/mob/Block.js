import {system, world} from "@minecraft/server";

import * as util from "../util";
import * as debug from "../debug_functions";
import * as abilities from "../data/abilities";

const block_roster = {};

world.afterEvents.entityLoad.subscribe(e => {
	const entity = e.entity;
	try {
		if (entity.matches({families: ["ljw_ww_block"]}))
			init_block(entity);
	}
	catch(err) {};
});

world.afterEvents.entitySpawn.subscribe(e => {
	const entity = e.entity;
	const cause = e.cause;
	
	try {
		if (entity.matches({families: ["ljw_ww_block"]}))
			init_block(entity);
	}
	catch(err) {};
});

async function startup_block_init() {
	try {
		const block_list = util.getEntities("all", {families: [ "ljw_ww_block" ]});
		for (const block of block_list) {
			if (block_roster[block.id] == null)
				init_block(block);
		}
	}
	catch(err) {
		debug.error(`${err} - Could not initialize block.`);
		try {
			block.remove();
		}
		catch(err) {
			debug.error(`${err} - Could not remove block.`);
		}
	}
}

async function init_block(entity) {
	const block_instance = new Block(entity);
}

class Block {
	block;
	player;
	tickInstance;
	
	constructor(item) {
		debug.info(`New Block! ${item.id}`);
		
		this.block = item;
		
		const playerID = item.getDynamicProperty("ljw_ww:player_id");
		let shouldLoad = true;
		try {
			const player = world.getEntity(playerID);
			if (player != null) {
				if (player.getDynamicProperty("ljw_ww:wolf_vision_block_id") != this.block.id) {
					shouldLoad = false;
				}
				this.player = player;
			}
			else {
				shouldLoad = false;
			}
		}
		catch(err) {
			shouldLoad = false;
		}
		
		if (shouldLoad) {
			block_roster[item.id] = this;
			this.tickInstance = system.runInterval(() => {this.tick();});
		}
		else {
			this.stop();
		}
		
		system.runTimeout(() => {if ((this.block != null) && this.block.isValid()) this.block.playAnimation("animation.ljw_ww.block.activate", {controller: "controller.animation.ljw_ww.block", nextState: "animation.ljw_ww.block.activate", players: [`${this.player.nameTag}`], stopExpression: "0"});}, 5);
	}
	
	tick() {
		try {
			if (!this.player.isValid()) {
				this.stop();
				return;
			}
				
			if (this.player.dimension != this.block.dimension) {
				this.stop();
				return;
			}
			
			const form = this.player.getDynamicProperty(`ljw_ww:form`) ?? "normal";
			if (form != "wolf") {
				this.stop();
				return;
			}
			
			const darknessEffectTest = this.player.getEffect("darkness");
			if (darknessEffectTest != null) {
				this.stop();
				return;
			}
			
			const nightVisionEffectTest = this.player.getEffect("night_vision");
			if (nightVisionEffectTest != null) {
				this.stop();
				return;
			}
			
			const berserkVisionEnabled = world.getDynamicProperty("ljw_ww:setting_enable_berserk_vision") ?? true;
			const berserkTime = berserkVisionEnabled ? (this.player.getDynamicProperty("ljw_ww:berserk_time") ?? 0) : 0;
			const nightVisionLevel = this.player.getDynamicProperty(`ljw_ww:werewolf_night_vision_setting`) ?? 0;
			
			this.block.setProperty("ljw_ww:berserk_time", berserkTime / abilities.berserkerRageDuration);
			if ((nightVisionLevel != 1) && (berserkTime == 0)) {
				this.stop();
				return;
			}
			
			const rotation = this.player.getRotation();
			const pitch = rotation.x;
			const yaw = rotation.y;

			// Convert yaw to radians for trigonometric calculations
			const offset = 15;
			const yawRad = (yaw + offset) * (Math.PI / 180);
			
			// Calculate the position one block behind the player
			// To go "behind" the player, we use the opposite direction of their yaw
			const offsetX = Math.sin(yawRad) * 0; // Negative to go opposite the facing direction
			const offsetZ = -Math.cos(yawRad) * 0;
			
			// Calculate the target position (one block behind)
			const targetLocation = {
				x: this.player.location.x + offsetX,
				y: this.player.location.y + 1.65,
				z: this.player.location.z + offsetZ
			};
			
			this.block.teleport(targetLocation);
		}
		catch(err) {
			debug.warn(`Block tick error: ${err}`);
			this.stop();
		}
	}
	
	stop() {
		try {
			if (this.tickInstance)
				system.clearRun(this.tickInstance);
			
			this.block.remove();
		}
		catch(err) {
			debug.error(`Block remove error: ${err}`);
		}
	}
}

system.run(startup_block_init);