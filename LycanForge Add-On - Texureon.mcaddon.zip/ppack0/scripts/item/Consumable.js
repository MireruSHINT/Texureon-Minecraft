import { system, world, ItemStack } from "@minecraft/server";
import * as debug from "../debug_functions";
import * as util from "../util";

world.afterEvents.itemCompleteUse.subscribe(e => {
	// Will decrement by 1 every 5 ticks
	const itemStack = e.itemStack;
	const player = e.source;
	if (itemStack.hasTag("ljw_ww:werewolf_state_modifier")) {
		try {
			if (itemStack.typeId == "ljw_ww:suspicious_stew_transform") {
				increase_transform_time(player, 5 * 10);
			}
			else if (itemStack.typeId == "ljw_ww:suspicious_stew_untransform") {
				increase_transform_block_time(player, 5 * 10);
			}
		}
		catch(err) {
			debug.error(`Werewolf state modifier error: ${err}`);
		}
	}
});

function increase_transform_time(player, amount) {
	try {
		// Will decrement by 1 every 5 ticks
		const isWerewolf = player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
		
		if (isWerewolf) {
			const transformExtendTime = player.getDynamicProperty("ljw_ww:transformation_extend_time") ?? 0;
			player.setDynamicProperty("ljw_ww:transformation_inhibit_time", 0);
			player.setDynamicProperty("ljw_ww:transformation_extend_time", transformExtendTime + amount);
		}
		else {
			player.addEffect("speed", 20 * 4);
			player.addEffect("jump_boost", 20 * 4);
			player.addEffect("night_vision", 20 * 10);
		}
	}
	catch(err) {
		debug.error(`Transform time increase error: ${err}`);
	}
}

function increase_transform_block_time(player, amount) {
	try {
		// Will decrement by 1 every 5 ticks
		const isWerewolf = player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
		
		if (isWerewolf) {
			const transformInhibitTime = player.getDynamicProperty("ljw_ww:transformation_inhibit_time") ?? 0;
			player.setDynamicProperty("ljw_ww:transformation_extend_time", 0);
			player.setDynamicProperty("ljw_ww:transformation_inhibit_time", transformInhibitTime + amount);
		}
		else {
			player.removeEffect("speed");
			player.removeEffect("jump_boost");
			player.removeEffect("night_vision");
		}
	}
	catch(err) {
		debug.error(`Transform time decrease error: ${err}`);
	}
}