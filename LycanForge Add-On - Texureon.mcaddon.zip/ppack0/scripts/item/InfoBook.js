import {system, world, ItemStack} from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import * as debug from "../debug_functions";

const divider = "_".repeat(32);

world.afterEvents.playerSpawn.subscribe(e => {
	const player = e.player;
		
	if (!(player.getDynamicProperty("ljw_ww:info_book_init") ?? false))
	{
		give_info(player);
		player.setDynamicProperty("ljw_ww:info_book_init", true);
	}
});

function give_info(player) {
	player.dimension.spawnItem(new ItemStack("ljw_ww:info_book"), player.location);
}

system.afterEvents.scriptEventReceive.subscribe(e => {
    const entity = e.sourceEntity;
    if (e.id == "ljw_ww:info_book") {
		if (e.message == "get")
		{
			if (entity == null)
			{
				debug.error("'ljw_ww:info_book get' must be run from an entity.");
				return;
			}
			
			give_info(entity);
		}
		else if (e.message == "reset")
		{
			for (const player of world.getPlayers())
				player.setDynamicProperty("ljw_ww:info_book_init", false);
		}
    }
});

world.beforeEvents.worldInitialize.subscribe(e => {
    e.itemComponentRegistry.registerCustomComponent("ljw_ww:info_book", {onUse: open_guide});
});

function open_guide(e) {
	const player = e.source != null ? e.source : e;
	if (player == null)
		return;
	
	try {
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ww.info_book.main.title", with: { rawtext: [ { translate: "item.ljw_ww:info_book", with: { rawtext: [ { text: "\n" }]} }]} });
		guideDialog.body({ translate: "ljw_ww.info_book.main.body", with: { rawtext: [ { text: "\n" }, { text: divider }]} });
		
		guideDialog.button({ translate: "ljw_ww.info_book.main.button.getting_started", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/info_book");
		guideDialog.button({ translate: "ljw_ww.info_book.main.button.settings", with: { rawtext: [ { text: "\n" }]} }, "textures/ui/automation_glyph_color");
		guideDialog.button({ translate: "ljw_ww.info_book.main.button.about", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/info_book");
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				open_docs(player);
			else if (response.selection == 1)
				open_settings(player);
			else if (response.selection == 2)
				open_credits(player);
		});
	}
	catch (err) {
		debug.error(`Info Book error: ${err}`)
	}
}

function open_docs(player) {
	try {
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ww.info_book.docs.title", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.body({ translate: "ljw_ww.info_book.docs.body", with: { rawtext: [ { text: "\n" }, { text: divider }]} });
		
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.quickstart", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/info_book");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.lycan_forge", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/blocks/lycan_forge_front");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.moonglow_sprig", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/moonglow_sprig");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.werewolf_emblems", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/emblem_lv0");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.cure_werewolf", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/emblem_disable");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.customizing_appearance", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/ability_coat_echo");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.understanding_transformations", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/ability_form_shift");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.werewolf_regeneration", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/ability_pack_mender");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.wolfband", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/wolfband");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.lunar_lantern", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/lunar_lantern");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.lunarburn", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/lunarburn_lantern");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.werewolf_tips", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ww/items/info_book");
		guideDialog.button({ translate: "ljw_ww.info_book.docs.button.technical_info", with: { rawtext: [ { text: "\n" }]} }, "textures/ui/automation_glyph_color");
		
		guideDialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					explain_topic(player, "quickstart", "item.ljw_ww:moonglow_sprig", "item.dye.white.name", "item.ljw_ww:werewolf_emblem_lv0", "item.ljw_ww:lycan_forge", "tile.cobblestone.name");
				else if (response.selection == 1)
					explain_topic(player, "lycan_forge", "item.ljw_ww:lycan_forge");
				else if (response.selection == 2)
					explain_topic(player, "moonglow_sprig", "item.ljw_ww:moonglow_sprig", "item.dye.white.name");
				else if (response.selection == 3)
					explain_topic(player, "werewolf_emblems", "item.ljw_ww:werewolf_emblem_lv0", "tile.cobblestone.name", "item.ljw_ww:moonglow_sprig");
				else if (response.selection == 4)
					explain_topic(player, "cure_werewolf", "item.ljw_ww:werewolf_emblem_lv0", "tile.cobblestone.name", "item.ljw_ww:moonglow_sprig", "item.glow_berries.name");
				else if (response.selection == 5)
					explain_topic(player, "customizing_appearance", "item.ljw_ww:lycan_forge", "item.ljw_ww:ability_coat_echo", "item.ljw_ww:moonglow_sprig");
				else if (response.selection == 6)
					explain_topic(player, "understanding_transformations", divider, "enchantment.curse.binding", "item.ljw_ww:lycan_forge");
				else if (response.selection == 7)
					explain_topic(player, "werewolf_regeneration", "enchantment.curse.binding", "item.ljw_ww:lycan_forge");
				else if (response.selection == 8)
					explain_topic(player, "wolfband", "item.ljw_ww:wolfband");
				else if (response.selection == 9)
					explain_topic(player, "lunar_lantern", "item.ljw_ww:lunar_lantern", "item.ljw_ww:moonglow_sprig");
				else if (response.selection == 10)
					explain_topic(player, "lunarburn");
				else if (response.selection == 11)
					explain_topic(player, "werewolf_tips", "enchantment.curse.binding", "item.ljw_ww:lycan_forge");
				else if (response.selection == 12)
					explain_topic(player, "technical_info", divider);
			}
			else
				open_guide(player);
		});
	}
	catch (err) {
		debug.error(`Docs error: ${err}`)
	}
}

function explain_topic(player, topic, translateA = "", translateB = "", translateC = "", translateD = "", translateE = "") {
	try {
		const guideDialog = new ActionFormData();
		guideDialog.title({ translate: `ljw_ww.info_book.docs.button.${topic}` });
		guideDialog.body({ translate: `ljw_ww.info_book.docs.${topic}.body`, with: { rawtext: [ { text: "\n" }, { translate: translateA }, { translate: translateB }, { translate: translateC }, { translate: translateD }, { translate: translateE }]} });
		
		guideDialog.button({ translate: "ljw_ww.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ww.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					open_docs(player);
			}
			else
				open_docs(player);
		});
	}
	catch (err) {
		debug.error(`Explanation Error: ${err}`)
	}
}

function open_settings(player) {
	try {
		const guideDialog = new ModalFormData();
		
		guideDialog.title({ translate: "ljw_ww.info_book.settings.title", with: { rawtext: [ { text: "\n" }]} });
		const customAnimationsEnabled = world.getDynamicProperty("ljw_ww:setting_enable_custom_anims") ?? true;
		const berserkVisionEnabled = world.getDynamicProperty("ljw_ww:setting_enable_berserk_vision") ?? true;
		
		guideDialog.toggle({ translate: `ljw_ww.info_book.settings.custom_animations.toggle`, with: { rawtext: [ { text: "\n" }]} }, customAnimationsEnabled);
		guideDialog.toggle({ translate: `ljw_ww.info_book.settings.berserk_vision.toggle`, with: { rawtext: [ { text: "\n" }]} }, berserkVisionEnabled);
		
		guideDialog.show(player).then((formData) => {
			if (formData.canceled || formData == undefined)
				open_guide(player);
			else {
				world.setDynamicProperty("ljw_ww:setting_enable_custom_anims", formData.formValues[0]);
				world.setDynamicProperty("ljw_ww:setting_enable_berserk_vision", formData.formValues[1]);
			}
		}).catch((err) => {
			debug.error(`Info Book error: ${err}`);
			open_guide(player);
		});
	}
	catch (err) {
		debug.error(`Info Book error: ${err}`)
	}
}

function open_credits(player) {
	try {
		const guideDialog = new ActionFormData();
		const version = "1.0.0";
		
		guideDialog.title({ translate: "ljw_ww.info_book.about.title", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.body({ translate: `ljw_ww.info_book.about.body`, with: { rawtext: [ { text: "\n" }, { text: version }]} });
		
		guideDialog.button({ translate: "ljw_ww.info_book.about.button.changelog", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ww.info_book.about.button.special_thanks", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ww.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ww.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				open_changelog(player);
			else if (response.selection == 1)
				open_thanks(player);
			else if (response.selection == 2)
				open_guide(player);
			else if (response.selection == 3)
				return;
		});
	}
	catch (err) {
		debug.error(`Credits error: ${err}`)
	}
}

function open_changelog(player) {
	try {
		const guideDialog = new ActionFormData();
		let content = "";
		
		content += `§lLycanForge v1.0.0§r\n- Initial Release!`
		content += `\n\n`
		
		guideDialog.title({ translate: "ljw_ww.info_book.changelog.title", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.body(content.replaceAll("- ", "§s§l>§r "));
		
		guideDialog.button({ translate: "ljw_ww.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ww.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				open_guide(player);
			else if (response.selection == 1)
				return;
		});
	}
	catch (err) {
		debug.error(`Changelog error: ${err}`)
	}
}

const thanksList = [
	{ name: "ambel", social: "", role: "Audio"},
	{ name: "Beez", social: "", role: "Art"},
	{ name: "EZOEY", social: "", role: "Art"},
	{ name: "King Creeper Studios", social: "", role: "Testing"},
	{ name: "Milo", social: "", role: "Art"},
	{ name: "Pixerkk", social: "", role: "Art"},
	{ name: "TheWyrm", social: "", role: "Art"},
	{ name: "vemigvan", social: "", role: "Art"},
	{ name: "XG", social: "", role: "Audio"},
	{ name: "Yallay", social: "", role: "Art"}
]

const roleIconMappings = {
	"Art": "textures/ui/color_picker",
	"Audio": "textures/items/record_cat",
	"Testing": "textures/ui/controller_glyph_color"
}

function open_thanks(player) {
	try {
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ww.info_book.special_thanks.title", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.body({ translate: "ljw_ww.info_book.special_thanks.body", with: { rawtext: [ { text: "\n" }]} });
		
		for (const entry of thanksList) {
			guideDialog.button(`${entry.name}`, roleIconMappings[entry.role]);
		}
		
		guideDialog.button({ translate: "ljw_ww.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ww.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == thanksList.length)
				open_credits(player);
			else if (response.selection == thanksList.length + 1)
				return;
			else
				open_thanks(player);
		});
	}
	catch (err) {
		debug.error(`Thanks List error: ${err}`)
	}
}

function explain_thanks(player, num) {
	try {
		const guideDialog = new ActionFormData();
		let content = "";
		
		content += ``;
		
		for (const entry of thanksList[num].contributions) {
			content += `- ${entry}`;
			content += `\n`;
		}
		
		guideDialog.title(thanksList[num].name);
		guideDialog.body({ translate: `ljw_ww.info_book.credit`, with: { rawtext: [ { text: "\n" }, { text: thanksList[num].social }, { text: thanksList[num].role }, { text: content }]} });
		
		guideDialog.button({ translate: "ljw_ww.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ww.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				open_thanks(player);
			else if (response.selection == 3)
				return;
		});
	}
	catch (err) {
		debug.error(`Thanks error: ${err}`)
	}
}