import { system, world } from "@minecraft/server";
import * as debug from "../debug_functions";
import * as abilities from "../data/abilities";
import * as util from "../util";

world.beforeEvents.worldInitialize.subscribe(e => {
	e.itemComponentRegistry.registerCustomComponent('ljw_ww:werewolf_trim_pack', { onCompleteUse: use_werewolf_trim });
	e.itemComponentRegistry.registerCustomComponent('ljw_ww:werewolf_trim_material', { onCompleteUse: use_werewolf_trim });
});

function use_werewolf_trim(e) {
	const player = e.source;
	const itemStack = e.itemStack;
	
	if (player == null) {
		return;
	}
	if (player.typeId != "minecraft:player") {
		return;
	}
	
	try {
		test_unlock(player, itemStack);
	}
	catch(err) {
		debug.error(`Werewolf Trim Pack error: ${err}`);
	}
}

function test_unlock(player, itemStack) {
	const typeId = itemStack.typeId;
	if (itemStack.hasTag("ljw_ww:werewolf_trim_pack")) {
		const type = typeId.replace("ljw_ww:werewolf_trim_pack_", "");
		const trimListString = player.getDynamicProperty("ljw_ww:trim_pack_list") ?? "";
		const trimList = trimListString.split(";");
		const unlocked = trimList.includes(type);
		
		if (!unlocked) {
			player.setDynamicProperty(`ljw_ww:trim_pack_list`, `${type};${trimListString}`);
			player.sendMessage({ translate: "ljw_ww.message.trim_pack_activated", with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:lycan_forge" }]} });
			util.decrement_item(player, typeId);
			debug.info(`${player.nameTag} used a trim pack: ${type}`);
		}
		else {
			player.sendMessage({ translate: "ljw_ww.message.trim_pack_already_used", with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:lycan_forge" }]} });
		}
	}
	else if (itemStack.hasTag("ljw_ww:werewolf_trim_material")) {
		const type = typeId.replace("ljw_ww:werewolf_trim_material_", "");
		const trimListString = player.getDynamicProperty("ljw_ww:trim_material_list") ?? "";
		const trimList = trimListString.split(";");
		const unlocked = trimList.includes(type);
		
		if (!unlocked) {
			player.setDynamicProperty(`ljw_ww:trim_material_list`, `${type};${trimListString}`);
			player.sendMessage({ translate: "ljw_ww.message.trim_material_activated", with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:lycan_forge" }]} });
			util.decrement_item(player, typeId);
			debug.info(`${player.nameTag} used a trim material: ${type}`);
		}
		else {
			player.sendMessage({ translate: "ljw_ww.message.trim_material_already_used", with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:lycan_forge" }]} });
		}
	}
}