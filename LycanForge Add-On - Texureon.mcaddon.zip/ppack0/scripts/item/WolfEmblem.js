import { system, world, ItemStack } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import * as debug from "../debug_functions";
import * as abilities from "../data/abilities";
import * as util from "../util";

world.beforeEvents.worldInitialize.subscribe(e => {
	e.itemComponentRegistry.registerCustomComponent('ljw_ww:werewolf_emblem', { onUse: use_werewolf_emblem });
});

function use_werewolf_emblem(e) {
	const player = e.source;
	const itemStack = e.itemStack;
	
	if (player == null) {
		return;
	}
	if (player.typeId != "minecraft:player") {
		return;
	}
	
	try {
		if (itemStack.typeId == "ljw_ww:werewolf_emblem_lv0") {
			test_upgrade(player, 0);
		}
		else if (itemStack.typeId == "ljw_ww:werewolf_emblem_lv1") {
			test_upgrade(player, 1);
		}
		else if (itemStack.typeId == "ljw_ww:werewolf_emblem_lv2") {
			test_upgrade(player, 2);
		}
		else if (itemStack.typeId == "ljw_ww:werewolf_emblem_lv3") {
			test_upgrade(player, 3);
		}
		else if (itemStack.typeId == "ljw_ww:werewolf_emblem_lv4") {
			test_upgrade(player, 4);
		}
		else if (itemStack.typeId == "ljw_ww:werewolf_emblem_disable") {
			test_deactivate(player);
		}
		else {
			test_unlock(player, itemStack.typeId);
		}
	}
	catch(err) {
		debug.error(`Werewolf Emblem error: ${err}`);
	}
}

function activate_werewolf_form(player) {
	player.setDynamicProperty("ljw_ww:werewolf_form_enabled", true);
	player.setDynamicProperty("ljw_ww:has_had_werewolf_form", true);
	player.setDynamicProperty("ljw_ww:preferred_form", "werewolf");
	player.sendMessage({ translate: "ljw_ww.message.werewolf_form_acquired", with: { rawtext: [ { text: "\n" }]} });
}

function deactivate_werewolf_form(player) {
	player.setDynamicProperty("ljw_ww:werewolf_form_enabled", false);
	player.sendMessage({ translate: "ljw_ww.message.werewolf_form_removed", with: { rawtext: [ { text: "\n" }]} });
	util.decrement_item(player, `ljw_ww:werewolf_emblem_disable`);
}

function test_deactivate(player) {
	try {
		const isWerewolf = player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
		if (isWerewolf) {
			deactivate_werewolf_form(player);
		}
	}
	catch(err) {
		debug.error(`Werewolf deactivate error: ${err}`);
	}
}

function test_upgrade(player, level) {
	try {
		const isWerewolf = player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
		const hasBeenWerewolf = player.getDynamicProperty("ljw_ww:has_had_werewolf_form") ?? false;
		const wolfLevel = player.getDynamicProperty("ljw_ww:werewolf_level") ?? 0;
		const itemUseable = !isWerewolf || (wolfLevel < level);
		if (itemUseable) {
			if (!isWerewolf) {
				const guideDialog = new ActionFormData();
				guideDialog.title({ translate: `ljw_ww.general.window.confirm.title` });
				
				if (!hasBeenWerewolf)
					guideDialog.body({ translate: `ljw_ww.gain_werewolf_form_confirm`, with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:werewolf_emblem_lv0" }, { translate: "item.ljw_ww:info_book" }]} });
				else
					guideDialog.body({ translate: `ljw_ww.reactivate_werewolf_form_confirm`, with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:werewolf_emblem_lv0" }, { translate: "item.ljw_ww:info_book" }]} });
				
				guideDialog.button({ translate: "ljw_ww.general.button.confirm", with: { rawtext: [ { text: "\n" }]} });
				guideDialog.button({ translate: "ljw_ww.general.button.back", with: { rawtext: [ { text: "\n" }]} });
				
				guideDialog.show(player).then((response) => {
					if (response?.selection != null) {
						if (response.selection == 0) {
							util.decrement_item(player, `ljw_ww:werewolf_emblem_lv${level}`);
							activate_werewolf_form(player);
							if (wolfLevel < level)
								level_up_werewolf_form(player, level);
						}
						else if (response.selection == 1) {
						}
						
					}
				});
			}
			else if (wolfLevel < level) {
				util.decrement_item(player, `ljw_ww:werewolf_emblem_lv${level}`);
				level_up_werewolf_form(player, level);
			}
		}
		else {
			player.sendMessage({ translate: "ljw_ww.message.werewolf_form_already_leveled_up", with: { rawtext: [ { text: "\n" }, { text: wolfLevel.toString() }]} });
		}
	}
	catch(err) {
		debug.error(`Emblem use error: ${err}`);
	}
}

function test_unlock(player, typeId) {
	try {
		const type = typeId.replace("ljw_ww:werewolf_emblem_", "");
		const isWerewolf = player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
		const hasBeenWerewolf = player.getDynamicProperty("ljw_ww:has_had_werewolf_form") ?? false;
		const unlocked = player.getDynamicProperty(`ljw_ww:acquired_emblem_${type}`) ?? false;
		const itemUseable = !isWerewolf || !unlocked;
		if (itemUseable) {
			if (!isWerewolf) {
				const guideDialog = new ActionFormData();
				guideDialog.title({ translate: `ljw_ww.general.window.confirm.title` });
				
				if (!hasBeenWerewolf)
					guideDialog.body({ translate: `ljw_ww.gain_werewolf_form_confirm`, with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:werewolf_emblem_lv0" }, { translate: "item.ljw_ww:info_book" }]} });
				else
					guideDialog.body({ translate: `ljw_ww.reactivate_werewolf_form_confirm`, with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:werewolf_emblem_lv0" }, { translate: "item.ljw_ww:info_book" }]} });
				
				guideDialog.button({ translate: "ljw_ww.general.button.confirm", with: { rawtext: [ { text: "\n" }]} });
				guideDialog.button({ translate: "ljw_ww.general.button.back", with: { rawtext: [ { text: "\n" }]} });
				
				guideDialog.show(player).then((response) => {
					if (response?.selection != null) {
						if (response.selection == 0) {
							util.decrement_item(player, `ljw_ww:werewolf_emblem_${type}`);
							activate_werewolf_form(player);
							if (!unlocked)
								use_special_emblem(player, type);
						}
						else if (response.selection == 1) {
						}
						
					}
				});
			}
			else if (!unlocked) {
				util.decrement_item(player, `ljw_ww:werewolf_emblem_${type}`);
				use_special_emblem(player, type);
			}
		}
		else {
			player.sendMessage({ translate: "ljw_ww.message.special_emblem_already_used", with: { rawtext: [ { text: "\n" }]} });
		}
	}
	catch(err) {
		debug.error(`Special Emblem Error: ${err}`);
	}
}

function use_special_emblem(player, type) {
	try {
		if (type == "ultimate") {
			player.runCommandAsync("scriptevent ljw_ww:ability_unlock_cheat");
			player.runCommandAsync("scriptevent ljw_ww:appearance_unlock_cheat");
			player.playSound("random.levelup", {pitch: 1.2 - Math.random() * 0.3});
			player.sendMessage({ translate: "ljw_ww.message.ultimate_emblem_activated", with: { rawtext: [ { text: "\n" }]} });
		}
		else if (type == "reset") {
			player.runCommandAsync("scriptevent ljw_ww:reset_progress");
			player.playSound("random.orb", {pitch: 1.2 - Math.random() * 0.3});
			player.sendMessage({ translate: "ljw_ww.message.reset_emblem_activated", with: { rawtext: [ { text: "\n" }]} });
		}
		else {
			player.setDynamicProperty(`ljw_ww:acquired_emblem_${type}`, true);
			player.sendMessage({ translate: "ljw_ww.message.special_emblem_activated", with: { rawtext: [ { text: "\n" }]} });
			player.playSound("random.orb", {pitch: 1.2 - Math.random() * 0.3});
			debug.info(`${player.nameTag} used a special emblem: ${type}`);
		}
	}
	catch(err) {
		debug.error(`Special Emblem Use Error: ${err}`);
	}
}

function level_up_werewolf_form(player, level) {
	try {
		player.setDynamicProperty("ljw_ww:werewolf_level", level);
		player.playSound("random.orb", {pitch: 1.2 - Math.random() * 0.3});
		player.sendMessage({ translate: "ljw_ww.message.leveled_up_werewolf_form", with: { rawtext: [ { text: "\n" }, { text: level.toString() }]} });
	}
	catch(err) {
		debug.error(`Level Up Error: ${err}`);
	}
}