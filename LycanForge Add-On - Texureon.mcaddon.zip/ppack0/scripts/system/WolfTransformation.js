import { system, world, ItemStack, MolangVariableMap, InputPermissionCategory, EntityTypes } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import * as util from "../util"
import * as debug from "../debug_functions";
import * as abilities from "../data/abilities";
import * as appearance from "../data/appearance";
import * as enchants from "../data/enchants";
import * as data from "../data/general";
const allEntityTypes = EntityTypes.getAll();
const markerFilled = "|";
const markerEmpty = ".";
	
world.beforeEvents.worldInitialize.subscribe(e => {
    e.itemComponentRegistry.registerCustomComponent("ljw_ww:block_durability_damage", {onBeforeDurabilityDamage: durability_damage_event});
	e.itemComponentRegistry.registerCustomComponent("ljw_ww:ability", {onUse: use_ability, onBeforeDurabilityDamage: durability_damage_event});
});

world.beforeEvents.playerBreakBlock.subscribe(e => {
    const itemStack = e.itemStack;
	const player = e.player;
	const block = e.block;
	
	if (itemStack == null)
		return;
	
	if (itemStack.typeId == "ljw_ww:ability_mining_claw") {
		try {
			if (player.getDynamicProperty("ljw_ww:form") != "wolf") {
				system.runTimeout(() => {player.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_requires_werewolf", with: { rawtext: [ { text: "\n" }]} });}, 1);
				e.cancel = true;
				return;
			}
			
			const gamemode = player.getGameMode();
			const abilityLevel = player.getDynamicProperty(`ljw_ww:werewolf_mining_claw_setting`) ?? 0;
			if ((gamemode != "creative") && (abilityLevel < 1)) {
				player.sendMessage({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
				e.cancel = true;
				return;
			}
			
			const miningStamina = player.getDynamicProperty("ljw_ww:mining_stamina") ?? abilities.miningStaminaMax;
			if (miningStamina <= 0) {
				player.sendMessage({ translate: "ljw_ww.message.out_of_mining_stamina", with: { rawtext: [ { text: "\n" }]} });
				e.cancel = true;
				return;
			}
			
			const dayTime = world.getTimeOfDay();
			const isNight = (dayTime >= 13000) && (dayTime < 23000);
			
			if (abilityLevel == 2 && isNight && (player.dimension.id == "minecraft:overworld")) {
				player.setDynamicProperty("ljw_ww:mining_stamina", miningStamina - 0.5);
				system.run(() => {player.addEffect("haste", 40, {showParticles: false, amplifier: 1})});
			}
			else {
				player.setDynamicProperty("ljw_ww:mining_stamina", miningStamina - 1);
			}
		}
		catch(err) {
			debug.error(`Mining Claw Error: ${err}`);
		}
	}
});

world.afterEvents.playerBreakBlock.subscribe(e => {
    const itemStack = e.itemStackAfterBreak;
    const itemStackBefore = e.itemStackBeforeBreak;
	const player = e.player;
	const block = e.block;
	
	if (itemStack == null)
		return;
	
	if (itemStack.typeId != "ljw_ww:ability_mining_claw") {
		test_werewolf_durbility_loss(player, itemStack, itemStackBefore);
	}
});

world.afterEvents.playerSpawn.subscribe((e) => {
    const player = e.player;
    const isInitialSpawn = e.initialSpawn;
    
    if (isInitialSpawn) {
        system.run(() => scent_tracker_cleanup(player));
    }
});

let playerList = [];
function updatePlayerList() {
	playerList = world.getPlayers();
}
system.run(updatePlayerList);
system.runInterval(updatePlayerList, 20);

function durability_damage_event(e) {
    // Cancel vanilla damage event
	e.durabilityDamage = 0;
}

function display_mining_stamina(player) {
    const miningStamina = player.getDynamicProperty("ljw_ww:mining_stamina") ?? abilities.miningStaminaMax;
	const staminaBar = `${markerFilled.repeat(util.clamp(Math.ceil(10 * miningStamina/abilities.miningStaminaMax),0,10))}${markerEmpty.repeat(util.clamp(10 - Math.ceil(10 * miningStamina/abilities.miningStaminaMax),0,10))}`;
	system.run(() => {player.onScreenDisplay.setActionBar({ translate: "ljw_ww.action_bar.mining_claw_stamina", with: { rawtext: [ { text: "\n" }, { text: staminaBar }]} });});
}

function use_ability(e) {
	const source = e.source;
	const itemStack = e.itemStack;
	if (source == null)
		return;
	
	if ((itemStack.typeId != "ljw_ww:ability_form_shift") && source.getDynamicProperty("ljw_ww:form") != "wolf") {
		source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_requires_werewolf", with: { rawtext: [ { text: "\n" }]} });
		return;
	}
	
	try {
		const durabilityComponent = itemStack.getComponent('durability');
		const damage = durabilityComponent.damage;
		const gamemode = source.getGameMode();
		const abilityId = itemStack.typeId.replace("ljw_ww:ability_", "");

		if ((gamemode != "creative") && ((100 - damage) < (abilities.list[abilityId].chargeMinimum ?? 100))) {
			source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_recharging", with: { rawtext: [ { text: "\n" }]} });
			return;
		}
		
		const equipment = source.getComponent("equippable")?.getEquipment("Legs");
		let isPerformingAbility = equipment?.hasTag("ljw_ww:werewolf_ability_anim");
		
		if (!isPerformingAbility) {
			if (source.typeId == "minecraft:player") {
				source.setDynamicProperty(`ljw_ww:ability_use_time_${abilityId}`, Date.now());
			}
			
			if (itemStack.typeId == "ljw_ww:ability_form_shift") {
				const isWerewolf = source.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
				
				if(isWerewolf) {
					const preferredForm = source.getDynamicProperty("ljw_ww:preferred_form") ?? "werewolf";
					
					if (preferredForm == "werewolf") {
						source.setDynamicProperty("ljw_ww:preferred_form", "human");
						source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.shift_to_human", with: { rawtext: [ { text: "\n" }]} });
						if (full_moon_check(source)) {
							source.sendMessage({ translate: "ljw_ww.message.shift_blocked_by_moonlight", with: { rawtext: [ { text: "\n" }]} });
						}
					}
					else if (preferredForm == "human") {
						source.setDynamicProperty("ljw_ww:preferred_form", "werewolf");
						source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.shift_to_werewolf", with: { rawtext: [ { text: "\n" }]} });
					}
				}
				else {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.shift_requires_werewolf", with: { rawtext: [ { text: "\n" }]} });
				}
				return;
			}
			else if (itemStack.typeId == "ljw_ww:ability_wide_claw") {
				// Can't be used with a shield equipped
				const offhand = source.getComponent("equippable").getEquipment("Offhand");
				if (offhand?.typeId == "minecraft:shield") {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_blocked_by_shield", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_wide_claw_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				set_legs_equipment(source, "swipe");
				source.playAnimation("animation.ljw_ww.werewolf_form.attack.2", {controller: "controller.animation.ljw_ww.attack_runtime"});
				system.runTimeout(() => {werewolf_sound(source, "attack");}, 7);
				system.runTimeout(() => {swipe_attack(source);}, 10);
				system.runTimeout(() => {set_legs_equipment(source);}, 19);
			}
			else if (itemStack.typeId == "ljw_ww:ability_wild_claw") {
				// Can't be used with a shield equipped
				const offhand = source.getComponent("equippable").getEquipment("Offhand");
				if (offhand?.typeId == "minecraft:shield") {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_blocked_by_shield", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_wild_claw_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				source.playAnimation("animation.ljw_ww.werewolf_form.attack.3", {controller: "controller.animation.ljw_ww.attack_runtime"});
				system.runTimeout(() => {werewolf_sound(source, "attack");}, 4);
				system.runTimeout(() => {wild_attack(source, -1);}, 7);
				system.runTimeout(() => {werewolf_sound(source, "attack");}, 12);
				system.runTimeout(() => {wild_attack(source, 1);}, 17);
				system.runTimeout(() => {set_legs_equipment(source);}, 19);
			}
			else if (itemStack.typeId == "ljw_ww:ability_wind_claw") {
				// Can't be used with a shield equipped
				const offhand = source.getComponent("equippable").getEquipment("Offhand");
				if (offhand?.typeId == "minecraft:shield") {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_blocked_by_shield", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_wind_claw_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				set_legs_equipment(source, "swipe");
				source.playAnimation("animation.ljw_ww.werewolf_form.attack.2", {controller: "controller.animation.ljw_ww.attack_runtime"});
				system.runTimeout(() => {werewolf_sound(source, "attack");}, 7);
				system.runTimeout(() => {breeze_attack(source);}, 10);
				system.runTimeout(() => {set_legs_equipment(source);}, 19);
			}
			else if (itemStack.typeId == "ljw_ww:ability_tree_cutter") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_tree_cutter_setting`) ?? 0;
	
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				set_legs_equipment(source, "swipe");
				source.playAnimation("animation.ljw_ww.werewolf_form.attack.2", {controller: "controller.animation.ljw_ww.attack_runtime"});
				system.runTimeout(() => {werewolf_sound(source, "attack");}, 7);
				system.runTimeout(() => {tree_cutter(source);}, 10);
				system.runTimeout(() => {set_legs_equipment(source);}, 19);
			}
			else if (itemStack.typeId == "ljw_ww:ability_mining_claw") {
				const gamemode = source.getGameMode();
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_mining_claw_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					e.cancel = true;
					return;
				}
				
				source.sendMessage({ translate: "ljw_ww.message.mining_claw.hint", with: { rawtext: [ { text: "\n" }]} });
			}
			else if (itemStack.typeId == "ljw_ww:ability_lunar_leap") {
				lunar_leap(source);
			}
			else if (itemStack.typeId == "ljw_ww:ability_lycan_guard") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_lycan_guard_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				lycan_guard(source);
			}
			else if (itemStack.typeId == "ljw_ww:ability_howl") {
				set_legs_equipment(source, "howl");
				source.setDynamicProperty("ljw_ww:movement_was_enabled", source.inputPermissions.isPermissionCategoryEnabled(InputPermissionCategory.Movement));
				source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, false);
				system.runTimeout(() => {set_legs_equipment(source);}, 49);
				system.runTimeout(() => {source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, source.getDynamicProperty("ljw_ww:movement_was_enabled") ?? true);}, 49);
			}
			else if (itemStack.typeId == "ljw_ww:ability_pack_mender") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_pack_mender_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				const entityCheck = source.getEntitiesFromViewDirection({closest: 1});
				if (entityCheck[0] != null) {
					if (entityCheck[0].entity.getEffect("wither")) {
						source.sendMessage({ translate: "ljw_ww.message.pack_mender.blocked_by_wither", with: { rawtext: [ { text: "\n" }]} });
						return;
					}
					
					if ((source.getDynamicProperty("ljw_ww:regeneration_charge") ?? 1.0) <= abilities.packMenderCost) {
						source.sendMessage({ translate: "ljw_ww.message.pack_mender.blocked_by_low_charge", with: { rawtext: [ { text: "\n" }]} });
						return;
					}
					
					set_legs_equipment(source, "heal");
					source.setDynamicProperty("ljw_ww:movement_was_enabled", source.inputPermissions.isPermissionCategoryEnabled(InputPermissionCategory.Movement));
					source.playAnimation("animation.ljw_ww.werewolf_form.attack", {controller: "controller.animation.ljw_ww.attack_runtime"});
					source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, false);
					system.runTimeout(() => {heal_howl(source, entityCheck[0].entity);}, 5);
					system.runTimeout(() => {set_legs_equipment(source);}, 20);
					system.runTimeout(() => {source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, source.getDynamicProperty("ljw_ww:movement_was_enabled") ?? true);}, 20);
					
				}
			}
			else if (itemStack.typeId == "ljw_ww:ability_enfeebling_howl") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_enfeebling_howl_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				set_legs_equipment(source, "howl_enfeebling");
				source.setDynamicProperty("ljw_ww:movement_was_enabled", source.inputPermissions.isPermissionCategoryEnabled(InputPermissionCategory.Movement));
				source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, false);
				system.runTimeout(() => {enfeebling_howl(source);}, 17);
				system.runTimeout(() => {set_legs_equipment(source);}, 49);
				system.runTimeout(() => {source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, source.getDynamicProperty("ljw_ww:movement_was_enabled") ?? true);}, 49);
			}
			else if (itemStack.typeId == "ljw_ww:ability_confusing_howl") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_confusing_howl_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				set_legs_equipment(source, "howl_discordant");
				source.setDynamicProperty("ljw_ww:movement_was_enabled", source.inputPermissions.isPermissionCategoryEnabled(InputPermissionCategory.Movement));
				source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, false);
				system.runTimeout(() => {confusing_howl(source);}, 17);
				system.runTimeout(() => {set_legs_equipment(source);}, 49);
				system.runTimeout(() => {source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, source.getDynamicProperty("ljw_ww:movement_was_enabled") ?? true);}, 49);
			}
			else if (itemStack.typeId == "ljw_ww:ability_pack_call") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_pack_call_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				set_legs_equipment(source, "howl");
				source.setDynamicProperty("ljw_ww:movement_was_enabled", source.inputPermissions.isPermissionCategoryEnabled(InputPermissionCategory.Movement));
				source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, false);
				system.runTimeout(() => {pack_call(source);}, 17);
				system.runTimeout(() => {set_legs_equipment(source);}, 49);
				system.runTimeout(() => {source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, source.getDynamicProperty("ljw_ww:movement_was_enabled") ?? true);}, 49);
			}
			else if (itemStack.typeId == "ljw_ww:ability_battle_howl") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_battle_howl_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				set_legs_equipment(source, "howl_battle");
				source.setDynamicProperty("ljw_ww:movement_was_enabled", source.inputPermissions.isPermissionCategoryEnabled(InputPermissionCategory.Movement));
				source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, false);
				system.runTimeout(() => {battle_howl(source);}, 17);
				system.runTimeout(() => {set_legs_equipment(source);}, 49);
				system.runTimeout(() => {source.inputPermissions.setPermissionCategory(InputPermissionCategory.Movement, source.getDynamicProperty("ljw_ww:movement_was_enabled") ?? true);}, 49);
			}
			else if (itemStack.typeId == "ljw_ww:ability_berserker_rage") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_berserker_rage_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				activate_berserk(source);
			}
			else if (itemStack.typeId == "ljw_ww:ability_coat_echo") {
				const checkData = check_biome_variant(source);
				const variant = checkData.variant;
				let morphList = source.getDynamicProperty("ljw_ww:werewolf_form_list");
				let testValue = "";
				
				if ((variant == 0) && checkData.taigaDetected) {
					testValue = "000;"
				}
				else {
					testValue += `${variant * 100};`;
				}
				
				if (morphList.indexOf(testValue) == -1) {
					morphList += testValue;
					source.playSound("random.orb", {pitch: 1.2 - Math.random() * 0.3});
					source.dimension.spawnParticle("ljw_ww:detect_wave_1", source.location);
					source.dimension.spawnParticle("ljw_ww:detect_wave_2", source.location);
					source.setDynamicProperty("ljw_ww:werewolf_form_list", morphList);
				}
				
				appearance.open_change_coat_menu(source, true);
				return;
			}
			else if (itemStack.typeId == "ljw_ww:ability_starfang_strike") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_starfang_strike_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				//set_legs_equipment(source, "swipe");
				//source.playAnimation("animation.ljw_ww.werewolf_form.attack.2", {controller: "controller.animation.ljw_ww.attack_runtime"});
				//system.runTimeout(() => {werewolf_sound(source, "attack");}, 7);
				starfang_strike(source);
				//system.runTimeout(() => {set_legs_equipment(source);}, 19);
			}
			else if (itemStack.typeId == "ljw_ww:ability_scent_tracker") {
				const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_scent_tracker_setting`) ?? 0;
				if ((gamemode != "creative") && (abilityLevel < 1)) {
					source.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.ability_not_learned", with: { rawtext: [ { text: "\n" }]} });
					return;
				}
				
				scent_tracker(source);
				return;
			}
		}
	}
	catch(err) {
		debug.error(`Ability error: ${err}`);
		if ((source != null) && source.isValid()) {
			set_legs_equipment(source);
		}
	}
}

function swipe_attack(source) {
    try {
		const sharpClawsLevel = source.getDynamicProperty(`ljw_ww:werewolf_sharp_claws_setting`) ?? 0;
		const particleConfig = new MolangVariableMap();
		particleConfig.setFloat("r", 0.20);
		particleConfig.setFloat("g", 0.50);
		particleConfig.setFloat("b", 0.90);
		particleConfig.setFloat("initial_spin", -1 * source.getRotation().y);
		source.dimension.spawnParticle("ljw_ww:horizontal_slash", {x: source.location.x, y: source.location.y + 1.1, z: source.location.z}, particleConfig);
		
		const boundsA = util.local_space_coords(source, {x: -1.5, y: 0, z: 0});
		const boundsB = util.local_space_coords(source, {x: 1.5, y: 1, z: 3});
		const boxDimensions = {x: boundsB.x - boundsA.x, y: boundsB.y - boundsA.y, z: boundsB.z - boundsA.z }
		
		//source.dimension.spawnParticle("minecraft:redstone_torch_dust_particle", boundsA);
		//source.dimension.spawnParticle("minecraft:redstone_torch_dust_particle", boundsB);
		
		// Create an entity query to find entities within the space
		const queryOptions = {
			location: boundsA,
			volume: boxDimensions,
			excludeFamilies: [ "inanimate" ],
			excludeTypes: ["minecraft:item"]
		};

		// Get entities within the bounding box
		const entities = source.dimension.getEntities(queryOptions);
		
		source.runCommand(`/fill ~-1 ~ ~-1 ~1 ~ ~1 air [] replace fire`);

        for (const entity of entities) {
			try {
				if (entity == source) {
					continue;
				}
				entity.applyDamage(strength_amplify_test(source, 3 + sharpClawsLevel), { cause: "entityAttack", damagingEntity: source });
				entity.applyKnockback( source.getViewDirection().x, source.getViewDirection().z, 2 * util.clamp(Math.abs(source.getViewDirection().x) + Math.abs(source.getViewDirection().z), -1, 1), Math.min(2 * source.getViewDirection().y, 1.5) );
			}
			catch(err) {
				debug.warn(`Swipe Attack Effect Error: ${err}`);
			}
        }
    }
	catch (err) {
        debug.error(`Swipe attack error: ${err}`);
    }
}

function wild_attack(source, rotationBit = 1) {
    try {
        const sharpClawsLevel = source.getDynamicProperty(`ljw_ww:werewolf_sharp_claws_setting`) ?? 0;
		const particleConfig = new MolangVariableMap();
		particleConfig.setFloat("r", 0.58);
		particleConfig.setFloat("g", 0.53);
		particleConfig.setFloat("b", 0.17);
		const rotation = source.getRotation().y * Math.PI / 180;
		const xValue = Math.cos(rotation);
		const zValue = Math.sin(rotation);
		particleConfig.setFloat("x_dir", xValue);
		particleConfig.setFloat("z_dir", zValue);
		particleConfig.setFloat("rotation_bit", rotationBit);
		source.dimension.spawnParticle("ljw_ww:diagonal_slash", {x: source.location.x, y: source.location.y + 1.1, z: source.location.z}, particleConfig);
		
		const boundsA = util.local_space_coords(source, {x: -1, y: 0, z: 0});
		const boundsB = util.local_space_coords(source, {x: 1, y: 1, z: 1.5});
		const boxDimensions = {x: boundsB.x - boundsA.x, y: boundsB.y - boundsA.y, z: boundsB.z - boundsA.z }
		
		// Create an entity query to find entities within the space
		const queryOptions = {
			location: boundsA,
			volume: boxDimensions,
			excludeFamilies: [ "inanimate" ],
			excludeTypes: ["minecraft:item"]
		};

		// Get entities within the bounding box
		const entities = source.dimension.getEntities(queryOptions);
		
		for (const entity of entities) {
			if (entity == source) {
				continue;
			}
			entity.applyDamage(strength_amplify_test(source, 1 + sharpClawsLevel), { cause: "entityAttack", damagingEntity: source });
        }
    }
	catch (err) {
        debug.error(`Wild attack error: ${err}`);
    }
}

function breeze_attack(source) {
    try {
        const sharpClawsLevel = source.getDynamicProperty(`ljw_ww:werewolf_sharp_claws_setting`) ?? 0;
		const particleConfig = new MolangVariableMap();
		particleConfig.setFloat("r", 0.52);
		particleConfig.setFloat("g", 0.53);
		particleConfig.setFloat("b", 0.82);
		particleConfig.setFloat("initial_spin", -1 * source.getRotation().y);
		source.dimension.spawnParticle("ljw_ww:horizontal_slash", {x: source.location.x, y: source.location.y + 1.1, z: source.location.z}, particleConfig);
		const particleConfigB = new MolangVariableMap();
		const viewDir = util.view_rot_to_dir(source.getRotation());
		particleConfigB.setFloat("dir_x", viewDir.x);
		particleConfigB.setFloat("dir_y", viewDir.y);
		particleConfigB.setFloat("dir_z", viewDir.z);
		source.dimension.spawnParticle("ljw_ww:wind_gust_1", source.location, particleConfigB);
		source.dimension.spawnParticle("ljw_ww:wind_gust_2", source.location, particleConfigB);
		
		const boundsA = util.local_space_coords(source, {x: -2, y: 0, z: 0});
		const boundsB = util.local_space_coords(source, {x: 2, y: 1, z: 5});
		const boxDimensions = {x: boundsB.x - boundsA.x, y: boundsB.y - boundsA.y, z: boundsB.z - boundsA.z }
		
		// Create an entity query to find entities within the space
		const queryOptions = {
			location: boundsA,
			volume: boxDimensions,
			excludeFamilies: [ "inanimate" ]
		};

		// Get entities within the bounding box
		const entities = source.dimension.getEntities(queryOptions);
		
		for (const entity of entities) {
			if (entity == source) {
				continue;
			}
			entity.extinguishFire(true);
            entity.applyKnockback( source.getViewDirection().x, source.getViewDirection().z, 4 * util.clamp(Math.abs(source.getViewDirection().x) + Math.abs(source.getViewDirection().z), -1, 1), 0.45 + Math.min(2 * source.getViewDirection().y, 1.5) );
        }
		
		source.runCommand(`/fill ^-3 ^-1 ^1 ^3 ^5 ^5 air [] replace fire`);
		source.runCommand(`/fill ~-1 ~ ~-1 ~1 ~ ~1 air [] replace fire`);
    }
	catch (err) {
        debug.error(`Swipe attack error: ${err}`);
    }
}

function lunar_leap(source) {
	try {
		const blockRaycast = source.getBlockFromViewDirection({ maxDistance: 64 });
		const knockbackStrength = 0.37;
		const verticalKnockbackStrength = 0.2;
		const customAnimsEnabled = world.getDynamicProperty("ljw_ww:setting_enable_custom_anims") ?? true;
		
		if (blockRaycast) {
			const blockLoc = blockRaycast.block.location;
			const currentPos = source.location;
			const direction = {
				x: blockLoc.x + 0.5 - currentPos.x,
				y: blockLoc.y + 0.5 - currentPos.y,
				z: blockLoc.z + 0.5 - currentPos.z
			};

			const leapDistance = Math.sqrt(direction.x * direction.x + direction.y * direction.y + direction.z * direction.z);
			source.applyKnockback( direction.x, direction.z, knockbackStrength * leapDistance, util.clamp(direction.y * verticalKnockbackStrength, 1, 2.5) );
			werewolf_sound(source, "leap");
			source.setDynamicProperty(`ljw_ww:fallproof`, true);
			
			const particleConfig = new MolangVariableMap();
			particleConfig.setFloat("r", 0.54);
			particleConfig.setFloat("g", 0.20);
			particleConfig.setFloat("b", 0.71);
			particleConfig.setFloat("size_modifier", 0.5);
			source.dimension.spawnParticle("ljw_ww:scan_wave_1", source.location, particleConfig);
			source.dimension.spawnParticle("ljw_ww:scan_wave_2", source.location, particleConfig);
			
			if (customAnimsEnabled)
				set_legs_equipment(source, "glide");
		}
	}
	catch(err) {
		debug.error(`Lunar Leap Error: ${err}`);
	}
}

function lycan_guard(source) {
	try {
		const targetId = source.getDynamicProperty("ljw_ww:lycan_guard_target");
		
		if (targetId) {
			source.setDynamicProperty("ljw_ww:lycan_guard_target");
			if (source.typeId == "minecraft:player")
				source.sendMessage({ translate: "ljw_ww.message.lycan_guard.link_removed", with: { rawtext: [ { text: "\n" }]} });
		}
		else {
			// Find target
			const entitiesInView = source.getEntitiesFromViewDirection({ maxDistance: 20, excludeFamilies: ["inanimate"] });

			if (entitiesInView[0]?.entity != null) {
				const entity = entitiesInView[0].entity;
				entity.setDynamicProperty("ljw_ww:lycan_guard_werewolf", source.id);
				source.setDynamicProperty("ljw_ww:lycan_guard_target", entity.id);
				source.setDynamicProperty("ljw_ww:lycan_guard_start_time", Date.now());
				entity.dimension.spawnParticle("ljw_ww:lycan_guard_b", {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
				if (source.typeId == "minecraft:player") {
					let name = { text: "" };
					if (entity.nameTag.length > 0) {
						name = { text: entity.nameTag };
					}
					else {
						name = { translate: `entity.${entity.typeId.replace("minecraft:", "")}.name`};
					}
					source.sendMessage({ translate: "ljw_ww.message.lycan_guard.link_successful", with: { rawtext: [ { text: "\n" }, name]} });
				}
			}
		}
	}
	catch(err) {
		debug.error(`Lycan Guard Error: ${err}`);
	}
}
function lycan_guard_validate(source) {
	try {
		const targetId = source.getDynamicProperty("ljw_ww:lycan_guard_target");
		
		if (targetId) {
			let linkValid = true;
			
			const target = world.getEntity(targetId);
			if (!target || !target.isValid()) {
				linkValid = false;
			}
			else {
				if (util.distance3D(target.location, source.location) > abilities.lycanGuardDistanceLimit) {
					linkValid = false;
					if (source.typeId == "minecraft:player")
						source.sendMessage({ translate: "ljw_ww.message.lycan_guard.link_removed.distance", with: { rawtext: [ { text: "\n" }]} });
				}
				else if ((Date.now() - (source.getDynamicProperty("ljw_ww:lycan_guard_start_time") ?? 0)) > abilities.lycanGuardTimeLimitMS) {
					linkValid = false;
					if (source.typeId == "minecraft:player")
						source.sendMessage({ translate: "ljw_ww.message.lycan_guard.link_removed.time", with: { rawtext: [ { text: "\n" }]} });
				}
			}
			
			if (!linkValid) {
				source.setDynamicProperty("ljw_ww:lycan_guard_target");
			}
		}
	}
	catch(err) {
		debug.error(`Protect Validate Error: ${err}`);
		source.setDynamicProperty("ljw_ww:lycan_guard_target");
	}
}

function strength_amplify_test(player, damageAmount) {
	try {
		const strengthEffect = player.getEffect("strength");
		
		if (strengthEffect != null) {
			const amplifier = strengthEffect.amplifier + 1;
			return damageAmount * (1.3 ** amplifier) + (((1.3 ** amplifier) - 1) / 0.3);
		}
		else
			return damageAmount
	}
	catch(err) {
		debug.warn(`Strength amplify error: ${err}`);
		return damageAmount;
	}
}

const starfangStrikePairs = [];
function starfang_strike(source) {
	const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_starfang_strike_setting`) ?? 1;
	const particleConfigA = new MolangVariableMap();
	particleConfigA.setFloat("r", 0.50);
	particleConfigA.setFloat("g", 0.00);
	particleConfigA.setFloat("b", 0.50);
	const particleConfigB = new MolangVariableMap();
	particleConfigB.setFloat("r", 0.50);
	particleConfigB.setFloat("g", 0.00);
	particleConfigB.setFloat("b", 0.50);
	particleConfigB.setFloat("initial_spin", -1 * source.getRotation().y);
	const location = source.location; 
	const viewDirection = source.getViewDirection();
	
	// Find target
	const entitiesInView = source.getEntitiesFromViewDirection({
		maxDistance: abilities.starfangStrikeConfigs[abilityLevel - 1].dashDistance + 1,
		excludeFamilies: ["inanimate"],
		excludeTypes: ["minecraft:item"]
	});

	if (entitiesInView[0]?.entity != null) {
		// Visual effects (starry trail)
		system.runTimeout(() => { source.dimension.spawnParticle("ljw_ww:starfang_strike", { x: location.x, y: location.y + 1, z: location.z }, particleConfigA);}, 2);
		//system.runTimeout(() => { source.dimension.spawnParticle("ljw_ww:horizontal_slash", {x: source.location.x, y: source.location.y + 1.1, z: source.location.z}, particleConfigB);}, 5);

		const entity = entitiesInView[0].entity;
		const knockbackStrength = 0.37;
		const verticalKnockbackStrength = 0.2;
		const customAnimsEnabled = world.getDynamicProperty("ljw_ww:setting_enable_custom_anims") ?? true;
		
		const blockLoc = entity.location;
        const currentPos = source.location;
        const direction = {
            x: blockLoc.x + 0.5 - currentPos.x,
            y: blockLoc.y + 0.5 - currentPos.y,
            z: blockLoc.z + 0.5 - currentPos.z
        };
		
        const leapDistance = Math.sqrt(direction.x * direction.x + direction.y * direction.y + direction.z * direction.z);
		source.applyKnockback( direction.x, direction.z, knockbackStrength * leapDistance, Math.min(Math.max(1, direction.y * verticalKnockbackStrength), 2) );
		starfangStrikePairs.push({source, target: entity});
		if (customAnimsEnabled)
			set_legs_equipment(source, "glide_power");
	}
	else {
		source.setDynamicProperty(`ljw_ww:ability_use_time_starfang_strike`);
	}
}
function starfang_strike_tick() {
	for (let i = 0; i < starfangStrikePairs.length; i += 1) {
		const source = starfangStrikePairs[i].source;
		const target = starfangStrikePairs[i].target;
		const abilityLevel = source.getDynamicProperty(`ljw_ww:werewolf_starfang_strike_setting`) ?? 1;
		let clearEntry = false;
		
		if (util.distance3D(source.location, target.location) < 8) {
			const isPlayer = target.matches({families: [ "player" ]});
			let minHP = 0;
			
			if (isPlayer) {
				const healthComponent = target.getComponent("health");
				const health = healthComponent.currentValue;
				if (health >= 8) {
					minHP = 5;
                }
				system.runTimeout(() => {try {target.applyDamage(Math.min(strength_amplify_test(source, abilities.starfangStrikeConfigs[abilityLevel - 1].damage), health - minHP), { cause: "entityAttack", damagingEntity: source });} catch(err) {debug.error(`Starfang Strike Damage Error: ${err}`)};}, 3);
            }
			else {
				system.runTimeout(() => {try {target.applyDamage(strength_amplify_test(source, abilities.starfangStrikeConfigs[abilityLevel - 1].damage), { cause: "entityAttack", damagingEntity: source });} catch(err) {debug.error(`Starfang Strike Damage Error: ${err}`)};}, 3);
			}
			clearEntry = true;
		}
		
		clearEntry = clearEntry || source.isOnGround;
		
		if (clearEntry) {
			starfangStrikePairs.splice(i ,1);
		}
	}
}
system.runInterval(starfang_strike_tick);

function tree_cutter(source) {
	const particleConfig = new MolangVariableMap();
	particleConfig.setFloat("r", 0.17);
	particleConfig.setFloat("g", 1.00);
	particleConfig.setFloat("b", 0.09);
	particleConfig.setFloat("initial_spin", -1 * source.getRotation().y);
	source.dimension.spawnParticle("ljw_ww:horizontal_slash", {x: source.location.x, y: source.location.y + 1.1, z: source.location.z}, particleConfig);
	cut_tree(source, source.getBlockFromViewDirection({maxDistance: 5})?.block);
}

function heal_howl(source, target) {
	const regenerationCharge = source.getDynamicProperty("ljw_ww:regeneration_charge") ?? 1.0;
	
	const particleConfig = new MolangVariableMap();
	particleConfig.setFloat("r", 0.17);
	particleConfig.setFloat("g", 1.00);
	particleConfig.setFloat("b", 0.09);
	source.dimension.spawnParticle("ljw_ww:scan_wave_1", source.location, particleConfig);
	source.dimension.spawnParticle("ljw_ww:scan_wave_2", source.location, particleConfig);
	
	system.runTimeout(() => {if (target != null) target.dimension.spawnParticle("ljw_ww:detect_wave_1", target.location, particleConfig);}, 5);
	system.runTimeout(() => {if (target != null) target.dimension.spawnParticle("ljw_ww:detect_wave_2", target.location, particleConfig);}, 5);
	
	const healthComponent = target.getComponent("health");
	healthComponent.setCurrentValue(Math.min(healthComponent.effectiveMax, healthComponent.currentValue + abilities.packMenderRestoreAmount));
	
	source.setDynamicProperty("ljw_ww:regeneration_charge", Math.max(0, regenerationCharge - abilities.packMenderCost));
}

function enfeebling_howl(source) {
	const nearby_list = source.dimension.getEntities({ location: source.location, maxDistance: 25, families: [ "monster" ] });
	
	const particleConfig = new MolangVariableMap();
	particleConfig.setFloat("r", 0.17);
	particleConfig.setFloat("g", 0.42);
	particleConfig.setFloat("b", 0.58);
	const particleLoc = {x: source.location.x, y: source.location.y + 2, z: source.location.z};
	source.dimension.spawnParticle("ljw_ww:scan_wave_1", particleLoc, particleConfig);
	source.dimension.spawnParticle("ljw_ww:scan_wave_2", particleLoc, particleConfig);
	
	for (const entity of nearby_list) { 
		try {
			entity.addEffect("slowness", 200, {amplifier: 3});
			entity.addEffect("weakness", 200, {amplifier: 3});
		}
		catch (err) {
			debug.error(`Enfeebling Howl error: ${err}`);
		}
	}
}
function confusing_howl(source) {
	const nearby_list = source.dimension.getEntities({ location: source.location, maxDistance: 25, families: [ "monster" ] });
	
	const particleConfig = new MolangVariableMap();
	particleConfig.setFloat("r", 0.58);
	particleConfig.setFloat("g", 0.53);
	particleConfig.setFloat("b", 0.17);
	const particleLoc = {x: source.location.x, y: source.location.y + 2, z: source.location.z};
	source.dimension.spawnParticle("ljw_ww:scan_wave_1", particleLoc, particleConfig);
	source.dimension.spawnParticle("ljw_ww:scan_wave_2", particleLoc, particleConfig);
	
	const success = (Math.random() <= 0.9);
	for (let i = 0; i < nearby_list.length; i += 1) { 
		try {
			const entity = nearby_list[i];
			if (success) {
				const target = nearby_list[Math.floor(Math.random() * nearby_list.length)];
				
				if (entity != target) {
					entity.applyDamage(0.001, {damagingEntity: target, cause: "entityAttack"});
				}
			}
			else {
				entity.addEffect("strength", 200, {amplifier: 1});
				entity.addEffect("speed", 200, {amplifier: 1});
			}
		}
		catch (err) {
			debug.error(`Confusing Howl error: ${err}`);
		}
	}
}
function battle_howl(source) {
	const horizontalStrength = 3.5 + (world.getDynamicProperty("ljw_ww:howl_force_modifier") ?? 0);
	const verticalStrength = 0.5;
	const nearby_list = source.dimension.getEntities({ location: source.location, maxDistance: 25, families: [ "monster" ] });
	
	const particleConfig = new MolangVariableMap();
	particleConfig.setFloat("r", 0.75);
	particleConfig.setFloat("g", 0.00);
	particleConfig.setFloat("b", 0.00);
	const particleLoc = {x: source.location.x, y: source.location.y + 2, z: source.location.z};
	source.dimension.spawnParticle("ljw_ww:scan_wave_1", particleLoc, particleConfig);
	source.dimension.spawnParticle("ljw_ww:scan_wave_2", particleLoc, particleConfig);
	
	for (const entity of nearby_list) { 
		try {
			 // Calculate direction vector from source to target
            const direction = {
                x: entity.location.x - source.location.x,
                y: entity.location.y - source.location.y,
                z: entity.location.z - source.location.z
            };

            // Calculate distance
            const distance = Math.sqrt(direction.x * direction.x + direction.y * direction.y + direction.z * direction.z);

            // Avoid division by zero
            if (distance === 0)
				continue;

            // Normalize direction vector
            const normalizedDirection = {
                x: direction.x / distance,
                z: direction.z / distance
            };

            // Create VectorXZ for horizontal knockback
            const knockbackVector = {
                x: normalizedDirection.x * horizontalStrength,
                z: normalizedDirection.z * horizontalStrength
            };

            // Apply knockback
            entity.applyKnockback(normalizedDirection.x, normalizedDirection.z, horizontalStrength, verticalStrength);
			entity.applyDamage(0.001, {damagingEntity: source, cause: "entityAttack"});
		}
		catch (err) {
			debug.error(`Battle Howl error: ${err}`);
		}
	}
}
function activate_berserk(source) {
	const berserkTime = source.getDynamicProperty("ljw_ww:berserk_time") ?? 0;
	const berserkTimeMax = abilities.berserkerRageDuration;
	source.setDynamicProperty("ljw_ww:berserk_time", berserkTimeMax);
	
	werewolf_sound(source, "angry");
	
	const particleConfig = new MolangVariableMap();
	particleConfig.setFloat("r", 1.00);
	particleConfig.setFloat("g", 0.15);
	particleConfig.setFloat("b", 0.15);
	source.dimension.spawnParticle("ljw_ww:detect_wave_1", source.location, particleConfig);
	source.dimension.spawnParticle("ljw_ww:detect_wave_2", source.location, particleConfig);
}

function pack_call(source) {
	const wolfList = source.dimension.getEntities({location: source.location, maxDistance: 20, families: [ "wolf" ], excludeFamilies: [ "ljw_ww:tameHowlExclude" ]});
	for (const wolf of wolfList) {
		const tameableComponent = wolf.getComponent("tameable");
		if (tameableComponent && !tameableComponent.isTamed) {
			tameableComponent.tame(source);
		}
	}
}

world.afterEvents.entityHurt.subscribe(e => {
	const entity = e.hurtEntity;
	const damage = e.damage;
	const cause = e.damageSource.cause;
	const source = e.damageSource.damagingEntity;
	
	try {
		if (!entity || !entity.isValid()) {
			return;
		}
		
		let protectingWerewolf = null;
		const protectingWerewolfId = entity.getDynamicProperty("ljw_ww:lycan_guard_werewolf");
		if (protectingWerewolfId) {
			const werewolf = world.getEntity(protectingWerewolfId);
			if (werewolf && werewolf.isValid()) {
				if (werewolf.getDynamicProperty("ljw_ww:form") == "wolf") {
					const protecting = werewolf.getDynamicProperty("ljw_ww:lycan_guard_target") == entity.id;
					if (protecting) {
						protectingWerewolf = werewolf;
					}
					else {
						entity.setDynamicProperty("ljw_ww:lycan_guard_werewolf");
					}
				}
				else {
					entity.setDynamicProperty("ljw_ww:lycan_guard_werewolf");
				}
			}
			else {
				entity.setDynamicProperty("ljw_ww:lycan_guard_werewolf");
			}
		}
		const shouldProtect = (protectingWerewolf != null) && (protectingWerewolf != source);
		
		const handEquipment = source?.getComponent("equippable")?.getEquipment("Mainhand");
		
		// Werewolves have damage modifiers applied
		if (entity.getDynamicProperty("ljw_ww:form") == "wolf") {
			werewolf_sound(entity, "hurt");
			const berserkTime = entity.getDynamicProperty("ljw_ww:berserk_time") ?? 0;
			const healthComponent = entity.getComponent("health");
			let modifier = 0;
			if (((entity.getDynamicProperty(`ljw_ww:werewolf_undercoat_setting`) ?? 0) >= 1) && (cause == "freezing"))
				modifier = damage;
			else if (["campfire", "fire", "fireTick", "magma", "soulCampfire", "lava"].includes(cause)) {
				const regenCharge = entity.getDynamicProperty("ljw_ww:regeneration_charge") ?? 1.0;
				entity.setDynamicProperty("ljw_ww:regeneration_charge", Math.min(regenCharge, Math.max(0.80, regenCharge - 0.02)));
				modifier = damage * -0.7;
			}
			else if (cause == "contact")
				modifier = damage * 0.2;
			else if (berserkTime > 0)
				modifier = damage * -2.5;
			
			if (shouldProtect) {
				protect(protectingWerewolf, entity, modifier);
			}
			else {
				healthComponent.setCurrentValue(Math.min(healthComponent.effectiveMax, healthComponent.currentValue + modifier));
			}
			
			// Track how much damage is done to a werewolf
			const damageScore = entity.getDynamicProperty("ljw_ww:damage_score") ?? 0;
			const damageScoreMultiplier = [ "maceSmash", "entityAttack" ].includes(cause) ? 0.3 : 0.2;
			entity.setDynamicProperty("ljw_ww:damage_score", util.clamp(damageScore + damage * damageScoreMultiplier, 0, 55));
		}
		else if (shouldProtect) {
			protect(protectingWerewolf, entity, damage);
		}
		
		// Track how much damage a werewolf does
		if (source != null) {
			if (source.getDynamicProperty("ljw_ww:form") == "wolf") {
				if (entity.isValid() && (handEquipment == null)) {
					const sharpClawsLevel = source.getDynamicProperty(`ljw_ww:werewolf_sharp_claws_setting`) ?? 0;
				
					entity.applyDamage(strength_amplify_test(source, 4 + sharpClawsLevel * 1.9), {damagingEntity: source, cause: "entityAttack"});
				}
				
				const damageScore = source.getDynamicProperty("ljw_ww:damage_score") ?? 0;
				const damageScoreMultiplier = [ "maceSmash", "entityAttack" ].includes(cause) ? 0.7 : 0.5;
				source.setDynamicProperty("ljw_ww:damage_score", util.clamp(damageScore + damage * damageScoreMultiplier, 0, 55));
			}
		}
	}
	catch(err) {
		debug.error(`Damage error: ${err}`);
	}
});

function protect(werewolf, target, damageAmount) {
	const werewolfHealthComponent = werewolf.getComponent("health");
	const targetHealthComponent = target.getComponent("health");
	const currentWerewolfHP = werewolfHealthComponent.currentValue;
	const currentTargetHP = targetHealthComponent.currentValue;
	
	// If entity has fallen, cancel.
	if (currentTargetHP <= 0) {
		werewolf.setDynamicProperty("ljw_ww:lycan_guard_target");
		if (werewolf.typeId == "minecraft:player")
			werewolf.sendMessage({ translate: "ljw_ww.message.lycan_guard.link_removed.fatal_hit", with: { rawtext: [ { text: "\n" }]} });
		return;
	}
	
	// Determine protection amount
	const protectionMax = currentWerewolfHP - 0.01;
	const protectionAmount = Math.min(damageAmount, protectionMax);
	const overloadAmount = Math.min(protectionMax - damageAmount, 0) * -1;
	
	// Apply Protection
	werewolf.dimension.spawnParticle("ljw_ww:lycan_guard_a", {x: werewolf.location.x, y: werewolf.location.y + 1, z: werewolf.location.z});
	werewolf.runCommand("damage @s 0");
	werewolfHealthComponent.setCurrentValue(Math.max(0.01, currentWerewolfHP - protectionAmount));
	targetHealthComponent.setCurrentValue(Math.min(targetHealthComponent.effectiveMax, targetHealthComponent.currentValue + protectionAmount));
	
	// If overflow occured, cancel bond
	if (overloadAmount > 0) {
		werewolf.setDynamicProperty("ljw_ww:lycan_guard_target");
		target.setDynamicProperty("ljw_ww:lycan_guard_werewolf");
		if (werewolf.typeId == "minecraft:player")
			werewolf.sendMessage({ translate: "ljw_ww.message.lycan_guard.link_removed.critical_hp", with: { rawtext: [ { text: "\n" }]} });
	}
}

world.afterEvents.entityDie.subscribe(e => {
    const target = e.deadEntity;
	try {
		if (target.getDynamicProperty("ljw_ww:form") == "wolf") {
			werewolf_sound(target, "death");
		}
	}
	catch(err) {
		// Ignore
	}
});

world.beforeEvents.effectAdd.subscribe(e => {
	const entity = e.entity;
	if (entity.getDynamicProperty("ljw_ww:form") == "wolf") {
		if ((e.effectType == "Slowness") && ((entity.getDynamicProperty(`ljw_ww:werewolf_undercoat_setting`) ?? 0) == 2)) {
			e.cancel = true;
		}
		else if (e.effectType == "Hunger") {
			e.cancel = true;
		}
	}
});

world.beforeEvents.playerInteractWithEntity.subscribe(e => {
	const player = e.player;
	const target = e.target;
	const itemStack = e.itemStack;
	
	try {
		if (player.getDynamicProperty("ljw_ww:form") == "wolf") {
			if (itemStack == null)
				return;
			
			if (itemStack.typeId == "ljw_ww:ability_coat_echo") {
				e.cancel = true;
				if (target.matches({families: [ "wolf" ]})) {
					appearance.test_new_variant(player, target);
				}
			}
		}
	}
	catch(err) {
		debug.error(`Coat Echo Error: ${err}`);
	}
});

system.afterEvents.scriptEventReceive.subscribe(e => {
    const entity = e.sourceEntity;
	if (e.id == "ljw_ww:test_store_inventory") {
		util.store_player_armor(entity);
    }
    else if (e.id == "ljw_ww:test_restore_inventory") {
		util.restore_player_armor(entity);
    }
    else if (e.id == "ljw_ww:test_place_item") {
		const playerInventoryContainer = entity.getComponent("inventory").container;
    }
    else if (e.id == "ljw_ww:ability_unlock_cheat") {
		unlock_all_abilities(entity);
    }
    else if (e.id == "ljw_ww:appearance_unlock_cheat") {
		unlock_all_apperances(entity);
    }
    else if (e.id == "ljw_ww:reset_progress") {
		reset_all_progress(entity);
    }
    else if (e.id == "ljw_ww:werewolf_sound") {
		werewolf_sound(entity, e.message);
    }
    else if (e.id == "ljw_ww:test") {
		const equipment = entity.getComponent("equippable");
		const wolfband = equipment.getEquipment("Offhand");
		
		// Head Equipment
		const durabilityComponent = wolfband.getComponent('durability');
		if (durabilityComponent != null) {
			const damage = durabilityComponent.damage;
			const damageMax = durabilityComponent.maxDurability;
			durabilityComponent.damage = Math.min(damage + 100, damageMax);
			debug.info(`${damage} | ${damageMax}`)
		}
		equipment.setEquipment("Offhand", wolfband);
    }
});

function activate_wolfband(equippableComponent, slot, wolfband) {
	const name = wolfband.nameTag;
	const newBand = new ItemStack("ljw_ww:wolfband_b");
	if (name && (name.length > 0))
		newBand.nameTag = name;
	
	const oldDurabilityComponent = wolfband.getComponent('durability');
	const newDurabilityComponent = newBand.getComponent('durability');
	if (oldDurabilityComponent && newDurabilityComponent) {
		const damage = oldDurabilityComponent.damage;
		const damageMax = oldDurabilityComponent.maxDurability;
		newDurabilityComponent.damage = Math.min(damage + 1, damageMax);
	}
	equippableComponent.setEquipment(slot, newBand);
}

function deactivate_wolfband(equippableComponent, slot, wolfband) {
	const name = wolfband.nameTag;
	const newBand = new ItemStack("ljw_ww:wolfband");
	if (name && (name.length > 0))
		newBand.nameTag = name;
	
	const oldDurabilityComponent = wolfband.getComponent('durability');
	const newDurabilityComponent = newBand.getComponent('durability');
	if (oldDurabilityComponent && newDurabilityComponent) {
		const damage = oldDurabilityComponent.damage;
		const damageMax = oldDurabilityComponent.maxDurability;
		
		if (damage == damageMax) {
			equippableComponent.setEquipment(slot);
			return false;
		}
		else {
			newDurabilityComponent.damage = damage;
			equippableComponent.setEquipment(slot, newBand);
			return true;
		}
	}
}

function unlock_all_abilities(player) {
	try {
		player.setDynamicProperty("ljw_ww:werewolf_level", 4);
		const abilityList = [];
		
		for (const ability of Object.keys(abilities.list)) {
			const abilityEntry = abilities.list[ability];
			const maxLevel = abilityEntry.maxLevel;
			const setLevel = abilityEntry.cheatUnlockLevel ?? abilityEntry.maxLevel;
			const activatedByItem = abilityEntry.activatedByItem ?? false;
			
			player.setDynamicProperty(`ljw_ww:werewolf_${ability}_level`, maxLevel);
			player.setDynamicProperty(`ljw_ww:werewolf_${ability}_setting`, setLevel);
			if (activatedByItem) {
				player.getComponent("inventory")?.container.addItem(new ItemStack(`ljw_ww:ability_${ability}`));
			}
		}
		
		for (const emblemClass of abilities.emblemClasses) {
			player.setDynamicProperty(`ljw_ww:acquired_emblem_${emblemClass}`, true);
		}
		
		player.setDynamicProperty(`ljw_ww:werewolf_ability_learned`, true);
	}
	catch (err) {
		debug.error(`Ability Unlock Cheat Error: ${err}`)
	}
}

function unlock_all_apperances(player) {
	try {
		player.setDynamicProperty("ljw_ww:werewolf_form_list", appearance.wolfIDList.join(";") + ";");
		player.setDynamicProperty("ljw_ww:trim_pack_list", appearance.trimLibrary.join(";") + ";");
		player.setDynamicProperty("ljw_ww:trim_material_list", appearance.trimMaterialLibrary.join(";") + ";");
	}
	catch (err) {
		debug.error(`Appearance Unlock Cheat Error: ${err}`);
	}
}

function reset_all_progress(player) {
	try {
		player.setDynamicProperty("ljw_ww:werewolf_form_list");
		player.setDynamicProperty("ljw_ww:trim_pack_list");
		player.setDynamicProperty("ljw_ww:trim_material_list");
		for (const ability of Object.keys(abilities.list)) {
			player.setDynamicProperty(`ljw_ww:werewolf_${ability}_level`);
			player.setDynamicProperty(`ljw_ww:werewolf_${ability}_setting`);
		}
		player.setDynamicProperty(`ljw_ww:werewolf_level`);
		for (const emblemClass of abilities.emblemClasses) {
			player.setDynamicProperty(`ljw_ww:acquired_emblem_${emblemClass}`);
		}
	}
	catch (err) {
		debug.error(`Progress Reset Error: ${err}`);
	}
}

function form_tick() {
	for (const player of playerList) { 
		try {
			if (!player.isValid()) {
				continue;
			}
			
			const form = player.getDynamicProperty("ljw_ww:form") ?? "normal";
			
			const equipment = player.getComponent("equippable");
			const hasEquipment = equipment.getEquipment("Head")?.hasTag("ljw_ww:werewolf_form");
			const berserkTime = player.getDynamicProperty("ljw_ww:berserk_time") ?? 0;
			let transformed = false;
			
			// Determine if a transformation needs to occur
			if ((form != "wolf") && hasEquipment) {
				player.setDynamicProperty("ljw_ww:form", "wolf");
				transformed = true;
				player.playAnimation("animation.ljw_ww.werewolf_form.transform_to_wolf", {controller: "controller.animation.ljw_ww.werewolf_form", nextState: "animation.ljw_ww.werewolf_form.corrections", stopExpression: "q.any_animation_finished", blendOutTime: 0.1});
			}
			else if ((form != "normal") && !hasEquipment){
				player.setDynamicProperty("ljw_ww:form", "normal");
				transformed = true;
				player.playAnimation("animation.ljw_ww.werewolf_form.transform_to_normal", {controller: "controller.animation.ljw_ww.werewolf_form", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "q.any_animation_finished", blendOutTime: 0.1});
			}
			
			// If transformed, set a delay
			if (transformed) {
				player.setDynamicProperty("ljw_ww:transforming", true);
				system.runTimeout(() => {player.setDynamicProperty("ljw_ww:transforming", false);}, 10);
			}
			
			// If not normal form, set invis
			if (form != "normal") {
				player.addEffect("invisibility", 600, {showParticles: false});
			}
			
			const lunarburnExposure = player.getDynamicProperty("ljw_ww:lunarburn_exposure") ?? 0;
			
			// Run transformation mechanics & animations (unless a delay is active)
			const transforming = player.getDynamicProperty("ljw_ww:transforming") ?? false;
			if (!transforming) {
				if (form == "normal") {
					player.playAnimation("animation.ljw_ww.werewolf_form.blank", {controller: "controller.animation.ljw_ww.werewolf_form", nextState: "animation.ljw_ww.werewolf_form.transform_to_wolf", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form')", blendOutTime: 0.1});
					if (berserkTime > 0) {
						player.setDynamicProperty("ljw_ww:berserk_time", 0);
					}
					if (lunarburnExposure > data.lunarburnExposureMax[0]) {
						player.setDynamicProperty("ljw_ww:lunarburn_exposure", data.lunarburnExposureMax[0]);
					}
				}
				else if (form == "wolf") {
					const loopCount = player.getDynamicProperty("ljw_ww:wolf_counter_loop") ?? 0;
					const agilityLevel = player.getDynamicProperty(`ljw_ww:werewolf_agility_setting`) ?? 0;
					const regenLevel = player.getDynamicProperty(`ljw_ww:werewolf_auto_regen_setting`) ?? 0;
					const jumpDashLevel = player.getDynamicProperty(`ljw_ww:werewolf_jump_dash_setting`) ?? 0;
					const leapFlightLevel = player.getDynamicProperty(`ljw_ww:werewolf_leap_of_flight_setting`) ?? 0;
					const nightVisionLevel = player.getDynamicProperty(`ljw_ww:werewolf_night_vision_setting`) ?? 0;
					const battleVigorLevel = player.getDynamicProperty(`ljw_ww:werewolf_battle_vigor_setting`) ?? 0;
					const climbingClawsLevel = player.getDynamicProperty(`ljw_ww:werewolf_climbers_claws_setting`) ?? 0;
					const divingMasteryLevel = player.getDynamicProperty(`ljw_ww:werewolf_diving_mastery_setting`) ?? 0;
					const HPUPLevel = player.getDynamicProperty(`ljw_ww:werewolf_hp_up_setting`) ?? 0;
					const miningClawLevel = player.getDynamicProperty(`ljw_ww:werewolf_mining_claw_setting`) ?? 0;
					const miningStamina = player.getDynamicProperty("ljw_ww:mining_stamina") ?? abilities.miningStaminaMax;
					const damageScore = player.getDynamicProperty(`ljw_ww:damage_score`) ?? 0;
					const handEquipment = player.getComponent("equippable")?.getEquipment("Mainhand");
					const legEquipment = equipment.getEquipment("Legs");
					const feetEquipment = equipment.getEquipment("Feet");
					const customAnimsEnabled = world.getDynamicProperty("ljw_ww:setting_enable_custom_anims") ?? true;
					const berserkVisionEnabled = world.getDynamicProperty("ljw_ww:setting_enable_berserk_vision") ?? true;
					const regenerationCharge = player.getDynamicProperty("ljw_ww:regeneration_charge") ?? 1.0;
					const isJumping = player.inputInfo.getButtonState("Jump") == "Pressed";
					const movementVector = player.inputInfo.getMovementVector();
					const isMovingForward = movementVector.y > 0;
					const healthComponent = player.getComponent("health");
					let jumpDashPerformed = player.getDynamicProperty("ljw_ww:jump_dash_performed") ?? false;
					const leapFlightActive = player.getDynamicProperty("ljw_ww:leap_flight_active") ?? false;
					const sprinting = player.isSprinting;
					const sleeping = player.isSleeping;
					const sneaking = player.isSneaking;
					
					if (lunarburnExposure > 0) {
						// High levels of lunarburn cause damage
						if (lunarburnExposure >= data.lunarburnExposureHazardThreshold) {
							if ((loopCount + 1) % 50 == 0) {
								const healthMinimum = (lunarburnExposure >= data.lunarburnExposureDangerThreshold) ? 2 : 10;
								const health = healthComponent.currentValue;
								const availableHealth = Math.max(0, health - healthMinimum);
								const damageAmount = Math.min(2.5, availableHealth);
								if (damageAmount > 0) {
									player.applyDamage(damageAmount, { cause: "magma" });
								}
							}
						}
					}
					
					if (sprinting) {
						if (lunarburnExposure < data.lunarburnExposureEffectThreshold) {
							player.addEffect("speed", 20, {showParticles: false, amplifier: agilityLevel});
							player.addEffect("jump_boost", 20, {showParticles: false});
						}
						
						if (customAnimsEnabled && player.isOnGround && !sneaking && !legEquipment?.hasTag("ljw_ww:werewolf_glide") && !(legEquipment?.hasTag("ljw_ww:werewolf_run") || legEquipment?.hasTag("ljw_ww:werewolf_ability_anim")) && !legEquipment?.hasTag("ljw_ww:werewolf_climb")) {
							player.playAnimation("animation.ljw_ww.werewolf_form.action.sprint_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.sprint_conclude", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || ((!q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_run') && !q.is_first_person) || q.is_in_water || q.is_crawling)", blendOutTime: 0.2});
							player.playAnimation("animation.ljw_ww.werewolf_form.sprint_init", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.action.sprint_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_run') && !q.is_first_person && !q.is_in_water && !q.is_crawling) && (Math.mod(q.time_stamp, 5) == 0)", blendOutTime: 0.2});
							set_legs_equipment(player, "run");
						}
					}
					else if (!customAnimsEnabled && legEquipment?.hasTag("ljw_ww:werewolf_run")) {
						set_legs_equipment(player);
					}
					else if ((!sprinting || player.isSwimming) && customAnimsEnabled && legEquipment?.hasTag("ljw_ww:werewolf_run")) {
						set_legs_equipment(player);
					}
					
					if (sleeping) {
						if (customAnimsEnabled && !legEquipment?.hasTag("ljw_ww:werewolf_sleep")) {
							werewolf_sound(player, "rest");
							set_legs_equipment(player, "sleep");
						}
					}
					else if (!customAnimsEnabled && legEquipment?.hasTag("ljw_ww:werewolf_sleep")) {
						set_legs_equipment(player);
					}
					else if (customAnimsEnabled && !sleeping && legEquipment?.hasTag("ljw_ww:werewolf_sleep")) {
						set_legs_equipment(player);
					}
					
					if (nightVisionLevel == 2) {
						player.addEffect("night_vision", 300, {showParticles: false});
					}
					else if ((nightVisionLevel == 1) || ((berserkTime > 0) && berserkVisionEnabled)) {
						const darknessEffectTest = player.getEffect("darkness");
						const nightVisionEffectTest = player.getEffect("night_vision");
						if ((darknessEffectTest == null) && (nightVisionEffectTest == null)) {
							let visionBlockSet = true;
							const visionBlockID = player.getDynamicProperty("ljw_ww:wolf_vision_block_id");
							if (visionBlockID != null) {
								try {
									if (world.getEntity(visionBlockID) == null)
										visionBlockSet = false;
								}
								catch(err) {
									visionBlockSet = false;
								}
							}
							else {
								visionBlockSet = false;
							}
							
							if (!visionBlockSet) {
								const visionBlock = player.dimension.spawnEntity("ljw_ww:block", player.location);
								visionBlock.setDynamicProperty("ljw_ww:player_id", player.id);
								player.setDynamicProperty("ljw_ww:wolf_vision_block_id", visionBlock.id);
							}
						}
					}
					
					if (HPUPLevel > 0) {
						if (player.getEffect("health_boost") == null) {
							const healthRatio = healthComponent.currentValue / healthComponent.effectiveMax;
							player.addEffect("health_boost", 600, {showParticles: false, amplifier: HPUPLevel - 1});
							healthComponent.setCurrentValue(healthComponent.effectiveMax * healthRatio);
						}
						else {
							player.addEffect("health_boost", 600, {showParticles: false, amplifier: HPUPLevel - 1});
						}
					}
					
					if (!player.getEffect("wither") && !player.getComponent("minecraft:onfire") && (lunarburnExposure <= 0)) {
						let recoveryAmount = 0;
						if (regenLevel == 0)
							recoveryAmount = 0.010;
						else if (regenLevel == 1)
							recoveryAmount = 0.015;
						else if (regenLevel == 2)
							recoveryAmount = 0.020;
						
						healthComponent.setCurrentValue(Math.min(healthComponent.effectiveMax, healthComponent.currentValue + (recoveryAmount * regenerationCharge)));
					}
					
					if (berserkTime > 0) {
						if ((loopCount % 100 == 0) && (Math.random() >= 0.65))
							werewolf_sound(player, "angry");
						
						player.setDynamicProperty("ljw_ww:berserk_time", berserkTime - 1);
						if (lunarburnExposure < data.lunarburnExposureEffectThreshold) {
							player.addEffect("strength", 5, {showParticles: false, amplifier: 2});
							player.addEffect("haste", 5, {showParticles: false, amplifier: 1});
						}
						else {
							player.addEffect("strength", 5, {showParticles: false, amplifier: 0});
						}
					}
					else {
						if (feetEquipment?.hasTag("ljw_ww:werewolf_berserk_state")) {
							set_feet_equipment(player);
						}
						
						if (battleVigorLevel > 0) {
							let level = 0;
							if ((battleVigorLevel >= 3) && (damageScore > 45))
								level = 3;
							else if ((battleVigorLevel >= 2) && (damageScore > 25))
								level = 2;
							else if ((battleVigorLevel >= 1) && (damageScore > 10))
								level = 1;
							
							if (lunarburnExposure >= data.lunarburnExposureEffectThreshold) {
								level = 0;
							}
							
							if (level > 0)
								player.addEffect("strength", 5, {showParticles: false, amplifier: Math.max(0, level - 1)});
						}
					}
					if (damageScore > 0)
						player.setDynamicProperty(`ljw_ww:damage_score`, Math.max(0, damageScore - 0.05));
					
					if (legEquipment?.hasTag("ljw_ww:werewolf_run") && !player.isOnGround && !player.isInWater) {
						if (customAnimsEnabled)
							set_legs_equipment(player, "glide");
					}
					
					if (jumpDashLevel > 0) {
						const jumpCount = player.getDynamicProperty("ljw_ww:jump_count") ?? 0;
						const canDoubleJump = player.getDynamicProperty("ljw_ww:can_double_jump") ?? false;
						const timeSinceJump = Math.max(0, Date.now() - (player.getDynamicProperty("ljw_ww:jump_time") ?? 0));
						const dashWindowExpired = (timeSinceJump > 500) && (leapFlightLevel == 0);
						
						if (((!sprinting && (leapFlightLevel == 0)) || player.isOnGround || (player.isInWater && (divingMasteryLevel == 3) && dashWindowExpired)) && (jumpCount > 0)) {
							player.setDynamicProperty("ljw_ww:jump_count", 0);
							player.setDynamicProperty("ljw_ww:can_double_jump", false);
						}
						else {
							if (isJumping && sprinting) {
								if (jumpCount == 0) {
									player.setDynamicProperty("ljw_ww:jump_count", 1);
									player.setDynamicProperty("ljw_ww:jump_time", Date.now());
								}
								else if (!dashWindowExpired && (jumpCount == 1) && (canDoubleJump)) {
									const viewDir = player.getViewDirection();
									player.applyKnockback(viewDir.x, viewDir.z, 2.0, util.clamp(viewDir.y * 2, -0.75, 0.75));
									player.setDynamicProperty("ljw_ww:jump_count", 2);
									player.setDynamicProperty("ljw_ww:jump_dash_performed", true);
									jumpDashPerformed = true;
									
									const particleConfig = new MolangVariableMap();
									particleConfig.setFloat("r", 0.25);
									particleConfig.setFloat("g", 0.25);
									particleConfig.setFloat("b", 0.25);
									particleConfig.setFloat("size_modifier", 0.4);
									player.dimension.spawnParticle("ljw_ww:scan_wave_1", player.location, particleConfig);
									player.dimension.spawnParticle("ljw_ww:scan_wave_2", player.location, particleConfig);
									system.runTimeout(() => {try { player.dimension.spawnParticle("ljw_ww:wind_trail", player.location); } catch(err){}}, 0);
									system.runTimeout(() => {try { player.dimension.spawnParticle("ljw_ww:wind_trail", player.location); } catch(err){}}, 2);
									system.runTimeout(() => {try { player.dimension.spawnParticle("ljw_ww:wind_trail", player.location); } catch(err){}}, 4);
									system.runTimeout(() => {try { player.dimension.spawnParticle("ljw_ww:wind_trail", player.location); } catch(err){}}, 6);
									system.runTimeout(() => {try { player.dimension.spawnParticle("ljw_ww:wind_trail", player.location); } catch(err){}}, 8);
									werewolf_sound(player, "leap");
									if (customAnimsEnabled)
										set_legs_equipment(player, "glide");
								}
							}
						}
						
						if ((jumpCount == 1) && !isJumping && !canDoubleJump) {
							player.setDynamicProperty("ljw_ww:can_double_jump", true);
						}
					}
					
					if (jumpDashPerformed && !isJumping) {
						player.setDynamicProperty("ljw_ww:jump_dash_performed", false);
					}
					
					if ((leapFlightLevel > 0) && !jumpDashPerformed) {
						const requiredJumps = (jumpDashLevel > 0) ? 2 : 1;
						const jumpCount = player.getDynamicProperty("ljw_ww:jump_count") ?? 0;
						const canLeapJump = player.getDynamicProperty("ljw_ww:can_leap_jump") ?? false;
						if ((player.isOnGround || (player.isInWater && (divingMasteryLevel == 3))) && (jumpCount > 0)) {
							player.setDynamicProperty("ljw_ww:jump_count", 0);
							player.setDynamicProperty("ljw_ww:can_leap_jump", false);
						}
						else {
							if (!leapFlightActive && isJumping && (sprinting || (jumpCount > 2))) {
								if (jumpCount == 0) {
									player.setDynamicProperty("ljw_ww:jump_count", 1);
								}
								else if (canLeapJump && (jumpCount >= requiredJumps)) {
									const rocketCount = util.countItem(player, "minecraft:firework_rocket");
									const canLeap = (rocketCount > 0);
									if (canLeap) {
										util.decrement_item(player, "minecraft:firework_rocket");
										
										const viewDir = player.getViewDirection();
										player.applyKnockback(viewDir.x, viewDir.z, 7.0, 1.0);
										player.setDynamicProperty("ljw_ww:leap_flight_active", true);
										werewolf_sound(player, "leap");
										player.setDynamicProperty(`ljw_ww:fallproof`, true);
										
										const particleConfig = new MolangVariableMap();
										particleConfig.setFloat("r", 0.54);
										particleConfig.setFloat("g", 0.20);
										particleConfig.setFloat("b", 0.71);
										particleConfig.setFloat("size_modifier", 1.5);
										player.dimension.spawnParticle("ljw_ww:scan_wave_1", player.location, particleConfig);
										player.dimension.spawnParticle("ljw_ww:scan_wave_2", player.location, particleConfig);
										
										if (customAnimsEnabled)
											set_legs_equipment(player, "glide");
									}
									player.setDynamicProperty("ljw_ww:jump_count", jumpCount + 1);
								}
							}
							else if (leapFlightActive && !isJumping) {
								player.setDynamicProperty("ljw_ww:leap_flight_active", false);
							}
						}
						
						if ((jumpCount == 1) && !isJumping && !canLeapJump) {
							player.setDynamicProperty("ljw_ww:can_leap_jump", true);
						}
					}
					else if (leapFlightActive && !isJumping) {
						player.setDynamicProperty("ljw_ww:leap_flight_active", false);
					}
					
					if (legEquipment?.hasTag("ljw_ww:werewolf_glide")) {
						if (player.isInWater) {
							set_legs_equipment(player);
						}
						else if (player.isOnGround) {
							if (sprinting && !sneaking) {
								if (customAnimsEnabled && !(legEquipment?.hasTag("ljw_ww:werewolf_run") || legEquipment?.hasTag("ljw_ww:werewolf_ability_anim")) && !legEquipment?.hasTag("ljw_ww:werewolf_climb")) {
									player.playAnimation("animation.ljw_ww.werewolf_form.action.sprint_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.sprint_conclude", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || ((!q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_run') && !q.is_first_person) || q.is_in_water || q.is_crawling)", blendOutTime: 0.2});
									player.playAnimation("animation.ljw_ww.werewolf_form.sprint_init", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.action.sprint_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_run') && !q.is_first_person && !q.is_in_water && !q.is_crawling) && (Math.mod(q.time_stamp, 5) == 0)", blendOutTime: 0.2});
									set_legs_equipment(player, "run");
								}
							}
							else {
								set_legs_equipment(player);
							}
						}
						else if ((loopCount + 1) % 50 == 0) {
							if (check_riding(player).isRiding) {
								set_legs_equipment(player);
							}
						}
					}
					
					if (climbingClawsLevel > 0) {
						const climbingStamina = player.getDynamicProperty("ljw_ww:climbing_stamina") ?? 0;
						const climbingStaminaMax = abilities.climbingDurations[climbingClawsLevel - 1];
						const isClimbing = player.getDynamicProperty("ljw_ww:is_climbing") ?? false;
						
						if (((climbingClawsLevel == 4) || (climbingStamina > 0)) && isJumping && isMovingForward && !player.isSwimming) {
							const viewDir = util.view_rot_to_dir(player.getRotation());
							
							const blockAboveLoc = {x: player.location.x, y: player.location.y + 1.4, z: player.location.z};
							const blockBelowLoc = {x: player.location.x + util.clamp(viewDir.x, -0.1, 0.1) * 5, y: player.location.y, z: player.location.z + util.clamp(viewDir.z, -0.1, 0.1) * 5};
							
							const blockAboveTest = player.dimension.getBlockFromRay(blockAboveLoc, {x: viewDir.x, y: 0, z: viewDir.z}, {maxDistance: 1, includePassableBlocks: false});
							const blockBelowTest = player.dimension.getBlockFromRay(blockBelowLoc, {x: 0, y: 1, z: 0}, {maxDistance: 1.4, includePassableBlocks: false});
							
							let climbableBlockAbove = false;
							let climbableBlockBelow = false;
							
							if (blockAboveTest?.block != null) {
								const testLocation = {x: blockAboveTest.faceLocation.x + blockAboveTest.block.location.x, y: blockAboveTest.faceLocation.y + blockAboveTest.block.location.y, z: blockAboveTest.faceLocation.z + blockAboveTest.block.location.z}
								
								climbableBlockAbove = (util.distance3D(blockAboveLoc, testLocation) <= 0.15);
							}
							
							if (!climbableBlockAbove) {
								const blockCenterLoc = {x: player.location.x, y: player.location.y + 0.85, z: player.location.z};
								const blockCenterTest = player.dimension.getBlockFromRay(blockCenterLoc, {x: viewDir.x, y: 0, z: viewDir.z}, {maxDistance: 1, includePassableBlocks: false});
								if (blockCenterTest?.block != null) {
									const testLocation = {x: blockCenterTest.faceLocation.x + blockCenterTest.block.location.x, y: blockCenterTest.faceLocation.y + blockCenterTest.block.location.y, z: blockCenterTest.faceLocation.z + blockCenterTest.block.location.z}
									
									climbableBlockAbove = (util.distance3D(blockCenterLoc, testLocation) <= 0.15);
								}
							}
							
							if (blockBelowTest?.block != null) {
								climbableBlockBelow = true;
							}
							
							const shouldClimb = (isClimbing && (climbableBlockAbove || climbableBlockBelow)) || (!isClimbing && climbableBlockAbove);
							
							if (shouldClimb) {
								player.applyKnockback(0, 0, 0, 0.2);
								player.setDynamicProperty("ljw_ww:climbing_stamina", Math.max(0, climbingStamina - 1));
						
								if (!isClimbing) {
									player.setDynamicProperty("ljw_ww:is_climbing", true);
									set_legs_equipment(player, "climb");
								}
							}
							else {
								if (isClimbing) {
									player.setDynamicProperty("ljw_ww:is_climbing", false);
									const viewDir = util.view_rot_to_dir(player.getRotation());
									if (player.dimension.getBlock({x: player.location.x + viewDir.x, y: player.location.y - 1, z: player.location.z + viewDir.z}).isAir) {
										set_legs_equipment(player, "glide");
									}
									else {
										set_legs_equipment(player);
									}
								}
							}
						}
						else {
							if (isClimbing) {
								player.setDynamicProperty("ljw_ww:is_climbing", false);
								set_legs_equipment(player, "glide");
							}
						}
						
						if ((climbingStamina < climbingStaminaMax) && (player.isOnGround || player.isInWater)) {
							player.setDynamicProperty("ljw_ww:climbing_stamina", climbingStaminaMax);
						}
					}
					
					if (miningClawLevel == 1) {
						if ((miningStamina < abilities.miningStaminaMax) && (loopCount % 40 == 0)) {
							const newStamina = miningStamina + 1;
							player.setDynamicProperty("ljw_ww:mining_stamina", newStamina);
						}
					}
					
					// Scent Tracker
					if ((loopCount > 0) && (loopCount % 100) == 0) {
						scent_tracker_track(player);
					}
					
					// Ensure animations are loaded
					{
						player.playAnimation("animation.ljw_ww.werewolf_form.corrections", {controller: "controller.animation.ljw_ww.werewolf_form", nextState: "animation.ljw_ww.werewolf_form.transform_to_normal", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form')", blendOutTime: 0.1});
						player.playAnimation("animation.ljw_ww.werewolf_form.attachable_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.b", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form')", blendOutTime: 0.1});
						player.playAnimation("animation.ljw_ww.werewolf_form.idle", {controller: "controller.animation.ljw_ww.werewolf_form.idle", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form')", blendOutTime: 0.1});
						
						if (legEquipment.hasTag("ljw_ww:werewolf_glide")) {
							player.playAnimation("animation.ljw_ww.werewolf_form.action.sprint_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.sprint_conclude", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || ((!q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_run') && !q.is_first_person) || q.is_in_water || q.is_crawling)", blendOutTime: 0.2});
							player.playAnimation("animation.ljw_ww.werewolf_form.sprint_init", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.action.sprint_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_run') && !q.is_first_person && !q.is_in_water && !q.is_crawling) && (Math.mod(q.time_stamp, 5) == 0)", blendOutTime: 0.2});
							player.playAnimation("animation.ljw_ww.werewolf_form.action.glide_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.action.sprint_corrections", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || (!q.equipped_item_all_tags('slot.armor.legs', 'ljw_ww:werewolf_glide'))", blendOutTime: 0});
						}
						else if (legEquipment.hasTag("ljw_ww:werewolf_climb")) {
							player.playAnimation("animation.ljw_ww.werewolf_form.action.climb_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.climb", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || (!q.equipped_item_all_tags('slot.armor.legs', 'ljw_ww:werewolf_climb'))", blendOutTime: 0});
						}
						else {
							player.playAnimation("animation.ljw_ww.werewolf_form.blank", {controller: "controller.animation.ljw_ww.werewolf_form.climb", nextState: "animation.ljw_ww.werewolf_form.action.climb_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_all_tags('slot.armor.legs', 'ljw_ww:werewolf_climb'))", blendOutTime: 0});
						}
						
						if (loopCount >= 200) {
							if (customAnimsEnabled && !player.isSwimming) {
								player.playAnimation("animation.ljw_ww.werewolf_form.action.sprint_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.action.glide_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_all_tags('slot.armor.legs', 'ljw_ww:werewolf_glide'))", blendOutTime: 0.2});
								player.playAnimation("animation.ljw_ww.werewolf_form.action.sprint_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.sprint_conclude", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || ((!q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_run') && !q.is_first_person) || q.is_in_water || q.is_crawling)", blendOutTime: 0.2});
								if (!sprinting) {
									player.playAnimation("animation.ljw_ww.werewolf_form.sprint_conclude", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.sprint_init", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_run') && !q.is_first_person && !q.is_in_water && !q.is_crawling)", blendOutTime: 0.2});
								}
							}
							
							player.playAnimation("animation.ljw_ww.werewolf_form.action.swim_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.swim", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || (!q.is_swimming && !q.is_crawling)", blendOutTime: 0});
							player.playAnimation("animation.ljw_ww.werewolf_form.blank", {controller: "controller.animation.ljw_ww.werewolf_form.swim", nextState: "animation.ljw_ww.werewolf_form.action.swim_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.is_swimming || q.is_crawling)", blendOutTime: 0});
							
							player.playAnimation("animation.ljw_ww.werewolf_form.action.ride", {controller: "controller.animation.ljw_ww.werewolf_form.ride", nextState: "animation.ljw_ww.werewolf_form.ride.b", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || (!q.is_riding)", blendOutTime: 0});
							player.playAnimation("animation.ljw_ww.werewolf_form.action.ride.b", {controller: "controller.animation.ljw_ww.werewolf_form.ride", nextState: "animation.ljw_ww.werewolf_form.action.ride", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.is_riding)", blendOutTime: 0});
						}
						
						if (player.isSneaking) {
							player.playAnimation("animation.ljw_ww.werewolf_form.action.sneak", {controller: "controller.animation.ljw_ww.werewolf_form.sneak", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || (!q.is_sneaking)", blendOutTime: 0});
						}
						else {
							player.playAnimation("animation.ljw_ww.werewolf_form.blank", {controller: "controller.animation.ljw_ww.werewolf_form.sneak", nextState: "animation.ljw_ww.werewolf_form.action.sneak", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.is_sneaking)", blendOutTime: 0});
						}
						
						if (sleeping) {
							player.playAnimation("animation.ljw_ww.werewolf_form.action.sleep_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.sleep", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || (!q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_sleep'))", blendOutTime: 0});
						}
						else {
							player.playAnimation("animation.ljw_ww.werewolf_form.blank", {controller: "controller.animation.ljw_ww.werewolf_form.sleep", nextState: "animation.ljw_ww.werewolf_form.action.sleep_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_any_tag('slot.armor.legs', 'ljw_ww:werewolf_sleep'))", blendOutTime: 0});
						}
						
						//if (handEquipment?.hasTag("ljw_ww:werewolf_ability")) {
						//	player.playAnimation("animation.ljw_ww.werewolf_form.action.ability_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.hold_ability", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || (!q.equipped_item_any_tag('slot.weapon.mainhand', 'ljw_ww:werewolf_ability'))", blendOutTime: 0});
						//}
						//else {
						//	player.playAnimation("animation.ljw_ww.werewolf_form.blank", {controller: "controller.animation.ljw_ww.werewolf_form.hold_ability", nextState: "animation.ljw_ww.werewolf_form.action.ability_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_any_tag('slot.weapon.mainhand', 'ljw_ww:werewolf_ability'))", blendOutTime: 0});
						//}
						
						//player.playAnimation("animation.ljw_ww.werewolf_form.action.sprint", {controller: "controller.animation.ljw_ww.werewolf_form.sprint", nextState: "animation.ljw_ww.werewolf_form.sprint_conclude", stopExpression: "!q.is_sprinting", blendOutTime: 0});
					}
					
					if (loopCount >= 200) {
						lycan_guard_validate(player);
						player.setDynamicProperty("ljw_ww:wolf_counter_loop", 0);
					}
					else {
						player.setDynamicProperty("ljw_ww:wolf_counter_loop", loopCount + 1);
					}
				}
			}
		}
		catch(err) {
			debug.warn(`Armor check error: ${err}`);
		}
	}
}
system.runInterval(form_tick);

function transformation_window_check() {
	try {
		for (const player of playerList) {
			const morphID = player.getDynamicProperty("ljw_ww:selected_werewolf_form") ?? 0;
			
			// Check for wolfband
			const equipment = player.getComponent("equippable");
			const mainhandEquipment = equipment.getEquipment("Mainhand");
			const offhandEquipment = equipment.getEquipment("Offhand");
			let hasWolfband = offhandEquipment && (offhandEquipment.hasTag("ljw_ww:wolfband"));
			hasWolfband = hasWolfband || (mainhandEquipment && (mainhandEquipment.hasTag("ljw_ww:wolfband")));
			const hasActiveWolfband = hasWolfband && ((mainhandEquipment && (mainhandEquipment.hasTag("ljw_ww:wolfband_active"))) || (offhandEquipment && (offhandEquipment.hasTag("ljw_ww:wolfband_active"))));
			
			if (morphID != null) {
				// Get info
				const morphEnabled = player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
				const transformExtendTime = player.getDynamicProperty("ljw_ww:transformation_extend_time") ?? 0;
				const transformInhibitTime = player.getDynamicProperty("ljw_ww:transformation_inhibit_time") ?? 0;
				const caveWolfLevel = player.getDynamicProperty(`ljw_ww:werewolf_cave_wolf_setting`) ?? 0;
				
				const dimension = player.dimension;
				const dayTime = world.getTimeOfDay();
				const isNight = (dayTime >= 13000) && (dayTime < 23000);
				const lunarAccess = isNight && (dimension.id == "minecraft:overworld") && ((caveWolfLevel == 1) || (player.location.y > 20));
				
				// Get current equipment
				const headEquipment = equipment.getEquipment("Head");
				const chestEquipment = equipment.getEquipment("Chest");
				const legsEquipment = equipment.getEquipment("Legs");
				const feetEquipment = equipment.getEquipment("Feet");
				
				// Determine if transformation has already occured
				const hasEquipment = (headEquipment != null) && headEquipment.hasTag("ljw_ww:werewolf_form");
				const hasChestEquipment = equipment.getEquipment("Chest")?.hasTag("ljw_ww:werewolf_form");
				const hasLegEquipment = equipment.getEquipment("Legs")?.hasTag("ljw_ww:werewolf_form");
				const hasFeetEquipment = equipment.getEquipment("Feet")?.hasTag("ljw_ww:werewolf_form");
				
				// Determine if transformation is blocked by incompatible equipment
				let equipmentOK = true;
				equipmentOK = equipmentOK && ((headEquipment == null) || (headEquipment.hasTag("ljw_ww:werewolf_form")) || ((headEquipment.lockMode == "none") && (headEquipment.getComponent('enchantable')?.getEnchantment("binding") == null)));
				equipmentOK = equipmentOK && ((chestEquipment == null) || (chestEquipment.hasTag("ljw_ww:werewolf_form")) || ((chestEquipment.lockMode == "none") && (chestEquipment.getComponent('enchantable')?.getEnchantment("binding") == null)));
				equipmentOK = equipmentOK && ((legsEquipment == null) || (legsEquipment.hasTag("ljw_ww:werewolf_form")) || ((legsEquipment.lockMode == "none") && (legsEquipment.getComponent('enchantable')?.getEnchantment("binding") == null)));
				equipmentOK = equipmentOK && ((feetEquipment == null) || (feetEquipment?.hasTag("ljw_ww:werewolf_form")) || ((feetEquipment?.lockMode == "none") && (feetEquipment?.getComponent('enchantable')?.getEnchantment("binding") == null)));
				let transformationBlockedByArmor = player.getDynamicProperty("ljw_ww:transformation_blocked_by_armor");
				if (transformationBlockedByArmor == null) {
					transformationBlockedByArmor = false;
					player.setDynamicProperty("ljw_ww:transformation_blocked_by_armor", false);
				}
				
				// Determine if transformation is blocked by lunarburn exposure
				const lunarburnExposure = player.getDynamicProperty("ljw_ww:lunarburn_exposure") ?? 0;
				const lunarburnOK = (lunarburnExposure < data.lunarburnExposureEffectThreshold);
				let transformationBlockedByLunarburn = player.getDynamicProperty("ljw_ww:transformation_blocked_by_lunarburn");
				if (transformationBlockedByLunarburn == null) {
					transformationBlockedByLunarburn = false;
					player.setDynamicProperty("ljw_ww:transformation_blocked_by_lunarburn", false);
				}
				
				// Update Tag
				if (morphEnabled)
					player.addTag("ljw_ww_hasWerewolfPowers");
				else
					player.removeTag("ljw_ww_hasWerewolfPowers");
				
				// Determine if powers have been lost & transformation needs to be forced
				const transformationOverride = (!morphEnabled && hasEquipment);
				
				// Determine if player has chosen to stay in wolf form (or if full moon is overriding)
				const preferredForm = player.getDynamicProperty("ljw_ww:preferred_form") ?? "werewolf";
				const fullMoon = full_moon_check(player);
				const werewolfFormSelected = (preferredForm == "werewolf") || fullMoon;
				if (!hasWolfband && morphEnabled && (preferredForm != "werewolf") && fullMoon && !hasEquipment) {
					player.sendMessage({ translate: "ljw_ww.message.shift_forced_by_moonlight", with: { rawtext: [ { text: "\n" }]} });
				}
				
				// Determine if tranformation should occur
				let canTransform = equipmentOK && (lunarburnOK || hasEquipment);
				canTransform = canTransform && morphEnabled;
				canTransform = canTransform && (transformInhibitTime == 0);
				canTransform = canTransform && !player.isGliding;
				canTransform = canTransform && (!player.isSleeping || (world.getDynamicProperty("ljw_ww:setting_enable_custom_anims") ?? true));
				let transformEnvironment = false;
				transformEnvironment = transformEnvironment || (dimension.id == "minecraft:the_end");
				transformEnvironment = transformEnvironment || lunarAccess;
				transformEnvironment = transformEnvironment || (transformExtendTime > 0);
				const useAlwaysWolf = always_wolf_test(player, transformEnvironment, canTransform);
				const doTransformation = werewolfFormSelected && (transformEnvironment || useAlwaysWolf) && canTransform;
				
				// Notify player if armor has blocked transformation
				if (morphEnabled && (transformEnvironment || (player.getDynamicProperty("ljw_ww:can_use_always_wolf") ?? false))) {
					if (!transformationBlockedByArmor && !equipmentOK) {
						player.setDynamicProperty("ljw_ww:transformation_blocked_by_armor", true);
						player.sendMessage({ translate: "ljw_ww.message.werewolf_transformation_blocked_by_armor", with: { rawtext: [ { text: "\n" }]} });
					}
					else if (transformationBlockedByArmor && equipmentOK) {
						player.setDynamicProperty("ljw_ww:transformation_blocked_by_armor", false);
					}
				}
				else if (transformationBlockedByArmor) {
					player.setDynamicProperty("ljw_ww:transformation_blocked_by_armor", false);
				}
				
				// Notify player if lunarburn has blocked transformation
				if (!hasEquipment && morphEnabled && werewolfFormSelected && (transformEnvironment || (player.getDynamicProperty("ljw_ww:can_use_always_wolf") ?? false))) {
					if (!transformationBlockedByLunarburn && !lunarburnOK) {
						player.setDynamicProperty("ljw_ww:transformation_blocked_by_lunarburn", true);
						player.sendMessage({ translate: "ljw_ww.message.werewolf_transformation_blocked_by_lunarburn", with: { rawtext: [ { text: "\n" }]} });
					}
					else if (transformationBlockedByLunarburn && lunarburnOK) {
						player.setDynamicProperty("ljw_ww:transformation_blocked_by_lunarburn", false);
					}
				}
				else if (transformationBlockedByLunarburn) {
					player.setDynamicProperty("ljw_ww:transformation_blocked_by_lunarburn", false);
				}
				
				if (hasEquipment) {
					// Ensure that the current transformation is what the player set
					// If not, refresh the transformation
					const durabilityComponent = headEquipment.getComponent('durability');
					if (durabilityComponent != null) {
						const id = parseInt(morphID);
						if (!isNaN(id) && (durabilityComponent.damage != id))
							refresh_transformation(player);
					}
					
					// Refresh transformation if new skill was learned
					if (player.getDynamicProperty(`ljw_ww:werewolf_ability_learned`) ?? false) {
						refresh_transformation(player);
						
						player.setDynamicProperty(`ljw_ww:werewolf_ability_learned`, false);
					}
				}
				
				// Wolfband halts transformation events 
				if (!hasWolfband || transformationOverride) {
					// Transform if necessary
					if (doTransformation && !hasEquipment) {
						debug.info(`Transforming ${player.nameTag} into werewolf...`);
						player.dimension.spawnParticle("ljw_ww:smokescreen", player.location);
						werewolf_sound(player, "transform_to_wolf");
						check_coat_config(player);
						
						// Lunarburn stops transformation healing
						if (lunarburnExposure == 0)
							system.runTimeout(() => {werewolf_regenerate(player);}, 3);
						
						// Store existing equipment, if any
						util.store_player_armor(player, "wolf_transformation");
						
						// Run transformation
						refresh_transformation(player);
						
						player.addTag("ljw_ww_werewolf");
					}
					
					// Un-transform if necessary
					if (!doTransformation && (hasEquipment || hasChestEquipment || hasLegEquipment || hasFeetEquipment)) {
						debug.info(`Transforming ${player.nameTag} to normal...`);
						player.dimension.spawnParticle("ljw_ww:smokescreen", player.location);
						werewolf_sound(player, "transform_to_normal");
						
						player.addEffect("invisibility", 10, {showParticles: false, amplifier: 255});
						
						const HPUPLevel = player.getDynamicProperty(`ljw_ww:werewolf_hp_up_setting`) ?? 0;
						if (HPUPLevel > 0) {
							if (player.getEffect("health_boost") != null) {
								const healthComponent = player.getComponent("health");
								const healthRatio = healthComponent.currentValue / healthComponent.effectiveMax;
								player.removeEffect("health_boost");
								healthComponent.setCurrentValue(healthComponent.effectiveMax * healthRatio);
							}
						}
						
						equipment.setEquipment("Head");
						equipment.setEquipment("Chest");
						equipment.setEquipment("Legs");
						equipment.setEquipment("Feet");
						util.restore_player_armor(player, "wolf_transformation");
						player.removeTag("ljw_ww_werewolf");
					}
				}
				else {
					const shouldBeActive = (doTransformation && !hasEquipment) || (!doTransformation && hasEquipment);
					
					if (shouldBeActive && !hasActiveWolfband) {
						const mainhandBand = (mainhandEquipment && (mainhandEquipment.hasTag("ljw_ww:wolfband")));
						const offhandBand = (offhandEquipment && (offhandEquipment.hasTag("ljw_ww:wolfband")));
						
						if (mainhandBand) {
							activate_wolfband(equipment, "Mainhand", mainhandEquipment);
						}
						if (offhandBand) {
							activate_wolfband(equipment, "Offhand", offhandEquipment);
						}
					}
					else if (!shouldBeActive && hasActiveWolfband) {
						const mainhandBand = (mainhandEquipment && (mainhandEquipment.hasTag("ljw_ww:wolfband")));
						const offhandBand = (offhandEquipment && (offhandEquipment.hasTag("ljw_ww:wolfband")));
						
						if (mainhandBand) {
							if (!deactivate_wolfband(equipment, "Mainhand", mainhandEquipment))
								player.dimension.playSound("random.break", player.location);
						}
						if (offhandBand) {
							if (!deactivate_wolfband(equipment, "Offhand", offhandEquipment))
								player.dimension.playSound("random.break", player.location);
						}
					}
				}
					
				if ((transformExtendTime != 0) && (transformInhibitTime == 0)) {
					player.setDynamicProperty("ljw_ww:transformation_extend_time", Math.max(0, transformExtendTime - 1));
				}
				
				if (transformInhibitTime != 0) {
					player.setDynamicProperty("ljw_ww:transformation_inhibit_time", Math.max(0, transformInhibitTime - 1));
					player.setDynamicProperty("ljw_ww:transformation_extend_time", 0);
				}
			}
		}
	}
	catch(err) {
		debug.error(`Transformation Check Error: ${err}`);
	}
}
system.runInterval(transformation_window_check, 5);

function werewolf_sound(player, sound) {
	const modifyableSounds = [ "bark", "hurt", "angry", "death" ];
	const modifyableWerewolfSounds = [ "growlhowl", "howl" ];
	let modifier = "";
	let soundPitch = 1.0;
	
	if (modifyableSounds.includes(sound)) {
		const config = player.getDynamicProperty("ljw_ww:werewolf_voice_profile_setting");
		if (config) {
			modifier = `${config}.`;
			soundPitch = 0.9;
		}
	}
	else if (modifyableWerewolfSounds.includes(sound)) {
		const config = player.getDynamicProperty("ljw_ww:werewolf_voice_profile_setting");
		if (config && !config.includes("wolf_")) {
			modifier = `${config}.`;
		}
	}
	
	player.dimension.playSound(`mob.ljw_ww.werewolf.${modifier}${sound}`, player.location, {pitch: soundPitch});
}

function refresh_transformation(player) {
	debug.info(`Updating ${player.nameTag}'s werewolf form...`);
	set_head_equipment(player);
	set_body_equipment(player);
	set_legs_equipment(player);
	set_feet_equipment(player);
}

function set_head_equipment(player) {
	try {
		const equipment = player.getComponent("equippable");
		const morphID = player.getDynamicProperty("ljw_ww:selected_werewolf_form") ?? 0;
		const divingMasteryLevel = player.getDynamicProperty(`ljw_ww:werewolf_diving_mastery_setting`) ?? 0;
		const defenseLevel = player.getDynamicProperty(`ljw_ww:werewolf_defense_up_setting`) ?? 0;
		
		// Head Equipment
		const headEquipment = new ItemStack(`ljw_ww:werewolf_transformation_head`);
		const durabilityComponent = headEquipment.getComponent('durability');
		if (durabilityComponent != null) {
			const id = parseInt(morphID);
			if (!isNaN(id))
				durabilityComponent.damage = id;
		}
		const enchantableComponent = headEquipment.getComponent('enchantable');
		if (enchantableComponent != null) {
			enchantableComponent.addEnchantment({type: enchants.vanishing, level: 1});
			
			if (defenseLevel >= 5)
				enchantableComponent.addEnchantment({type: enchants.protection, level: defenseLevel - 4});
			
			if (divingMasteryLevel > 0)
				enchantableComponent.addEnchantment({type: enchants.respiration, level: divingMasteryLevel});
			
			if (divingMasteryLevel >= 2)
				enchantableComponent.addEnchantment({type: enchants.aqua_affinity, level: 1});
		}
		headEquipment.lockMode = "slot";
		equipment.setEquipment("Head", headEquipment);
		system.runTimeout(() => {player.runCommand("stopsound @s armor.equip_generic");}, 1);
	}
	catch(err) {
		debug.error(`Head equipment error: ${err}`);
	}
}

function set_body_equipment(player) {
	try {
		const equipment = player.getComponent("equippable");
		const defenseLevel = player.getDynamicProperty(`ljw_ww:werewolf_defense_up_setting`) ?? 0;
		
		// Chest Equipment
		const chestEquipment = new ItemStack(`ljw_ww:werewolf_transformation_body_lv${Math.min(defenseLevel, 4)}`);
		const enchantableComponent = chestEquipment.getComponent('enchantable');
		if (enchantableComponent != null) {
			enchantableComponent.addEnchantment({type: enchants.vanishing, level: 1});
			
			if (defenseLevel >= 5)
				enchantableComponent.addEnchantment({type: enchants.protection, level: defenseLevel - 4});
		}
		chestEquipment.lockMode = "slot";
		equipment.setEquipment("Chest", chestEquipment);
		system.runTimeout(() => {player.runCommand("stopsound @s armor.equip_generic");}, 1);
	}
	catch(err) {
		debug.error(`Body equipment error: ${err}`);
	}
}

function set_legs_equipment(player, mode) {
	try {
		const equipment = player.getComponent("equippable");
		const speedStealthLevel = player.getDynamicProperty(`ljw_ww:werewolf_speed_stealth_setting`) ?? 0;
		const defenseLevel = player.getDynamicProperty(`ljw_ww:werewolf_defense_up_setting`) ?? 0;
		const trimSetting = player.getDynamicProperty(`ljw_ww:werewolf_trim_setting`) ?? 0;
		const trimMaterialSetting = player.getDynamicProperty(`ljw_ww:werewolf_trim_material_setting`) ?? 0;
		
		if ((mode != null) && mode.includes("howl")) {
			werewolf_sound(player, "growlhowl");
			player.playAnimation("animation.ljw_ww.werewolf_form.blank", {controller: "controller.animation.ljw_ww.werewolf_form.howl_action", nextState: "animation.ljw_ww.werewolf_form.action.howl_corrections", stopExpression: "q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') && (q.equipped_item_all_tags('slot.armor.legs', 'ljw_ww:werewolf_howl'))", blendOutTime: 0});
			player.playAnimation("animation.ljw_ww.werewolf_form.action.howl_corrections", {controller: "controller.animation.ljw_ww.werewolf_form.howl_action", nextState: "animation.ljw_ww.werewolf_form.blank", stopExpression: "!q.equipped_item_all_tags('slot.armor.head', 'ljw_ww:werewolf_form') || (!q.equipped_item_all_tags('slot.armor.legs', 'ljw_ww:werewolf_howl') && q.any_animation_finished)", blendOutTime: 0});
		}
		
		// Legs Equipment
		const legsEquipment = new ItemStack(`ljw_ww:werewolf_transformation_legs${mode != null ? "_" + mode : ""}`);
		const durabilityComponent = legsEquipment.getComponent('durability');
		if (durabilityComponent != null) {
			const trimSettingValue = parseInt(trimSetting) * 2;
			const trimMaterialSettingValue = parseInt(trimMaterialSetting) * 100;
			const armorData = trimSettingValue + trimMaterialSettingValue;
			if (!isNaN(armorData))
				durabilityComponent.damage = armorData;
		}
		const enchantableComponent = legsEquipment.getComponent('enchantable');
		if (enchantableComponent != null) {
			enchantableComponent.addEnchantment({type: enchants.vanishing, level: 1});
			
			if (defenseLevel >= 5)
				enchantableComponent.addEnchantment({type: enchants.protection, level: defenseLevel - 4});
			
			if (speedStealthLevel > 0)
				enchantableComponent.addEnchantment({type: enchants.swift_sneak, level: speedStealthLevel});
		}
		legsEquipment.lockMode = "slot";
		equipment.setEquipment("Legs", legsEquipment);
		system.runTimeout(() => {player.runCommand("stopsound @s armor.equip_generic");}, 1);
	}
	catch(err) {
		debug.error(`Legs equipment error: ${err}`);
	}
}

function set_feet_equipment(player) {
	try {
		const equipment = player.getComponent("equippable");
		const divingMasteryLevel = player.getDynamicProperty(`ljw_ww:werewolf_diving_mastery_setting`) ?? 0;
		const featherFallingLevel = player.getDynamicProperty(`ljw_ww:werewolf_feather_falling_setting`) ?? 0;
		const defenseLevel = player.getDynamicProperty(`ljw_ww:werewolf_defense_up_setting`) ?? 0;
		const armorSetting = player.getDynamicProperty(`ljw_ww:werewolf_armor_setting`) ?? 0;
		const armorTypeSetting = player.getDynamicProperty(`ljw_ww:werewolf_armor_type_setting`) ?? 0;
		const eyeColorSetting = player.getDynamicProperty(`ljw_ww:werewolf_eye_color_setting`) ?? 0;
		
		// Feet Equipment
		const feetEquipment = new ItemStack(`ljw_ww:werewolf_transformation_feet`);
		const durabilityComponent = feetEquipment.getComponent('durability');
		if (durabilityComponent != null) {
			const armorSettingValue = parseInt(armorSetting) * 2;
			const eyeColorSettingValue = parseInt(eyeColorSetting) * 1000;
			const armorTypeSettingValue = parseInt(armorTypeSetting) * 10;
			const armorData = armorSettingValue + armorTypeSettingValue + eyeColorSettingValue;
			if (!isNaN(armorData))
				durabilityComponent.damage = armorData;
		}
		const enchantableComponent = feetEquipment.getComponent('enchantable');
		if (enchantableComponent != null) {
			enchantableComponent.addEnchantment({type: enchants.vanishing, level: 1});
			
			if (defenseLevel >= 5)
				enchantableComponent.addEnchantment({type: enchants.protection, level: defenseLevel - 4});
			
			if (featherFallingLevel > 0)
				enchantableComponent.addEnchantment({type: enchants.feather_falling, level: featherFallingLevel});
			
			if (divingMasteryLevel > 0)
				enchantableComponent.addEnchantment({type: enchants.depth_strider, level: divingMasteryLevel});
		}
		feetEquipment.lockMode = "slot";
		equipment.setEquipment("Feet", feetEquipment);
		system.runTimeout(() => {player.runCommand("stopsound @s armor.equip_generic");}, 1);
	}
	catch(err) {
		debug.error(`Feet equipment error: ${err}`);
	}
}

function always_wolf_test(player, transformEnvironment, canTransform) {
	const usingAlwaysWolf = player.getDynamicProperty("ljw_ww:always_wolf_valid_day") == world.getDay();
	const morphEnabled = player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
	const alwaysWolfSetting = (player.getDynamicProperty(`ljw_ww:werewolf_always_wolf_setting`) ?? 0);
	const hasEnoughXP = (alwaysWolfSetting == 2) || (player.level >= 1);
	
	// Update flag
	player.setDynamicProperty("ljw_ww:can_use_always_wolf", hasEnoughXP && alwaysWolfSetting);
	
	// If unable to transform, don't use this either
	if (transformEnvironment || !canTransform) {
		return false;
	}
	
	// Test to see if ability can be used
	if (alwaysWolfSetting >= 1) {
		if (usingAlwaysWolf)
			return true;
		
		if (hasEnoughXP) {
			if (alwaysWolfSetting < 2) {
				player.addLevels(-1);
				player.playSound("random.orb", {pitch: 1.2 - Math.random() * 0.3});
			}
			player.setDynamicProperty("ljw_ww:always_wolf_valid_day", world.getDay());
			return true;
		}
		else
			return false;
	}
	
	return false;
}

function werewolf_regenerate(player) {
	if (player.getEffect("wither")) {
		player.sendMessage({ translate: "ljw_ww.message.regen_blocked_by_wither", with: { rawtext: [ { text: "\n" }]} });
		return;
	}
	
	const regenerationCharge = player.getDynamicProperty("ljw_ww:regeneration_charge") ?? 1.0;
	
	const healthComponent = player.getComponent("health");
	const currentHP = healthComponent.currentValue;
	const maxHP = healthComponent.effectiveMax;
	
	const healNeed = 1 - (currentHP / maxHP);
	const healAmount = Math.min(healNeed, regenerationCharge);
	
	healthComponent.setCurrentValue(Math.min(maxHP, currentHP + maxHP * healAmount));
	
	player.setDynamicProperty("ljw_ww:regeneration_charge", regenerationCharge - healAmount);
	debug.info(`Werewolf regen: ${currentHP} -> ${currentHP + maxHP * healAmount} | ${regenerationCharge} -> ${regenerationCharge - healAmount}`);
}

function cut_tree(player, startingBlock) {
	const maxNumBlocks = abilities.treeCutterMaxNumBlocks;
	try {
        // Check if the starting block is valid and is a log
        if (!startingBlock || !abilities.is_tree_cutter_block(startingBlock)) {
            return;
        }

        // Store blocks to break and blocks we've checked
        const blocksToBreak = [];
        const checkedBlocks = new Set();
		let isNaturalTree = false;
		let blockSum = 0;
        
        // Check if the tree is rooted in natural ground
        function check_tree_base(block) {
            let currentBlock = block;
			
			for (let y = block.y; y >= currentBlock.dimension.heightRange.min; y--) {
                currentBlock = block.dimension.getBlock({ x: block.x, y, z: block.z });
                if (!currentBlock) {
                    break;
                }
                
				if (abilities.is_tree_cutter_ground_block(currentBlock)) {
                    startingBlock = currentBlock.above();
					isNaturalTree = true;
                    break;
                }
                if (!abilities.is_tree_cutter_block(currentBlock)) {
					break; // Hit non-log block before ground
                }
            }
            return isNaturalTree;
        }

        // Function to recursively find connected logs
        function find_connected_logs(block) {
			if (!block || checkedBlocks.has(`${block.x},${block.y},${block.z}`) || (blockSum > maxNumBlocks)) {
                return;
            }

            checkedBlocks.add(`${block.x},${block.y},${block.z}`);
			
			const range = 1;
			if (abilities.is_tree_cutter_block(block)) {
				blocksToBreak.push(block);
				
				if (block.typeId.includes("mushroom")) {
					blockSum += 0.5;
				}
				else {
					blockSum += 1.0;
				}
				
                for (let x = -1 * range; x <= range; x += 1) {
					for (let y = -1 * range; y <= range; y += 1) {
						for (let z = -1 * range; z <= range; z += 1) {
							const nextBlock = block.dimension.getBlock({ x: block.x + x, y: block.y + y, z: block.z + z });
							find_connected_logs(nextBlock);
						}
					}
				}
            }
        }

        // Verify this is likely a natural tree
        if (check_tree_base(startingBlock)) {
			// Start the recursive search
			find_connected_logs(startingBlock);
        }
		else if (abilities.is_tree_cutter_block(startingBlock)) {
			blocksToBreak.push(startingBlock);
		}
		
		// Break all found log blocks with a slight delay for effect
		if (blockSum < maxNumBlocks) {
			let delay = 0;
			for (const block of blocksToBreak) {
				system.runTimeout(() => {
					// Check if block still exists and is a log
					const currentBlock = block.dimension.getBlock(block.location);
					if (currentBlock && abilities.is_tree_cutter_block(currentBlock)) {
						currentBlock.dimension.runCommand(`fill ${currentBlock.x} ${currentBlock.y} ${currentBlock.z} ${currentBlock.x} ${currentBlock.y} ${currentBlock.z} air [] destroy`);
					}
				}, delay);
				delay += 2; // Increase delay by 2 ticks for each block (adjust as needed)
			}
		}
		else {
			player.sendMessage({ translate: "ljw_ww.message.tree_cutter_too_many_blocks", with: { rawtext: [ { text: "\n" }]} })
		}
    }
	catch (error) {
        debug.error(`Werewolf Tree Cutter Error: ${error}`);
    }
}

function scent_tracker(player) {
	try {
		const trackDialog = new ActionFormData();
		const itemTrackExperimentEnabled = world.getDynamicProperty("ljw_ww:item_tracking_experiment") ?? false;
		trackDialog.title({ translate: `ljw_ww.scent_track_window.main.title` });
		trackDialog.body({ translate: `ljw_ww.scent_track_window.main.body`, with: { rawtext: [ { text: "\n" }]} });
		
		trackDialog.button({ translate: "ljw_ww.scent_track_window.main.button.learn", with: { rawtext: [ { text: "\n" }]} });
		trackDialog.button({ translate: "ljw_ww.scent_track_window.main.button.find_entity", with: { rawtext: [ { text: "\n" }]} });
		
		if (itemTrackExperimentEnabled)
			trackDialog.button({ translate: "ljw_ww.scent_track_window.main.button.find_item", with: { rawtext: [ { text: "\n" }]} });
		
		
		const currentTarget = player.getDynamicProperty("ljw_ww:scent_tracker_target");
		if (currentTarget == "minecraft:player") {
			trackDialog.button({ translate: "ljw_ww.scent_track_window.main.button.cancel", with: { rawtext: [ { text: "\n" }, { text: `${player.getDynamicProperty("ljw_ww:scent_tracker_player_target")}`}]} });
		}
		else if (currentTarget != null) {
			trackDialog.button({ translate: "ljw_ww.scent_track_window.main.button.cancel", with: { rawtext: [ { text: "\n" }, { translate: `entity.${currentTarget.replace("minecraft:", "")}.name`}]} });
		}
		
		//trackDialog.button("Reset");
		
		trackDialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					scent_tracker_learn(player);
				else if (response.selection == 1)
					scent_tracker_track_entity_init(player);
				else if (!itemTrackExperimentEnabled && (response.selection == 2))
					player.setDynamicProperty("ljw_ww:scent_tracker_target");
				else if (itemTrackExperimentEnabled && (response.selection == 2))
					scent_tracker_track_item_init(player);
				else if (itemTrackExperimentEnabled && (response.selection == 3))
					player.setDynamicProperty("ljw_ww:scent_tracker_target");
			}
		});
	}
	catch (err) {
		debug.error(`Explanation Error: ${err}`)
	}
}

function scent_tracker_learn(player) {
	try {
        const nearbyEntities = player.dimension.getEntities({location: player.location, excludeFamilies: ["inanimate", "ljw_ww:noTrack"], maxDistance: 20});
        
        // Get existing entity types from DynamicProperty (or empty string if none)
        const existingTypes = player.getDynamicProperty("ljw_ww:scent_tracker_record") || "";
        let entityTypeSet = new Set(existingTypes.split(";").filter(type => type !== ""));
        let newEntityFound = false;
		
		// Get existing player names from DynamicProperty (or empty string if none)
        const existingPlayers = player.getDynamicProperty("ljw_ww:player_scent_tracker_record") || "";
        let playerNameSet = new Set(existingPlayers.split(";").filter(type => type !== ""));
        let newPlayerFound = false;
		
		// Get existing item types from DynamicProperty (or empty string if none)
        const existingItems = player.getDynamicProperty("ljw_ww:item_scent_tracker_record") || "";
        let itemNameSet = new Set(existingItems.split(";").filter(type => type !== ""));
        let newItemFound = false;
		const itemTrackExperimentEnabled = world.getDynamicProperty("ljw_ww:item_tracking_experiment") ?? false;
		
        // Add new entity types to the set (duplicates are automatically handled by Set)
        for (const entity of nearbyEntities) {
			if (entity == player)
				continue;
			
			if (entity.typeId == "minecraft:player") {
				if (!playerNameSet.has(entity.nameTag)) {
					player.sendMessage({ translate: "ljw_ww.message.scent_track.found_new_player", with: { rawtext: [ { text: "\n" }, { text: `${entity.nameTag}` }]} });
					playerNameSet.add(entity.nameTag);
					newPlayerFound = true;
					debug.info(`${player.nameTag} can now track ${entity.nameTag}`);
				}
			}
			else if (entity.typeId == "minecraft:item") {
				if (!itemTrackExperimentEnabled) {
					continue;
				}
				
				const component = entity.getComponent("item");
				if (component != null) {
					const itemType = component.itemStack.typeId;
					
					if (!itemNameSet.has(itemType)) {
						if (!newItemFound)
							player.sendMessage({ translate: "ljw_ww.message.scent_track.found_new_item", with: { rawtext: [ { text: "\n" } ]} });
						
						itemNameSet.add(itemType);
						newItemFound = true;
						debug.info(`${player.nameTag} can now track ${itemType}`);
					}
				}
				else {
					continue;
				}
			}
			else if (!entityTypeSet.has(entity.typeId)) {
				player.sendMessage({ translate: "ljw_ww.message.scent_track.found_new_entity", with: { rawtext: [ { text: "\n" }, { translate: `entity.${entity.typeId.replace("minecraft:", "")}.name`}]} });
				entityTypeSet.add(entity.typeId);
				newEntityFound = true;
				debug.info(`${player.nameTag} can now track ${entity.typeId}`);
            }
        }
        
		
        // Convert Sets back to semicolon-separated strings
		if (newEntityFound) {
			const updatedTypes = Array.from(entityTypeSet).sort((a, b) => a.localeCompare(b)).join(";");
			player.setDynamicProperty("ljw_ww:scent_tracker_record", updatedTypes);
			//debug.info(`${player.nameTag}'s tracked entity types: ${updatedTypes || "none"}`);
		}
		if (newPlayerFound) {
			const updatedTypes = Array.from(playerNameSet).sort((a, b) => a.localeCompare(b)).join(";");
			player.setDynamicProperty("ljw_ww:player_scent_tracker_record", updatedTypes);
		}
		if (newItemFound) {
			const updatedTypes = Array.from(itemNameSet).sort((a, b) => a.localeCompare(b)).join(";");
			player.setDynamicProperty("ljw_ww:item_scent_tracker_record", updatedTypes);
		}
		
		if (!newEntityFound && !newPlayerFound && !newItemFound) {
			player.sendMessage({ translate: "ljw_ww.message.scent_track.found_nothing", with: { rawtext: [ { text: "\n" }]} });
		}
	}
	catch (error) {
		debug.error(`Scent learn error: ${error.message}`);
	}
}

function scent_tracker_track_entity_init(player) {
	try {
        const knownTypesString = player.getDynamicProperty("ljw_ww:scent_tracker_record") || "";
        const knownTypes = knownTypesString.split(";").filter(type => type !== "");
        const knownPlayersString = player.getDynamicProperty("ljw_ww:player_scent_tracker_record") || "";
        const knownPlayers = knownPlayersString.split(";").filter(type => type !== "");
        
        if ((knownTypes.length == 0) && (knownPlayers.length == 0)) {
            player.sendMessage({ translate: "ljw_ww.message.scent_track.none_found_yet", with: { rawtext: [ { text: "\n" }]} });
            return;
        }
        
        const trackDialog = new ActionFormData();
		trackDialog.title({ translate: "ljw_ww.scent_track_window.main.button.find_entity", with: { rawtext: [ { text: "\n" }]} })
        trackDialog.body({ translate: `ljw_ww.scent_track_window.find_mob.body`, with: { rawtext: [ { text: "\n" }]} });
        
        for (const type of knownTypes) {
            trackDialog.button({ translate: `ljw_ww.scent_track_window.find_mob.button`, with: { rawtext: [ { text: "\n" }, { translate: `entity.${type.replace("minecraft:", "")}.name`}, {text: `${type.split(":")[0]}`}]} });
		}
        for (const name of knownPlayers) {
            trackDialog.button({ text: `${name}`});
		}
        
        trackDialog.show(player).then((response) => {
            if (response?.selection != null) {
				if (response.selection < knownTypes.length) {
					player.setDynamicProperty("ljw_ww:scent_tracker_target", knownTypes[response.selection]);
				}
				else {
					player.setDynamicProperty("ljw_ww:scent_tracker_target", "minecraft:player");
					player.setDynamicProperty("ljw_ww:scent_tracker_player_target", knownPlayers[response.selection - knownTypes.length]);
				}
            }
        }).catch((err) => {
            debug.error(`Track mob window error: ${err}`);
        });
    }
	catch (err) {
        debug.error(`Track mob init error: ${err}`);
    }
}

function scent_tracker_track_item_init(player) {
	try {
        const knownTypesString = player.getDynamicProperty("ljw_ww:item_scent_tracker_record") || "";
        const knownTypes = knownTypesString.split(";").filter(type => type !== "");
        
        if (knownTypes.length == 0) {
            player.sendMessage({ translate: "ljw_ww.message.scent_track.no_items_found_yet", with: { rawtext: [ { text: "\n" }]} });
            return;
        }
        
        const trackDialog = new ActionFormData();
		trackDialog.title({ translate: "ljw_ww.scent_track_window.main.button.find_item", with: { rawtext: [ { text: "\n" }]} })
        trackDialog.body({ translate: `ljw_ww.scent_track_window.find_item.body`, with: { rawtext: [ { text: "\n" }]} });
        
        for (const type of knownTypes) {
            trackDialog.button({ translate: `ljw_ww.scent_track_window.find_mob.button`, with: { rawtext: [ { text: "\n" }, { translate: `item.${type.replace("minecraft:", "")}.name`}, {text: `${type.split(":")[0]}`}]} });
		}
        
        trackDialog.show(player).then((response) => {
            if (response?.selection != null) {
				player.setDynamicProperty("ljw_ww:scent_tracker_target", "minecraft:item");
				player.setDynamicProperty("ljw_ww:scent_tracker_item_target", knownTypes[response.selection]);
            }
        }).catch((err) => {
            debug.error(`Track item window error: ${err}`);
        });
    }
	catch (err) {
        debug.error(`Track item init error: ${err}`);
    }
}

function scent_tracker_track(player) {
	try {
        const targetType = player.getDynamicProperty("ljw_ww:scent_tracker_target") || "";
		if (!targetType || (targetType.length === 0))
			return;
		
		if (targetType == "minecraft:player") {
			const playerName = player.getDynamicProperty("ljw_ww:scent_tracker_player_target") || "";
			if (!playerName || (playerName.length === 0)) {
				debug.warn("Tracking a player without name! Cancelling.");
				player.setDynamicProperty("ljw_ww:scent_tracker_target");
			}
			
			// Get matching player
			const nearbyPlayers = player.dimension.getPlayers({location: player.location, name: playerName, minDistance: 1, maxDistance: 32, closest:1});
			if (nearbyPlayers[0] != null) {
				const entity = nearbyPlayers[0];
				try {
					// Create marker entity
					player.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.scent_track.found_player", with: { rawtext: [ { text: "\n" }, { text: `${playerName}`}]} });
					const marker = entity.dimension.spawnEntity("ljw_ww:marker", {x: entity.location.x, y: entity.location.y + 0.5, z: entity.location.z});
					system.runTimeout(() => {if ((marker != null) && marker.isValid()) marker.playAnimation("animation.ljw_ww.marker.activate", {controller: "controller.animation.ljw_ww.marker", nextState: "animation.ljw_ww.marker.activate", players: [`${player.nameTag}`], stopExpression: "0"});}, 5);
				}
				catch (err) {
					debug.warn(`Marker Error for ${entity.typeId}: ${err}`);
				}
			}
		}
		else if (targetType == "minecraft:item") {
			const itemType = player.getDynamicProperty("ljw_ww:scent_tracker_item_target") || "";
			if (!itemType || (itemType.length === 0)) {
				debug.warn("Tracking an item without id! Cancelling.");
				player.setDynamicProperty("ljw_ww:scent_tracker_target");
			}
			
			// Get matching items
			const nearbyItems = player.dimension.getEntities({location: player.location, type: "minecraft:item", minDistance: 1, maxDistance: 32});
			if (nearbyItems.length > 0) {
				for (const entity of nearbyItems) {
					const component = entity.getComponent("item");
					if (component != null) {
						const type = component.itemStack.typeId;
					
						if (type == itemType) {
							try {
								// Create marker entity
								player.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.scent_track.found_item", with: { rawtext: [ { text: "\n" }]} });
								const marker = entity.dimension.spawnEntity("ljw_ww:marker", {x: entity.location.x, y: entity.location.y + 0.5, z: entity.location.z});
								system.runTimeout(() => {if ((marker != null) && marker.isValid()) marker.playAnimation("animation.ljw_ww.marker.activate", {controller: "controller.animation.ljw_ww.marker", nextState: "animation.ljw_ww.marker.activate", players: [`${player.nameTag}`], stopExpression: "0"});}, 5);
							}
							catch (err) {
								debug.warn(`Marker Error for ${entity.typeId}: ${err}`);
							}
							break;
						}
					}
				}
			}
		}
		else {
			// Get matching entities
			const nearbyEntities = player.dimension.getEntities({location: player.location, type: targetType, minDistance: 1, maxDistance: 32, closest:1});
			if (nearbyEntities[0] != null) {
				const entity = nearbyEntities[0];
				try {
					// Create marker entity
					player.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.scent_track.found_mob", with: { rawtext: [ { text: "\n" }, { translate: `entity.${entity.typeId.replace("minecraft:", "")}.name`}]} });
					const marker = entity.dimension.spawnEntity("ljw_ww:marker", {x: entity.location.x, y: entity.location.y + 0.5, z: entity.location.z});
					system.runTimeout(() => {if ((marker != null) && marker.isValid()) marker.playAnimation("animation.ljw_ww.marker.activate", {controller: "controller.animation.ljw_ww.marker", nextState: "animation.ljw_ww.marker.activate", players: [`${player.nameTag}`], stopExpression: "0"});}, 5);
				}
				catch (err) {
					debug.warn(`Marker Error for ${entity.typeId}: ${err}`);
				}
			}
		}
    }
	catch (err) {
        debug.error(`Scent Track Error: ${err}`);
    }
}

function scent_tracker_cleanup(player) {
	try {
        const existingTypes = player.getDynamicProperty("ljw_ww:scent_tracker_record") || "";
        if (!existingTypes) {
            return;
        }

        let entityTypeSet = new Set(existingTypes.split(";").filter(type => type !== ""));
        const validatedTypes = new Set();
		
		for (const typeId of entityTypeSet) {
            if (allEntityTypes.some(entityType => entityType.id === typeId)) {
                validatedTypes.add(typeId);
            }
			else {
                debug.info(`Removed invalid entity scent id from ${player.nameTag}: ${typeId}`);
            }
        }

        if (validatedTypes.size !== entityTypeSet.size) {
            const sortedTypes = Array.from(validatedTypes).sort((a, b) => a.localeCompare(b)).join(";");
            player.setDynamicProperty("nearbyEntityTypes", sortedTypes);
        }
    }
	catch (err) {
        debug.error(`Track List cleanup error: ${err}`);
    }
}

function wolf_roster_check() {
	for (const player of playerList) {
		if (!player.isValid()) {
			continue;
		}
		const form = player.getDynamicProperty("ljw_ww:form") ?? "normal";
		const packLeaderSetting = player.getDynamicProperty("ljw_ww:werewolf_pack_leader_setting") ?? 0;
		
		if ((form == "wolf") && (packLeaderSetting > 0)) {
			for (const wolf of player.dimension.getEntities({families: [ "wolf" ], location: player.location, maxDistance: 8})) {
				try {
					const tamedComponent = wolf.getComponent("is_tamed");
					if (tamedComponent != null) {
						if (wolf.getEffect("strength") == null) {
							wolf.addEffect("strength", 110, {showParticles: false, amplifier: 1});
						}
						const healthComponent = wolf.getComponent("health");
						healthComponent.setCurrentValue(Math.min(healthComponent.effectiveMax, healthComponent.currentValue + (healthComponent.effectiveMax * 0.05)));
						wolf.dimension.spawnParticle("ljw_ww:moonglow_sprig_sparkle", {x: wolf.location.x, y: wolf.location.y + 0.5, z: wolf.location.z})
					}
				}
				catch(err) {
					debug.warn(`Wolf Sync Error: ${err}`);
				}
			}
		}
	}
}
system.runInterval(wolf_roster_check, 100);

function lunarburn_recovery_tick() {
	for (const player of playerList) {
		if (!player.isValid()) {
			continue;
		}
		
		const lunarburnExposure = player.getDynamicProperty("ljw_ww:lunarburn_exposure") ?? 0;
		if (lunarburnExposure > 0) {
			const exposureRating = Math.ceil(10 * lunarburnExposure/data.lunarburnExposureMax[1]);
			const effectThreshold = data.lunarburnExposureEffectThreshold / 10 + 1;
			const warningThreshold = data.lunarburnExposureHazardThreshold / 10 + 1;
			const dangerThreshold = data.lunarburnExposureDangerThreshold / 10 + 1;
			const colorModifier = exposureRating >= dangerThreshold ? "§u" : exposureRating >= warningThreshold ? "§c" : exposureRating >= effectThreshold ? "§e" : "";
			const bar = `§l${colorModifier}${markerFilled.repeat(util.clamp(exposureRating,0,10))}${markerEmpty.repeat(util.clamp(10 - exposureRating,0,10))}§r`;
			system.run(() => {player.onScreenDisplay.setActionBar({ translate: "ljw_ww.action_bar.lunarburn_exposure", with: { rawtext: [ { text: "\n" }, { text: bar }]} });});
			player.setDynamicProperty("ljw_ww:lunarburn_exposure", Math.max(0, lunarburnExposure - 2));
			player.dimension.spawnParticle("ljw_ww:lunarburn_effect", {x: player.location.x, y: player.location.y + 1, z: player.location.z})
		}
	}
}
system.runInterval(lunarburn_recovery_tick, 20);

const slotList = [];
function inventory_check() {
	for (const player of playerList) {
		try {
			if (!player.isValid()) {
				continue;
			}
			const inventory = player.getComponent("inventory").container;
			for (let i = 0; i < inventory.size; i += 1) {
				const slot = inventory.getSlot(i);
				
				if (!slot.hasItem() || !slot.hasTag("ljw_ww:werewolf_ability"))
					continue;
				
				const slotInstance = { id: `${player.id}.${i}`, slot, player };
				const checkMap = new Map(slotList.map(item => [item.id, item]));
				if (!checkMap.has(slotInstance.id)) {
					slotList.push(slotInstance);
				}
			}
		}
		catch(err) {
			debug.warn(`Inventory Check Error: ${err}`);
		}
    }
}
system.runInterval(inventory_check, 40);

function update_werewolf_items() {
	for (let i = 0; i < slotList.length; i +=1) {
		try {
			const slotInstance = slotList[i];
			const player = slotInstance.player;
			const slot = slotInstance.slot;
			let invalid = false;
			
			invalid = !player.isValid();
			invalid = invalid || !slot.hasItem();
			invalid = invalid || !slot.hasTag("ljw_ww:werewolf_ability");
			
			if (!invalid) {
				try {
					//debug.info(`Tick ${slot.typeId}`);
					const itemStack = slot.getItem();
					const durabilityComponent = itemStack.getComponent('durability');
					if (durabilityComponent != null) {
						const damage = durabilityComponent.damage;
						const abilityId = slot.typeId.replace("ljw_ww:ability_", "");
						if (abilityId == "lunar_leap") {
							durabilityComponent.damage = player.isOnGround ? 0 : 100;
							slot.setItem(itemStack);
						}
						else if (abilityId == "mining_claw") {
							const miningStamina = player.getDynamicProperty("ljw_ww:mining_stamina") ?? abilities.miningStaminaMax;
							durabilityComponent.damage = 100 - (100 * miningStamina / abilities.miningStaminaMax);
							slot.setItem(itemStack);
						}
						else if (abilityId == "pack_mender") {
							const regenCharge = player.getDynamicProperty("ljw_ww:regeneration_charge") ?? 1.0;
							durabilityComponent.damage = 100 - (100 * regenCharge);
							slot.setItem(itemStack);
						}
						else {
							const rechargeTime = abilities.list[abilityId].rechargeTime ?? 0;
							if (rechargeTime == 0)
								continue;
							
							const useTime = player.getDynamicProperty(`ljw_ww:ability_use_time_${abilityId}`) ?? 0;
							if ((useTime == 0) && (damage == 0))
								continue;
							else if (useTime == 0) {
								durabilityComponent.damage = 0;
								slot.setItem(itemStack);
							}
							else {
								const time = Date.now();
								const rechargeAmount = 100 - Math.min(Math.floor(((time - useTime) / rechargeTime) * 100), 100);
								durabilityComponent.damage = rechargeAmount;
								if (time >= (useTime + rechargeTime)) {
									player.setDynamicProperty(`ljw_ww:ability_use_time_${abilityId}`);
								}
								slot.setItem(itemStack);
							}
						}
					}
				}
				catch(err) {
					debug.error(`Slot update error: ${err}`);
					slotList.splice(i ,1);
				}
			}
			else {
				//debug.info(`Removing invalid slot..`)
				slotList.splice(i ,1);
			}
		}
		catch(err) {
			debug.error(`Slot check error: ${err}`);
		}
    }
}
system.runInterval(update_werewolf_items, 5);

function regeneration_charge_recharge_tick() {
	for (const player of playerList) {
		try {
			if (!player.isValid()) {
				continue;
			}
			
			const regenerationCharge = player.getDynamicProperty("ljw_ww:regeneration_charge") ?? 1.0;
			
			// Recover regeneration charge over time
			if (regenerationCharge < 1.0) {
				player.setDynamicProperty("ljw_ww:regeneration_charge", Math.min(regenerationCharge + 0.017, 1.0));
			}
		}
		catch(err) {
			debug.warn(`Regen Recharge Error: ${err}`);
		}
	}
}
system.runInterval(regeneration_charge_recharge_tick, 200);

function fallproof_check() {
    for (const player of playerList) {
		try {
			if (!player.isValid()) {
				continue;
			}
			
			const hasEffect = player.getDynamicProperty(`ljw_ww:fallproof`) ?? false;
			
			if (!hasEffect) {
				continue;
			}
			
			if (player.isOnGround) {
				player.setDynamicProperty(`ljw_ww:fallproof`, false);
			}
			else {
				player.addEffect('slow_falling', 2, { amplifier: 200, showParticles: false });
			}
		}
		catch(err) {
			debug.warn(`Fallproof Check error: ${err}`);
		}
    }
}
system.runInterval(fallproof_check, 3);

function check_coat_config(player) {
	try {
		const config = player.getDynamicProperty("ljw_ww:werewolf_form_list");
		
		if (config) {
			return;
		}
		
		const checkData = check_biome_variant(player);
		const variant = checkData.variant;
		
		if (variant == 0) {
			player.setDynamicProperty("ljw_ww:werewolf_form_list", `000;`);
			player.setDynamicProperty("ljw_ww:selected_werewolf_form", 0);
		}
		else {
			player.setDynamicProperty("ljw_ww:werewolf_form_list", `${variant * 100};`);
			player.setDynamicProperty("ljw_ww:selected_werewolf_form", variant * 100);
		}
	}
	catch(err) {
		debug.warn(`Coat Config Check Error: {$err}`)
	}
}

function check_biome_variant(player) {
	try {
		const checkBlock = player.dimension.spawnEntity("ljw_ww:check_block", player.location);
		const variantComponent = checkBlock.getComponent("variant");
		const taigaDetected = checkBlock.getProperty("ljw_ww:in_taiga") ?? false;
		let variant = 0;
		if (variantComponent) {
			variant = variantComponent.value;
		}
		
		checkBlock.remove();
		return {taigaDetected, variant};
	}
	catch(err) {
		debug.warn(`Variant check error: ${err}`);
		return {taigaDetected: false, variant: 0};
	}
}

function test_werewolf_durbility_loss(player, itemStack) {
	if (!itemStack) {
		return;
	}
	const durabilityComponent = itemStack.getComponent('durability');
	
	if (durabilityComponent) {
		const dexterityLevel = player.getDynamicProperty("ljw_ww:werewolf_dexterity_setting") ?? 0;
		const penaltyChance = abilities.baseDurabilityPenalty - 1 - (dexterityLevel * abilities.durabilityPenaltyRecoveredPerLevel);
		const durabilityPenaltyApplies = Math.random() <= penaltyChance;
		const damageAmount = durabilityComponent.damage;
		
		if (durabilityPenaltyApplies && (damageAmount > 0)) {
			const damagePenalty = abilities.werewolfDurabilityPenalty;
			durabilityComponent.damage = Math.min(durabilityComponent.damage + damagePenalty, durabilityComponent.maxDurability);
			player.getComponent("equippable").setEquipment("Mainhand", itemStack);
			
			debug.info(`${damageAmount} | ${penaltyChance} | ${damagePenalty} | ${damageAmount + damagePenalty} | ${durabilityComponent.damage + damagePenalty}`);
		}
	}
}

function apply_werewolf_durbility_loss(player, itemStack) {
	const durabilityComponent = itemStack.getComponent('durability');
	if (durabilityComponent != null) {
		const beforeDamage = player.getDynamicProperty("ljw_ww:durability_before");
		if (!beforeDamage) {
			return;
		}
		
		debug.info(`After: ${durabilityComponent.damage}`);
	}
}

function full_moon_check(entity) {
    try {
        // Check if entity is in the Overworld
        if (entity.dimension.id !== "minecraft:overworld") {
            return false;
        }
		
		// Check does not apply if entity is not a werewolf
		const isWerewolf = entity.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
		if (!isWerewolf) {
			return false;
		}

        // Get the current time of day (0-23999, where 13000-23999 is night)
        const timeOfDay = world.getTimeOfDay();
        const isNightSoon = timeOfDay >= 12000;
        const isNight = timeOfDay >= 13000 && timeOfDay < 24000;

        // Get the moon phase (0-7, where 0 is full moon)
        const moonPhase = world.getMoonPhase();
        const isFullMoon = moonPhase === 0;
		
		// Inform Player that full moon is rising
		const fullMoonNotified = entity.getDynamicProperty("ljw_ww:notified_full_moon") ?? false;
        if (!isNight && isNightSoon && isFullMoon && !fullMoonNotified) {
			entity.onScreenDisplay.setActionBar({ translate: "ljw_ww.message.full_moon_warning", with: { rawtext: [ { text: "\n" }]} });
			entity.setDynamicProperty("ljw_ww:notified_full_moon", true);
		}
		else if (!(!isNight && isNightSoon && isFullMoon) && fullMoonNotified) {
			entity.setDynamicProperty("ljw_ww:notified_full_moon", false);
		}
		
		// Return true only if both conditions are met
        return isNight && isFullMoon;
    } 
	catch (error) {
        debug.warn(`Full moon check error: ${error}`);
        return false;
    }
}

function check_riding(player) {
    try {
		const radius = 5;
		
        // Find nearby entities with the rideable component. Exclude players to optimize
        const nearbyEntities = player.dimension.getEntities({ location: player.location, maxDistance: radius, excludeTypes: ["minecraft:player"] });

        // Check each entity for the rideable component and if the player is a rider
        for (const entity of nearbyEntities) {
            const rideableComponent = entity.getComponent("minecraft:rideable");
            if (rideableComponent && rideableComponent.getRiders().some(rider => rider.id === player.id)) {
                return {
                    isRiding: true,
                    riddenEntity: entity
                };
            }
        }

        // If no ridden entity is found, return false
        return {
            isRiding: false
        };
    }
	catch (err) {
        console.error("Error checking riding status:", error);
        return {
            isRiding: false
        };
    }
}