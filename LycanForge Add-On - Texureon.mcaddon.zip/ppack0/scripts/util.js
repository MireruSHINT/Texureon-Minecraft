import {world, system, MinecraftDimensionTypes, BlockPermutation, BlockSignComponent} from "@minecraft/server";
import * as debug from "debug_functions.js"

// Tool code
export const clamp = (num, min, max) => Math.min(Math.max(num, min), max);
export const revolve = (num, limit) => Math.abs(num) > Math.abs(limit) ? (num > 0 ? limit - (num % limit) : limit*-1 - (num % limit*-1)) : num;
export const distance2D = (locA, locB) => ((((locB.x - locA.x) ** 2) + ((locB.y - locA.y) ** 2)) ** 1/2);
export const distance2Dz = (locA, locB) => ((((locB.x - locA.x) ** 2) + ((locB.z - locA.z) ** 2)) ** 1/2);
export const distance3D = (locA, locB) => ((((locB.x - locA.x) ** 2) + ((locB.y - locA.y) ** 2) + ((locB.z - locA.z) ** 2)) ** 1/2);
export const camelToSnakeCase = str => str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
export const view_rot_to_dir = (viewRot) => ({x: -1 * Math.sin(viewRot.y * (Math.PI) / 180), y: -1 * viewRot.x / 90, z: Math.cos(viewRot.y * (Math.PI) / 180)});
export function parse_location(input) {
	// Fail if loc is empty
	if (input.length < 1)
		throw new Error("Error: parse_location requires a location of the format x,y,z");
	
	const coordinates = input.split(",");
	
	// Fail if we didn't get 3 items
	if (coordinates.length != 3)
		throw new Error("Error: parse_location requires a location of the format x,y,z");
	
	// Create return location
	const loc = {x: parseFloat(coordinates[0]), y: parseFloat(coordinates[1]), z: parseFloat(coordinates[2])};
	
	// Fail if a value isn't a number
	if (isNaN(loc.x))
		throw new Error(`Error: Provided x coordinate is invalid: ${coordinates[0]}`);
	if (isNaN(loc.y))
		throw new Error(`Error: Provided y coordinate is invalid: ${coordinates[1]}`);
	if (isNaN(loc.z))
		throw new Error(`Error: Provided y coordinate is invalid: ${coordinates[2]}`);
	
	// Return location
	return loc;
}
export const analyze = (obj) => {
	// Utility for analyzing objects.
	let properties = new Set()
	Object.getOwnPropertyNames(obj).map(item => properties.add(item))
	
	let currentObj = obj
	while ((currentObj = Object.getPrototypeOf(currentObj))) 
	{
		Object.getOwnPropertyNames(currentObj).map(item => properties.add(item))
	} 
	return [...properties.keys()]
}
export function getAllSubclasses(baseClass) {
	var allVars = Object.keys(world);
	var classes = allVars.filter(function (key) {
		try {
			var obj = world[key];
			return obj.prototype instanceof baseClass;
		}
		catch (e) 
		{
			console.warn(`Get classes error: ${err}`)
			return false;
		}
	});
	return classes;
}
export function getEntities(dimension, options) {
	if (options == null)
		options = {};
	
	let list = [];
	
	try {
		if (dimension == "all")
		{
			for (let dimension in MinecraftDimensionTypes) {
				list = [ ...list, ...world.getDimension(camelToSnakeCase(dimension)).getEntities(options)]
			};
		}
		else
			list = dimension.getEntities(options);
	}
	catch (err)
	{
		console.warn(`Get entities error: ${err}`)
	}
	return list
}
export function list_entity_components() {
	world.sendMessage(JSON.stringify(world.getDimension("overworld").getEntities().reduce((o, e) => {
		o[e.typeId.replace('minecraft:', '')] = e.getComponents().map(c => c?.typeId.substring(10))
		return o
	}, {}), null, 3));
}
export function directionInvert(dir) {
	switch (dir) {
		case "North":
			return "South";
		case "South":
			return "North";
		case "East":
			return "West";
		case "West":
			return "East";
		case "Up":
			return "Down";
		case "Down":
			return "Up";
		default:
			return "North";
	}
}
export function directionDetect(entity) {
	const direction = entity.getRotation().y;
	
	if ((direction >= -45) && (direction < 45))
		return "South";
	else if ((direction >= 45) && (direction < 135))
		return "West";
	else if ((direction >= 135) || (direction < -135))
		return "North";
	else if ((direction >= -135) && (direction < -45))
		return "East";
}
export function countItem(player, type) {
	const container = player.getComponent("inventory").container;
	const size = container.size;
	let total = 0;
	for (let i = 0; i < size; i++) {
		const itemInSlot = container.getItem(i);
		if (itemInSlot?.typeId != type) continue; // If not correct item, skip
		else total += itemInSlot?.amount; // If correct item, increment total by num of items.
	}
	return total;
}
export function decrement_item(entity, type, count = 1) {
	const inventory = entity.getComponent("inventory");
	
	if (inventory == null)
		return;
	
	const container = inventory.container;
	const size = container.size;
	let total = count;
	for (let i = 0; i < size; i++) {
		if (total == 0)
			break;
		
		const itemInSlot = container.getItem(i);
		if (itemInSlot?.typeId != type) continue; // If not correct item, skip
		else {
			// If correct item, decrement total accordingly.
			const amount = itemInSlot?.amount;
			if (total >= amount) {
				container.setItem(i);
				total -= amount;
			}
			else {
				itemInSlot.amount -= total;
				container.setItem(i, itemInSlot);
				total = 0;
			}
		}
	}
}
export function stringAdjust(str, index, item) {
	// Replaces character in str at index with item
    return str.substring(0, index) + item + str.substring(index + item.length);
}

export function give_item(player, itemStack) {
	const container = player.getComponent("inventory").container;
	
	system.runTimeout(() => {
		if (container.emptySlotsCount >= 1) {
			container.addItem(itemStack);
		}
		else {
			player.dimension.spawnItem(itemStack, player.location);
		}
	}, 2);
}

export function unequip_item(player, slot) {
	const equipment = player.getComponent("equippable");
	const item = equipment.getEquipment(slot);
	if (item != null) {
		give_item(player, item);
		equipment.setEquipment(slot);
	}
}

export function give_item_instant(player, itemStack, dropItem = true) {
	const container = player.getComponent("inventory").container;
	
	if (container.emptySlotsCount >= 1) {
		container.addItem(itemStack);
		return true;
	}
	else if (dropItem) {
		player.dimension.spawnItem(itemStack, player.location);
		return true;
	}
	return false;
}

export function unequip_item_instant(player, slot, dropItem = true) {
	const equipment = player.getComponent("equippable");
	const item = equipment.getEquipment(slot);
	if (item != null) {
		const result = give_item_instant(player, item, dropItem);
		if (result)
			equipment.setEquipment(slot);
		
		return result;
	}
	
	return false;
}

export function store_player_items(player, name = "general") {
	store_player_hotbar(player, name);
	store_player_inventory(player, name);
	store_player_equipment(player, name);
}
export function store_player_inventory(player, name = "general") {
	const structures = world.structureManager;
	const inventoryStructureID = `ljw_ww:${name}_inv_${player.id}`;
	const playerInventoryContainer = player.getComponent("inventory").container;
	const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
	
	// Test for pre-existing content
	if (structures.get(inventoryStructureID) != null) {
		debug.warn(`${inventoryStructureID} already exits.`);
		const timestamp = Date.now();
		store_player_inventory(player, `${name}.conflict${timestamp}`);
		const conflictList = player.getDynamicProperty(`ljw_ww:${name}_inv_conflict_list`) ?? "";
		player.setDynamicProperty(`ljw_ww:${name}_inv_conflict_list`, `${timestamp};${conflictList}`)
		return;
	}
	
	// Create new structure
	const inventoryStructureOriginalBlock = player.dimension.getBlock(structureLocation);
	const inventoryStructureOriginalBlockPermutation = inventoryStructureOriginalBlock.permutation;
	inventoryStructureOriginalBlock.setPermutation(BlockPermutation.resolve("minecraft:chest"));
	const inventoryStructureBlock = player.dimension.getBlock(structureLocation);
	const inventoryStructureContainer = inventoryStructureBlock.getComponent("inventory").container;
	const inventoryStructureContainerSize = inventoryStructureContainer.size;
	for (let i = 0; i < inventoryStructureContainerSize; i += 1) {
		inventoryStructureContainer.setItem(i, playerInventoryContainer.getItem(i + 9));
		playerInventoryContainer.setItem(i + 9);
	}
	const inventoryStructure = structures.createFromWorld(inventoryStructureID, player.dimension, structureLocation, structureLocation, {saveMode: "World"});
	for (let i = 0; i < inventoryStructureContainerSize; i += 1) {
		inventoryStructureContainer.setItem(i);
	}
	inventoryStructureBlock.setPermutation(inventoryStructureOriginalBlockPermutation);
}
export function store_player_hotbar(player, name = "general") {
	const structures = world.structureManager;
	const hotbarStructureID = `ljw_ww:${name}_hot_${player.id}`;
	const playerInventoryContainer = player.getComponent("inventory").container;
	const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
	
	// Test for pre-existing content
	if (structures.get(hotbarStructureID) != null) {
		debug.warn(`${hotbarStructureID} already exits.`);
		const timestamp = Date.now();
		store_player_hotbar(player, `${name}.conflict${timestamp}`);
		const conflictList = player.getDynamicProperty(`ljw_ww:${name}_hot_conflict_list`) ?? "";
		player.setDynamicProperty(`ljw_ww:${name}_hot_conflict_list`, `${timestamp};${conflictList}`)
		return;
	}
	
	// Create new structure
	const hotbarStructureOriginalBlock = player.dimension.getBlock(structureLocation);
	const hotbarStructureOriginalBlockPermutation = hotbarStructureOriginalBlock.permutation;
	hotbarStructureOriginalBlock.setPermutation(BlockPermutation.resolve("minecraft:chest"));
	const hotbarStructureBlock = player.dimension.getBlock(structureLocation);
	const hotbarStructureContainer = hotbarStructureBlock.getComponent("inventory").container;
	for (let i = 0; i < 9; i += 1) {
		hotbarStructureContainer.setItem(i, playerInventoryContainer.getItem(i));
		playerInventoryContainer.setItem(i);
	}
	const hotbarStructure = structures.createFromWorld(hotbarStructureID, player.dimension, structureLocation, structureLocation, {saveMode: "World"});
	for (let i = 0; i < 9; i += 1) {
		hotbarStructureContainer.setItem(i);
	}
	hotbarStructureBlock.setPermutation(hotbarStructureOriginalBlockPermutation);
}
export function store_player_equipment(player, name = "general") {
	store_player_armor(player, name);
	store_player_offhand(player, name);
}
export function store_player_armor(player, name = "general") {
	const structures = world.structureManager;
	const armorStructureID = `ljw_ww:${name}_arm_${player.id}`;
	const playerEquipment = player.getComponent("equippable");
	const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
	
	// Test for pre-existing content
	if (structures.get(armorStructureID) != null) {
		debug.warn(`${armorStructureID} already exits.`);
		const timestamp = Date.now();
		store_player_armor(player, `${name}.conflict${timestamp}`);
		const conflictList = player.getDynamicProperty(`ljw_ww:${name}_arm_conflict_list`) ?? "";
		player.setDynamicProperty(`ljw_ww:${name}_arm_conflict_list`, `${timestamp};${conflictList}`)
		return;
	}
	
	// Create new structure
	const armorStructureOriginalBlock = player.dimension.getBlock(structureLocation);
	const armorStructureOriginalBlockPermutation = armorStructureOriginalBlock.permutation;
	armorStructureOriginalBlock.setPermutation(BlockPermutation.resolve("minecraft:chest"));
	const armorStructureBlock = player.dimension.getBlock(structureLocation);
	const armorStructureContainer = armorStructureBlock.getComponent("inventory").container;
	armorStructureContainer.setItem(0, playerEquipment.getEquipment("Head"));
	armorStructureContainer.setItem(1, playerEquipment.getEquipment("Chest"));
	armorStructureContainer.setItem(2, playerEquipment.getEquipment("Legs"));
	armorStructureContainer.setItem(3, playerEquipment.getEquipment("Feet"));
	playerEquipment.setEquipment("Head");
	playerEquipment.setEquipment("Chest");
	playerEquipment.setEquipment("Legs");
	playerEquipment.setEquipment("Feet");
	const armorStructure = structures.createFromWorld(armorStructureID, player.dimension, structureLocation, structureLocation, {saveMode: "World"});
	armorStructureContainer.setItem(0);
	armorStructureContainer.setItem(1);
	armorStructureContainer.setItem(2);
	armorStructureContainer.setItem(3);
	armorStructureBlock.setPermutation(armorStructureOriginalBlockPermutation);
}
export function store_player_offhand(player, name = "general") {
	const structures = world.structureManager;
	const offhandStructureID = `ljw_ww:${name}_ofh_${player.id}`;
	const playerEquipment = player.getComponent("equippable");
	const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
	
	// Test for pre-existing content
	if (structures.get(offhandStructureID) != null) {
		debug.warn(`${offhandStructureID} already exits.`);
		const timestamp = Date.now();
		store_player_offhand(player, `${name}.conflict${timestamp}`);
		const conflictList = player.getDynamicProperty(`ljw_ww:${name}_ofh_conflict_list`) ?? "";
		player.setDynamicProperty(`ljw_ww:${name}_ofh_conflict_list`, `${timestamp};${conflictList}`)
		return;
	}
	
	// Create new structure
	const offhandStructureOriginalBlock = player.dimension.getBlock(structureLocation);
	const offhandStructureOriginalBlockPermutation = offhandStructureOriginalBlock.permutation;
	offhandStructureOriginalBlock.setPermutation(BlockPermutation.resolve("minecraft:chest"));
	const offhandStructureBlock = player.dimension.getBlock(structureLocation);
	const offhandStructureContainer = offhandStructureBlock.getComponent("inventory").container;
	offhandStructureContainer.setItem(0, playerEquipment.getEquipment("Offhand"));
	playerEquipment.setEquipment("Offhand");
	const offhandStructure = structures.createFromWorld(offhandStructureID, player.dimension, structureLocation, structureLocation, {saveMode: "World"});
	offhandStructureContainer.setItem(0);
	offhandStructureBlock.setPermutation(offhandStructureOriginalBlockPermutation);
}

export function restore_player_items(player, name = "general") {
	restore_player_equipment(player, name);
	restore_player_hotbar(player, name);
	restore_player_inventory(player, name);
}
export function restore_player_inventory(player, name = "general") {
	// Check for conflict data
	const conflictList = player.getDynamicProperty(`ljw_ww:${name}_inv_conflict_list`);
	if (conflictList != null) {
		const conflictEntries = conflictList.split(";");
		for (let i = 1; i < conflictEntries.length; i += 1) {
			if (conflictEntries[i].length > 0)
				restore_conflict_items(player, `${name}.conflict${conflictEntries[i]}_inv_${player.id}`);
				
			restore_conflict_items(player, `ljw_ww:${name}_inv_${player.id}`);
		}
		player.setDynamicProperty(`ljw_ww:${name}_inv_conflict_list`);
		name = `${name}.conflict${conflictEntries[0]}`;
	}
	
	try {
		const structures = world.structureManager;
		const inventoryStructureID = `ljw_ww:${name}_inv_${player.id}`;
		const playerInventoryContainer = player.getComponent("inventory").container;
		const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
		
		// Load Data
		const inventoryStructureOriginalBlock = player.dimension.getBlock(structureLocation);
		const inventoryStructureOriginalBlockPermutation = inventoryStructureOriginalBlock.permutation;
		structures.place(inventoryStructureID, player.dimension, structureLocation);
		const inventoryStructureBlock = player.dimension.getBlock(structureLocation);
		const inventoryStructureContainer = inventoryStructureBlock.getComponent("inventory").container;
		const inventoryStructureContainerSize = inventoryStructureContainer.size;
		for (let i = 0; i < inventoryStructureContainerSize; i += 1) {
			playerInventoryContainer.setItem(i + 9, inventoryStructureContainer.getItem(i));
		}
		for (let i = 0; i < inventoryStructureContainerSize; i += 1) {
			inventoryStructureContainer.setItem(i);
		}
		inventoryStructureBlock.setPermutation(inventoryStructureOriginalBlockPermutation);
		structures.delete(inventoryStructureID);
	}
	catch(err) {
		debug.error(`Inventory restore error: ${err}`);
	}
}
export function restore_player_hotbar(player, name = "general") {
	// Check for conflict data
	const conflictList = player.getDynamicProperty(`ljw_ww:${name}_hot_conflict_list`);
	if (conflictList != null) {
		const conflictEntries = conflictList.split(";");
		for (let i = 1; i < conflictEntries.length; i += 1) {
			if (conflictEntries[i].length > 0)
				restore_conflict_items(player, `${name}.conflict${conflictEntries[i]}_hot_${player.id}`);
				
			restore_conflict_items(player, `ljw_ww:${name}_hot_${player.id}`);
		}
		player.setDynamicProperty(`ljw_ww:${name}_hot_conflict_list`);
		name = `${name}.conflict${conflictEntries[0]}`;
	}
	
	try {
		const structures = world.structureManager;
		const hotbarStructureID = `ljw_ww:${name}_hot_${player.id}`;
		const playerInventoryContainer = player.getComponent("inventory").container;
		const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
		
		// Load Data
		const hotbarStructureOriginalBlock = player.dimension.getBlock(structureLocation);
		const hotbarStructureOriginalBlockPermutation = hotbarStructureOriginalBlock.permutation;
		structures.place(hotbarStructureID, player.dimension, structureLocation);
		const hotbarStructureBlock = player.dimension.getBlock(structureLocation);
		const hotbarStructureContainer = hotbarStructureBlock.getComponent("inventory").container;
		const hotbarStructureContainerSize = hotbarStructureContainer.size;
		for (let i = 0; i < 9; i += 1) {
			playerInventoryContainer.setItem(i, hotbarStructureContainer.getItem(i));
		}
		for (let i = 0; i < 9; i += 1) {
			hotbarStructureContainer.setItem(i);
		}
		hotbarStructureBlock.setPermutation(hotbarStructureOriginalBlockPermutation);
		structures.delete(hotbarStructureID);
	}
	catch(err) {
		debug.error(`Hotbar restore error: ${err}`);
	}
}
export function restore_player_equipment(player, name = "general") {
	restore_player_armor(player, name);
	restore_player_offhand(player, name);
}
export function restore_player_armor(player, name = "general") {
	// Check for conflict data
	const conflictList = player.getDynamicProperty(`ljw_ww:${name}_arm_conflict_list`);
	if (conflictList != null) {
		const conflictEntries = conflictList.split(";");
		for (let i = 1; i < conflictEntries.length; i += 1) {
			if (conflictEntries[i].length > 0)
				restore_conflict_items(player, `${name}.conflict${conflictEntries[i]}_arm_${player.id}`);
				
			restore_conflict_items(player, `ljw_ww:${name}_arm_${player.id}`);
		}
		player.setDynamicProperty(`ljw_ww:${name}_arm_conflict_list`);
		name = `${name}.conflict${conflictEntries[0]}`;
	}
	
	try {
		const structures = world.structureManager;
		const armorStructureID = `ljw_ww:${name}_arm_${player.id}`;
		const playerEquipment = player.getComponent("equippable");
		const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
		
		// Load Data
		const armorStructureOriginalBlock = player.dimension.getBlock(structureLocation);
		const armorStructureOriginalBlockPermutation = armorStructureOriginalBlock.permutation;
		structures.place(armorStructureID, player.dimension, structureLocation);
		const armorStructureBlock = player.dimension.getBlock(structureLocation);
		const armorStructureContainer = armorStructureBlock.getComponent("inventory").container;
		const armorStructureContainerSize = armorStructureContainer.size;
		playerEquipment.setEquipment("Head", armorStructureContainer.getItem(0));
		playerEquipment.setEquipment("Chest", armorStructureContainer.getItem(1));
		playerEquipment.setEquipment("Legs", armorStructureContainer.getItem(2));
		playerEquipment.setEquipment("Feet", armorStructureContainer.getItem(3));
		armorStructureContainer.setItem(0);
		armorStructureContainer.setItem(1);
		armorStructureContainer.setItem(2);
		armorStructureContainer.setItem(3);
		armorStructureBlock.setPermutation(armorStructureOriginalBlockPermutation);
		structures.delete(armorStructureID);
	}
	catch(err) {
		debug.error(`Armor restore error: ${err}`);
	}
}
export function restore_player_offhand(player, name = "general") {
	// Check for conflict data
	const conflictList = player.getDynamicProperty(`ljw_ww:${name}_ofh_conflict_list`);
	if (conflictList != null) {
		const conflictEntries = conflictList.split(";");
		for (let i = 1; i < conflictEntries.length; i += 1) {
			if (conflictEntries[i].length > 0)
				restore_conflict_items(player, `${name}.conflict${conflictEntries[i]}_ofh_${player.id}`);
				
			restore_conflict_items(player, `ljw_ww:${name}_ofh_${player.id}`);
		}
		player.setDynamicProperty(`ljw_ww:${name}_ofh_conflict_list`);
		name = `${name}.conflict${conflictEntries[0]}`;
	}
	
	try {
		const structures = world.structureManager;
		const offhandStructureID = `ljw_ww:${name}_ofh_${player.id}`;
		const playerEquipment = player.getComponent("equippable");
		const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
		
		// Load Data
		const offhandStructureOriginalBlock = player.dimension.getBlock(structureLocation);
		const offhandStructureOriginalBlockPermutation = offhandStructureOriginalBlock.permutation;
		structures.place(offhandStructureID, player.dimension, structureLocation);
		const offhandStructureBlock = player.dimension.getBlock(structureLocation);
		const offhandStructureContainer = offhandStructureBlock.getComponent("inventory").container;
		const offhandStructureContainerSize = offhandStructureContainer.size;
		playerEquipment.setEquipment("Offhand", offhandStructureContainer.getItem(0));
		offhandStructureContainer.setItem(0);
		offhandStructureBlock.setPermutation(offhandStructureOriginalBlockPermutation);
		structures.delete(offhandStructureID);
	}
	catch(err) {
		debug.error(`Offhand restore error: ${err}`);
	}
}
export function restore_conflict_items(player, name) {
	const structures = world.structureManager;
	const structureID = name;
	const structureLocation = {x: player.location.x, y: player.dimension.heightRange.min, z: player.location.z};
	
	// Load Data
	debug.info(`Restoring conflict data ${name}...`);
	try {
		if ((name != "") && (structures.get(structureID) != null)) {
			const structureOriginalBlock = player.dimension.getBlock(structureLocation);
			const structureOriginalBlockPermutation = structureOriginalBlock.permutation;
			structures.place(structureID, player.dimension, structureLocation);
			const structureBlock = player.dimension.getBlock(structureLocation);
			const structureContainerInventory = structureBlock.getComponent("inventory");
			if (structureContainerInventory != null) {
				const structureContainer = structureContainerInventory.container;
				const structureContainerSize = structureContainer.size;
				for (let i = 0; i < structureContainerSize; i += 1) {
					const itemStack = structureContainer.getItem(i);
					if (itemStack != null) {
						player.dimension.spawnItem(itemStack, player.location);
						structureContainer.setItem(i);
					}
				}
			}
			
			structureBlock.setPermutation(structureOriginalBlockPermutation);
			structures.delete(structureID);
		}
	}
	catch(err) {
		debug.error(`Conflict items restore error: ${err}`);
	}
}

export function condensed_bool_read(variable, index) {
	return (Math.floor((variable/Math.pow(2,index)) % 2));
}

export function condensed_bool_write(variable, index, value) {
	if (value == 1)
		return (!condensed_bool_read(variable, index) ? variable + Math.pow(2, index) : variable);
	else if (value == 0)
		return (condensed_bool_read(variable, index) ? variable - Math.pow(2, index) : variable);
	else
		throw new Error(`Condensed var error: Cannot set value at index ${index} to ${value}. Unsafe action blocked.`);
}

export function is_moving(entity) {
	const velocity = entity.getVelocity();
	return (velocity.x != 0) || (velocity.y != 0) || (velocity.z != 0)
}

export function translate_text(text) {
	//const signPerm = BlockPermutation.resolve('minecraft:standing_sign', { ground_sign_direction: 8 });
    const signComponent = new BlockSignComponent();
    signComponent.setText({ translate: text });
	return signComponent.getText();
}

export function manual_parse_name(entity) {
	return manual_format_name_by_id(entity.typeId);
}

export function manual_format_name_by_id(text) {
	return text.substring(text.indexOf(":") + 1,text.length).replaceAll("_", " ").replace(/\w\S*/g, function (txt) {return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();})
}

export function get_full_week_num(date) {
	const testDate = date;
	
	// Go back to Sunday & determine number of Sundays
	testDate.setDate(testDate.getDate() - testDate.getDay());
	const numOccurances = Math.ceil(testDate.getDate() / 7);
	
	return numOccurances;
}

export function deduct_xp(player, cost) {
	try {
		if (player.getGameMode() == "creative")
			cost = 0;
		
		if (cost > 0) {
			while (cost > 0) {
				if ((player.xpEarnedAtCurrentLevel == 0) && (player.level > 0)) {
					player.addLevels(-1);
					player.addExperience(player.totalXpNeededForNextLevel - 1);
					cost -= 1;
				}
				const xpAvailable = Math.min(player.xpEarnedAtCurrentLevel, cost);
				player.addExperience(-1 * Math.ceil(xpAvailable));
				cost -= xpAvailable;
			}
			player.playSound("random.orb", {pitch: 1.2 - Math.random() * 0.3});
		}
	}
	catch (err) {
		return;
	}
}

export function update_block_state(block, states) {
	const blockStates = block?.permutation.getAllStates();
	for (const state of Object.keys(states)) {
		if (blockStates[state] != null)
			blockStates[state] = states[state];
		else
			debug.warn(`Block ${block.typeId} doesn't support state "${state}". Ignoring...`);
	}
	block.setPermutation(BlockPermutation.resolve(block.typeId, blockStates));
}

export function local_space_coords(entity, relativeCoords = {x: 0, y: 0, z: 0}) {
    try {
        // Validate inputs
        if (!entity) {
            throw new Error("First argument must be an Entity");
        }

        // Get entity's current position and rotation
        const { x, y, z } = entity.location;
        const rotation = entity.getRotation(); // { x: pitch, y: yaw }
        const yaw = rotation.y; // Horizontal rotation in degrees
        const pitch = rotation.x; // Vertical rotation in degrees

        // Convert yaw and pitch to radians
        const yawRad = yaw * (Math.PI / 180);
        const pitchRad = pitch * (Math.PI / 180);

        // Calculate direction vectors based on yaw and pitch
        // Forward vector (aligned with ^z, forward/back)
        const forward = {
            x: -Math.sin(yawRad) * Math.cos(pitchRad),
            y: -Math.sin(pitchRad),
            z: Math.cos(yawRad) * Math.cos(pitchRad),
        };

        // Right vector (aligned with ^x, left/right)
        const right = {
            x: Math.cos(yawRad),
            y: 0, // Right is horizontal, no y component
            z: Math.sin(yawRad),
        };

        // Up vector (aligned with ^y, up/down, perpendicular to forward and right)
        // Computed using cross product of right and forward to ensure orthogonality
        const up = {
            x: -Math.sin(yawRad) * Math.sin(pitchRad),
            y: Math.cos(pitchRad),
            z: Math.cos(yawRad) * Math.sin(pitchRad),
        };

        // Compute the offset in world coordinates
        // ^x affects right, ^y affects up, ^z affects forward
        const offsetX = (right.x * relativeCoords.x) + (up.x * relativeCoords.y) + (forward.x * relativeCoords.z);
        const offsetY = (right.y * relativeCoords.x) + (up.y * relativeCoords.y) + (forward.y * relativeCoords.z);
        const offsetZ = (right.z * relativeCoords.x) + (up.z * relativeCoords.y) + (forward.z * relativeCoords.z);

        // Calculate absolute coordinates
        const absoluteCoords = {
            x: x + offsetX,
            y: y + offsetY,
            z: z + offsetZ,
        };

        return absoluteCoords; // Success
    }
	catch (error) {
        debug.error("Error in local_space_coords:", error.message);
        return false; // Failure
    }
}

export function local_space_coords_2d(entity, relativeCoords = {x: 0, y: 0, z: 2}) {
    try {
        // Validate inputs
        if (!entity) {
            throw new Error("First argument must be an Entity");
        }

        // Get entity's current position and rotation
        const { x, y, z } = entity.location;
        const rotation = entity.getRotation(); // { x: pitch, y: yaw }
        const yaw = rotation.y; // Yaw is horizontal rotation in degrees

        // Convert yaw to radians for trigonometric functions
        const yawRad = yaw * (Math.PI / 180);

        // Calculate the direction vectors based on yaw
        // In Minecraft, z is forward/back, x is left/right, y is up/down
        // ^x: left/right, ^y: up/down, ^z: forward/back
        const forward = {
            x: -Math.sin(yawRad), // Forward direction (z-axis)
            z: Math.cos(yawRad),
        };
        const right = {
            x: Math.cos(yawRad), // Right direction (x-axis)
            z: Math.sin(yawRad),
        };

        // Compute the offset in world coordinates
        const offsetX = (right.x * relativeCoords.x) + (forward.x * relativeCoords.z);
        const offsetY = relativeCoords.y; // Y is not affected by rotation
        const offsetZ = (right.z * relativeCoords.x) + (forward.z * relativeCoords.z);

        // Calculate absolute coordinates
        const absoluteCoords = {
            x: x + offsetX,
            y: y + offsetY,
            z: z + offsetZ,
        };

        return absoluteCoords; // Success
    }
	catch (error) {
        debug.error("Error in local_space_coords_2d:", error.message);
        return false; // Failure
    }
}