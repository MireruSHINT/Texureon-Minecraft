import {system, world, ItemStack} from "@minecraft/server";
import * as debug from "../debug_functions.js";
import * as util from "../util.js";

world.beforeEvents.worldInitialize.subscribe(e => {
	e.blockComponentRegistry.registerCustomComponent('ljw_ww:lantern_behavior', { onTick: lantern_tick });
});

function lantern_tick(e) {
	try {
		const block = e.block;
		const side = block?.permutation.getState("minecraft:block_face");
		
		if (side == "up") {
			const checkBlock = block.below();
			if (checkBlock?.isAir || checkBlock?.isLiquid) {
				block.dimension.spawnItem(new ItemStack(block.typeId), block.location);
				block.setType("minecraft:air");
			}
		}
		else if (side == "down") {
			const checkBlock = block.above();
			if (checkBlock?.isAir || checkBlock?.isLiquid) {
				block.dimension.spawnItem(new ItemStack(block.typeId), block.location);
				block.setType("minecraft:air");
			}
		}
	}
	catch(err) {
		debug.error(`Lantern Tick error: ${err}`);
	}
}