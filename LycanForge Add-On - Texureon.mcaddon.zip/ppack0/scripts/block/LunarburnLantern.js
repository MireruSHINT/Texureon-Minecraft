import {system, world} from "@minecraft/server";
import * as debug from "../debug_functions.js";
import * as util from "../util.js";
import * as data from "../data/general.js";

world.beforeEvents.worldInitialize.subscribe(e => {
	e.blockComponentRegistry.registerCustomComponent('ljw_ww:lunarburn_radiate', { onTick: lunarburn_radiate });
});

function lunarburn_radiate(e) {
	try {
		const block = e.block;
		for (const player of block.dimension.getPlayers({location: block.location, maxDistance: 16})) {
			if (player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false) {
				const transformExtendTime = player.getDynamicProperty("ljw_ww:transformation_extend_time") ?? 0;
				const lunarburnExposure = player.getDynamicProperty("ljw_ww:lunarburn_exposure") ?? 0;
				const fullStrength = (player.getDynamicProperty("ljw_ww:form") == "wolf") && (transformExtendTime == 0);
				player.setDynamicProperty("ljw_ww:lunarburn_exposure", Math.min(data.lunarburnExposureMax[fullStrength ? 1 : 0], lunarburnExposure + 5));
			}
		}
	}
	catch(err) {
		debug.error(`Lunarburn Radiate Tick error: ${err}`);
	}
}