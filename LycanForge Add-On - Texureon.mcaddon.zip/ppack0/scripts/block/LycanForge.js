import {system, world, ItemStack} from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import * as debug from "../debug_functions.js";
import * as abilities from "../data/abilities";
import * as appearance from "../data/appearance";
import * as util from "../util.js";

world.beforeEvents.worldInitialize.subscribe(e => {
	e.blockComponentRegistry.registerCustomComponent('ljw_ww:lycan_forge_behavior', { onPlayerInteract: lycan_forge_interact });
});

function lycan_forge_interact(e) {
	try {
		const block = e.block;
		const player = e.player;
		if (player == null)
			return;
		
		open_window(player, block);
	}
	catch(err) {
		debug.error(`Lycan Forge Interact error: ${err}`);
	}
}

function open_window(player, block) {
	try {
		const isWerewolf = player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false;
		const werewolfFormActive = (player.getDynamicProperty("ljw_ww:form") ?? "normal") == "wolf";
		const level = player.getDynamicProperty("ljw_ww:werewolf_level") ?? 0;
		const xp = player.getTotalXp();
		const debugMode = world.getDynamicProperty("ljw_ww:setting_forge_debug");
		
		const dialog = new ActionFormData();
		dialog.title({ translate: "ljw_ww.lycan_forge.main.title", with: { rawtext: [ { translate: "item.ljw_ww:lycan_forge", with: { rawtext: [ { text: "\n" }]} }]} });
		if (isWerewolf) {
			dialog.body({ translate: "ljw_ww.lycan_forge.main.body", with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:lycan_forge", with: { rawtext: [ { text: "\n" }]} }, { text: level.toString() }, { text: xp.toString() }]} });
		}
		else {
			player.sendMessage({ translate: "ljw_ww.lycan_forge.message.is_not_werewolf", with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:lycan_forge", with: { rawtext: [ { text: "\n" }]} }]} });
			return;
		}
		
		dialog.button({ translate: "ljw_ww.lycan_forge.main.button.abilities", with: { rawtext: [ { text: "\n" }]} });
		dialog.button({ translate: "ljw_ww.lycan_forge.main.button.appearance", with: { rawtext: [ { text: "\n" }]} });
		if (debugMode) {
			dialog.button("§cReset Appearance List§r");
			dialog.button("§cReset Abilities§r");
		}
		
		dialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					open_abilities_menu(player);
				else if (response.selection == 1)
					appearance.open_appearance_menu(player);
				else if (response.selection == 2) {
					player.setDynamicProperty("ljw_ww:werewolf_form_list");
					player.setDynamicProperty("ljw_ww:trim_pack_list");
					player.setDynamicProperty("ljw_ww:trim_material_list");
				}
				else if (response.selection == 3) {
					for (const ability of Object.keys(abilities.list)) {
						player.setDynamicProperty(`ljw_ww:werewolf_${ability}_level`);
						player.setDynamicProperty(`ljw_ww:werewolf_${ability}_setting`);
					}
					player.setDynamicProperty(`ljw_ww:werewolf_level`);
					for (const emblemClass of abilities.emblemClasses) {
						player.setDynamicProperty(`ljw_ww:acquired_emblem_${emblemClass}`);
					}
				}
			}
		});
	}
	catch (err) {
		debug.error(`Lycan Forge error: ${err}`)
	}
}

function open_abilities_menu(player) {
	try {
		const dialog = new ActionFormData();
		dialog.title({ translate: "ljw_ww.lycan_forge.abilities_menu.title", with: { rawtext: [ { text: "\n" }]} });
		dialog.body({ translate: "ljw_ww.lycan_forge.abilities_menu.body", with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:lycan_forge", with: { rawtext: [ { text: "\n" }]} }]} });
		
		dialog.button({ translate: "ljw_ww.lycan_forge.abilities_menu.button.learn", with: { rawtext: [ { text: "\n" }]} });
		dialog.button({ translate: "ljw_ww.lycan_forge.abilities_menu.button.manage", with: { rawtext: [ { text: "\n" }]} });
		dialog.button({ translate: "ljw_ww.lycan_forge.abilities_menu.button.items", with: { rawtext: [ { text: "\n" }]} });
		
		dialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					open_emblem_select_menu(player);
				else if (response.selection == 1)
					open_manage_abilities_menu(player);
				else if (response.selection == 2)
					open_ability_items_menu(player);
			}
		});
	}
	catch (err) {
		debug.error(`Lycan Forge error: ${err}`)
	}
}

function open_emblem_select_menu(player) {
	try {
		const level = player.getDynamicProperty("ljw_ww:werewolf_level") ?? 0;
		
		const dialog = new ActionFormData();
		dialog.title({ translate: "ljw_ww.lycan_forge.emblem_select_menu.title", with: { rawtext: [ { text: "\n" }]} });
		dialog.body({ translate: "ljw_ww.lycan_forge.emblem_select_menu.body", with: { rawtext: [ { text: "\n" }]} });
		
		const hasEmblemStatuses = [ ];
		
		for (const emblemClass of abilities.emblemClasses) {
			const acquiredEmblem = (emblemClass == "base") || (player.getDynamicProperty(`ljw_ww:acquired_emblem_${emblemClass}`) ?? false);
			hasEmblemStatuses.push(acquiredEmblem);
			
			let subtitle = {text: ""};
			if (!acquiredEmblem) {
				subtitle = { translate: `ljw_ww.general.not_acquired` };
			}
			else {
				let abilityCount = 0;
				for (const ability of Object.keys(abilities.list)) {
					const abilityEntry = abilities.list[ability];
					const wolfLevel = player.getDynamicProperty("ljw_ww:werewolf_level") ?? 0;
					const currentLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_level`) ?? 0;
					const maxLevel = abilityEntry.maxLevel;
					
					// Determine the max level of this ability that this player can access
					let availableLevel = -1;
					let testLevel = wolfLevel;
					do {
						availableLevel = abilityEntry.unlockLevels.lastIndexOf(testLevel);
						testLevel -= 1;
					} while ((availableLevel == -1) && (testLevel >= 0))
					
					// Filter for currently selected emblem
					if ((abilityEntry.emblemClass ?? "base") != emblemClass) {
						continue;
					}
					else if (maxLevel == currentLevel){
						continue;
					}
					else if (availableLevel == -1) {
						continue;
					}
					abilityCount += 1;
				}
				
				if (abilityCount > 0) {
					subtitle = { translate: "ljw_ww.lycan_forge.emblem_select_menu.button.subtitle.has_available", with: { rawtext: [ { text: "\n" }, { text: `${abilityCount}` }]} }
				}
				else {
					subtitle = { translate: "ljw_ww.lycan_forge.emblem_select_menu.button.subtitle.complete", with: { rawtext: [ { text: "\n" }]} }
				}
			}
			
			if (emblemClass == "base") {
				dialog.button({ translate: "ljw_ww.lycan_forge.emblem_select_menu.button.base", with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.emblem_class.base` }, {text: `${level}`}, subtitle]} }, `textures/ljw/ww/items/emblem_lv${level}`);
			}
			else {
				dialog.button({ translate: "ljw_ww.lycan_forge.emblem_select_menu.button.special", with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.emblem_class.${emblemClass}` }, subtitle]} }, `textures/ljw/ww/items/emblem_${emblemClass}`);
			}
		}
		
		dialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (hasEmblemStatuses[[response.selection]]) {
					open_learn_abilities_menu(player, abilities.emblemClasses[response.selection]);
				}
				else {
					open_emblem_info_menu(player, abilities.emblemClasses[response.selection]);
				}
			}
			else {
				open_abilities_menu(player);
			}
		});
	}
	catch (err) {
		debug.error(`Emblem Select error: ${err}`)
	}
}

function open_emblem_info_menu(player, emblemClass) {
	try {
		const dialog = new ActionFormData();
		dialog.title({ translate: `ljw_ww.lycan_forge.emblem_info_menu.title`, with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.emblem_class.${emblemClass}` }]} });
		
		let abilityCount = 0;
		
		for (const ability of Object.keys(abilities.list)) {
			const abilityEntry = abilities.list[ability];
			
			// Filter for currently selected emblem
			if ((abilityEntry.emblemClass ?? "base") != emblemClass) {
				continue;
			}
			abilityCount += 1;
		}
		
		dialog.body({ translate: `ljw_ww.lycan_forge.emblem_info_menu.body`, with: { rawtext: [ { text: "\n" }, { text: abilityCount.toString() }, { translate: `ljw_ww.emblem_class.${emblemClass}.hint` }]} });
		dialog.button({ translate: "ljw_ww.general.button.okay", with: { rawtext: [ { text: "\n" }]} });
		
		dialog.show(player).then((response) => {
			open_emblem_select_menu(player);
		});
	}
	catch (err) {
		debug.error(`Emblem Info Menu Error: ${err}`)
	}
}

function open_manage_abilities_menu(player, emblemClass) {
	try {
		const abilityList = [];
		
		const dialog = new ActionFormData();
		dialog.title({ translate: `ljw_ww.lycan_forge.manage_abilities_menu.title` });
			
		let abilityCount = 0;
		
		for (const ability of Object.keys(abilities.list)) {
			const abilityEntry = abilities.list[ability];
			const maxLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_level`) ?? 0;
			const currentLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_setting`) ?? 0;
			
			if (!abilityEntry.activatedByItem && (maxLevel > 0)) {
				abilityCount += 1;
				dialog.button({ translate: `ljw_ww.lycan_forge.abilities_menu.ability_button`, with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.ability.${ability}.name` }, { text: `§8[§r§b${"-".repeat(currentLevel)}§r§8${"-".repeat(maxLevel - currentLevel)}§r§8]§r` }]} });
				abilityList.push(ability);
			}
		}
			
		if (abilityCount > 0) {
			dialog.body({ translate: `ljw_ww.lycan_forge.manage_abilities_menu.body`, with: { rawtext: [ { text: "\n" }]} });
		}
		else {
			dialog.body({ translate: `ljw_ww.lycan_forge.manage_abilities_menu.body.no_abilities`, with: { rawtext: [ { text: "\n" }, { translate: "ljw_ww.lycan_forge.abilities_menu.button.learn" }]} });
			dialog.button({ translate: "ljw_ww.lycan_forge.abilities_menu.button.learn", with: { rawtext: [ { text: "\n" }]} });
			dialog.button({ translate: `ljw_ww.general.button.back`, with: { rawtext: [ { text: "\n" }]} });
		}
		
		dialog.show(player).then((response) => {
			if (abilityCount > 0) {
				if (response?.selection != null) {
					manage_ability(player, abilityList[response.selection])
				}
				else
					open_abilities_menu(player);
			}
			else {
				if (response?.selection == 0) {
					open_emblem_select_menu(player);
				}
				else if (response?.selection == 1) {
					open_abilities_menu(player);
				}
			}
		});
	}
	catch (err) {
		debug.error(`Manage Abilities Menu Error: ${err}`)
	}
}

function open_learn_abilities_menu(player, emblemClass) {
	try {
		const xp = player.getTotalXp();
		const wolfLevel = player.getDynamicProperty("ljw_ww:werewolf_level") ?? 0;
		const abilityList = [];
		
		const dialog = new ActionFormData();
		dialog.title({ translate: `ljw_ww.lycan_forge.learn_abilities_menu.title`, with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.emblem_class.${emblemClass}` }]} });
		
		let abilityCount = 0;
		
		for (const ability of Object.keys(abilities.list)) {
			const abilityEntry = abilities.list[ability];
			const maxLevel = abilityEntry.maxLevel;
			const currentLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_level`) ?? 0;
			
			// Filter for currently selected emblem
			if ((abilityEntry.emblemClass ?? "base") != emblemClass) {
				continue;
			}
			
			// Determine if player meets special requirements (if any)
			if ((abilityEntry.requirements != null) && !abilityEntry.requirements(player)) {
				continue;
			}
			
			// Determine the max level of this ability that this player can access
			let availableLevel = -1;
			let testLevel = wolfLevel;
			do {
				availableLevel = abilityEntry.unlockLevels.lastIndexOf(testLevel);
				testLevel -= 1;
			} while ((availableLevel == -1) && (testLevel >= 0))
			
			if (availableLevel > -1) {
				availableLevel += 1; // Adjust for UI
				if (availableLevel != currentLevel) {
					abilityCount += 1;
					dialog.button({ translate: `ljw_ww.lycan_forge.abilities_menu.ability_button`, with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.ability.${ability}.name` }, { text: `§8[§r§a${"-".repeat(currentLevel)}§r§8${"-".repeat(availableLevel - currentLevel)}§r§8]§r` + (currentLevel != availableLevel ? `§8 | ${abilityEntry.unlockXP[currentLevel]} XP§r` : "") }]} });
					abilityList.push(ability);
				}
			}
		}
		
		if (abilityCount > 0) {
			dialog.body({ translate: `ljw_ww.lycan_forge.learn_abilities_menu.body`, with: { rawtext: [ { text: "\n" }, { text: xp.toString() }, { translate: "item.ljw_ww:lycan_forge", with: { rawtext: [ { text: "\n" }]} }, { text: (player.getDynamicProperty(`ljw_ww:werewolf_level`) ?? 0).toString() }]} });
		}
		else {
			if (wolfLevel == 4) {
				dialog.body({ translate: `ljw_ww.lycan_forge.learn_abilities_menu.body.learned_all_abilities`, with: { rawtext: [ { text: "\n" }, { text: xp.toString() }, { translate: "item.ljw_ww:lycan_forge", with: { rawtext: [ { text: "\n" }]} }, { text: (player.getDynamicProperty(`ljw_ww:werewolf_level`) ?? 0).toString() }]} });
			}
			else {
				dialog.body({ translate: `ljw_ww.lycan_forge.learn_abilities_menu.body.learned_available_abilities`, with: { rawtext: [ { text: "\n" }, { text: xp.toString() }, { translate: "item.ljw_ww:lycan_forge", with: { rawtext: [ { text: "\n" }]} }, { text: (player.getDynamicProperty(`ljw_ww:werewolf_level`) ?? 0).toString() }]} });
			}
			dialog.button({ translate: `ljw_ww.general.button.back`, with: { rawtext: [ { text: "\n" }]} });
		}
		
		
		dialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (abilityCount > 0) {
					inspect_ability(player, abilityList[response.selection]);
				}
				else {
					open_emblem_select_menu(player);
				}
			}
			else
				open_emblem_select_menu(player);
		});
	}
	catch (err) {
		debug.error(`Learn Abilities Menu Error: ${err}`)
	}
}

function open_ability_items_menu(player) {
	try {
		const abilityList = [];
		
		const dialog = new ActionFormData();
		dialog.title({ translate: `ljw_ww.lycan_forge.ability_items_menu.title` });
			
		let abilityCount = 0;
		
		for (const ability of Object.keys(abilities.list)) {
			const abilityEntry = abilities.list[ability];
			const maxLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_level`) ?? 0;
			const currentLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_setting`) ?? 0;
			const activatedByItem = abilityEntry.activatedByItem ?? false;
			
			if ((maxLevel > 0) && (activatedByItem)) {
				abilityCount += 1;
				const hasItemMessage = util.countItem(player, `ljw_ww:ability_${ability}`) != 0 ? "ljw_ww.ability.info.holding_item" : "ljw_ww.ability.info.not_holding_item";
				dialog.button({ translate: `ljw_ww.lycan_forge.abilities_menu.ability_button`, with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.ability.${ability}.name` }, { translate: hasItemMessage }]} });
				abilityList.push(ability);
			}
		}
			
		if (abilityCount > 0) {
			dialog.body({ translate: `ljw_ww.lycan_forge.ability_items_menu.body`, with: { rawtext: [ { text: "\n" }]} });
		}
		else {
			dialog.body({ translate: `ljw_ww.lycan_forge.ability_items_menu.body.no_abilities`, with: { rawtext: [ { text: "\n" }, { translate: "ljw_ww.lycan_forge.abilities_menu.button.learn" }]} });
			dialog.button({ translate: "ljw_ww.lycan_forge.abilities_menu.button.learn", with: { rawtext: [ { text: "\n" }]} });
			dialog.button({ translate: `ljw_ww.general.button.back`, with: { rawtext: [ { text: "\n" }]} });
		}
		
		dialog.show(player).then((response) => {
			if (abilityCount > 0) {
				if (response?.selection != null) {
					view_ability_item(player, abilityList[response.selection])
				}
				else
					open_window(player);
			}
			else {
				if (response?.selection == 0) {
					open_emblem_select_menu(player);
				}
				else if (response?.selection == 1) {
					open_window(player);
				}
			}
		});
	}
	catch (err) {
		debug.error(`Manage Abilities Menu Error: ${err}`)
	}
}

function inspect_ability(player, ability) {
	try {
		const wolfLevel = player.getDynamicProperty("ljw_ww:werewolf_level") ?? 0;
		const currentLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_level`) ?? 0;
		const abilityEntry = abilities.list[ability];
		const maxLevel = abilityEntry.maxLevel;
		const activatedByItem = abilityEntry.activatedByItem ?? false;
		const xp = player.getTotalXp();
		const freeAbilities = (world.getDynamicProperty("ljw_ww:setting_free_abilities") ?? false);
		const requiredXP = freeAbilities ? 0 : abilityEntry.unlockXP[currentLevel];
		let canLearn = false;
		
		// Determine the max level of this ability that this player can access
		let availableLevel = -1;
		let testLevel = wolfLevel;
		do {
			availableLevel = abilityEntry.unlockLevels.lastIndexOf(testLevel);
			testLevel -= 1;
		} while ((availableLevel == -1) && (testLevel >= 0))
		availableLevel += 1; // Adjust for UI
	
		const dialog = new ActionFormData();
		dialog.title({ translate: `ljw_ww.ability.${ability}.name`, with: { rawtext: [ { text: "\n" }]} });
		
		let message = "";
		const itemRequiredMessage = (activatedByItem) ? "ljw_ww.ability.info.requires_item" : "";
		
		if ((xp < requiredXP) && (player.getGameMode() != "creative")) {
			message = `ljw_ww.ability.info.not_enough_xp`;
		}
		else if ((currentLevel == 0) && activatedByItem && (player.getComponent("inventory")?.container.emptySlotsCount == 0)) {
			message = `ljw_ww.ability.info.no_inventory_space`;
		}
		else {
			message = `ljw_ww.ability.info.can_learn`;
			canLearn = true;
		}
		
		dialog.body({ translate: `ljw_ww.lycan_forge.learn_ability`, with: { rawtext: [ { text: "\n" }, { text: currentLevel.toString() }, { text: availableLevel.toString() }, { text: xp.toString() }, { translate: message, with: { rawtext: [ { text: "\n" }, { text: requiredXP.toString() } ]} }, { translate: `ljw_ww.ability.${ability}.description`, with: { rawtext: [ { text: "\n" }]} }, { translate: itemRequiredMessage, with: { rawtext: [ { text: "\n" }, { translate: `item.ljw_ww:ability_${ability}` }]}  }]} });
		
		if (canLearn)
			dialog.button({ translate: `ljw_ww.lycan_forge.learn_ability.button.confirm`, with: { rawtext: [ { text: "\n" }, { text: requiredXP.toString() }]} });
		dialog.button({ translate: `ljw_ww.general.button.back`, with: { rawtext: [ { text: "\n" }]} });
		
		dialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (canLearn && (response.selection == 0)) {
					util.deduct_xp(player, requiredXP);
					player.setDynamicProperty(`ljw_ww:werewolf_${ability}_level`, currentLevel + 1);
					player.setDynamicProperty(`ljw_ww:werewolf_${ability}_setting`, currentLevel + 1);
					if (activatedByItem && (currentLevel == 0)) {
						player.getComponent("inventory")?.container.addItem(new ItemStack(`ljw_ww:ability_${ability}`));
					}
					player.setDynamicProperty(`ljw_ww:werewolf_ability_learned`, true);
				}
				
				open_learn_abilities_menu(player, (abilityEntry.emblemClass ?? "base"));
			}
			else
				open_learn_abilities_menu(player, (abilityEntry.emblemClass ?? "base"));
		});
	}
	catch (err) {
		debug.error(`Inspect Ability Error: ${err}`)
	}
}

function manage_ability(player, ability) {
	try {
		const maxLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_level`) ?? 0;
		const currentLevel = player.getDynamicProperty(`ljw_ww:werewolf_${ability}_setting`) ?? 0;
		const abilityEntry = abilities.list[ability];
		
		
		const dialog = new ModalFormData();
		dialog.title({ translate: `ljw_ww.ability.${ability}.name`, with: { rawtext: [ { text: "\n" }]} });
		
		if (abilityEntry.maxLevel > 1)
			dialog.slider({ translate: "ljw_ww.lycan_forge.manage_ability.slider", with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.ability.${ability}.description`, with: { rawtext: [ { text: "\n" }]} }]} }, 0, maxLevel, 1, currentLevel);
		else
			dialog.toggle({ translate: "ljw_ww.lycan_forge.manage_ability.toggle", with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.ability.${ability}.description`, with: { rawtext: [ { text: "\n" }]} }]} }, currentLevel == 1);
		
		
		dialog.show(player).then((formData) => {
			player.setDynamicProperty(`ljw_ww:werewolf_${ability}_setting`, formData.formValues[0]);
			player.setDynamicProperty(`ljw_ww:werewolf_ability_learned`, true);
		}).catch((error) => {
			debug.error("Manage Ability Error: " + error);
		}).finally(() => {
			open_manage_abilities_menu(player);
		});
	}
	catch (err) {
		debug.error(`Manage Ability Error: ${err}`)
	}
}

function view_ability_item(player, ability) {
	try {
		const abilityEntry = abilities.list[ability];
		
		const dialog = new ActionFormData();
		dialog.title({ translate: `ljw_ww.ability.${ability}.name`, with: { rawtext: [ { text: "\n" }]} });
			
		let abilityCount = 0;
		
		dialog.body({ translate: `ljw_ww.lycan_forge.ability_items_menu.body.inspect_item`, with: { rawtext: [ { text: "\n" }, { translate: "ljw_ww.lycan_forge.ability_items_menu.button.confirm" }, { translate: `ljw_ww.ability.${ability}.description`, with: { rawtext: [ { text: "\n" }]} }, { translate: "ljw_ww.ability.info.requires_item", with: { rawtext: [ { text: "\n" }, { translate: `item.ljw_ww:ability_${ability}` }]}  }]} });
		dialog.button({ translate: "ljw_ww.lycan_forge.ability_items_menu.button.confirm", with: { rawtext: [ { text: "\n" }]} });
		dialog.button({ translate: `ljw_ww.general.button.back`, with: { rawtext: [ { text: "\n" }]} });
		
		dialog.show(player).then((response) => {
			if (response?.selection == 0) {
				player.getComponent("inventory")?.container.addItem(new ItemStack(`ljw_ww:ability_${ability}`));
				player.sendMessage({ translate: "ljw_ww.lycan_forge.ability_items_menu.message.confirm", with: { rawtext: [ { text: "\n" }, { translate: `item.ljw_ww:ability_${ability}` }]} });
				open_ability_items_menu(player);
			}
			else
				open_ability_items_menu(player);
		});
	}
	catch (err) {
		debug.error(`Reclaim Ability Item Error: ${err}`)
	}
}