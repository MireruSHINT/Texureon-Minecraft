import {system, world, BlockPermutation, BlockComponentPlayerInteractEvent} from "@minecraft/server";
import * as debug from "../debug_functions.js";
import * as util from "../util.js";

const canGrowOnBlocks = [ "minecraft:grass_block", "minecraft:dirt", "minecraft:podzol" ];
const canReplaceBlocks = [ "minecraft:short_grass", "minecraft:snow_layer" ];

world.beforeEvents.worldInitialize.subscribe(e => {
	e.blockComponentRegistry.registerCustomComponent('ljw_ww:moonglow_sprig_behavior', { onTick: moonglow_sprig_tick, onPlayerInteract: moonglow_sprig_spread_chance });
});

world.afterEvents.playerInteractWithBlock.subscribe(e => {
    const itemStack = e.beforeItemStack;
    const block = e.block;
    const blockFace = e.blockFace;
	try {
		const time = world.getTimeOfDay();
		const isDay = !((time >= 13000) && (time <= 23000));
		if (!isDay && (itemStack?.typeId == "minecraft:bone_meal") && (blockFace == "Up") && canGrowOnBlocks.includes(block.typeId)) {
			const checkBlock = block.dimension.spawnEntity("ljw_ww:check_block", {x: block.location.x, y: block.location.y + 1, z: block.location.z});
			
			if (checkBlock.getProperty("ljw_ww:in_dark_oak_forest")) {
				moonglow_sprig_spread_chance({block: block, player: e.player}, true);
			}
			
			checkBlock.remove();
		}
	}
	catch(err) {
		debug.warn(`Bonemeal error: ${err}`);
	}
});

function moonglow_sprig_tick(e) {
	try {
		const block = e.block;
		
		const activated = block?.permutation.getState("ljw_ww:activated") == 1;
		const time = world.getTimeOfDay();
		const isDay = !((time >= 13000) && (time <= 23000));
		
		if (!activated && !isDay) {
			util.update_block_state(block, {"ljw_ww:activated": 1});
		}
		else if (activated && isDay) {
			util.update_block_state(block, {"ljw_ww:activated": 0});
		}
		
		if (activated && !isDay)
			block.dimension.spawnParticle("ljw_ww:moonglow_sprig_sparkle", {x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5})
	}
	catch(err) {
		debug.error(`Moonglow Sprig Tick error: ${err}`);
	}
}

function moonglow_sprig_spread_chance(e, newHerbChance = false) {
	try {
		const block = e.block;
		const activated = block?.permutation.getState("ljw_ww:activated") == 1;
		const player = e.player;
		
		if (activated || newHerbChance) {
			let success = false;
			let hasItem = false;
			const equipment = player.getComponent("equippable");
			if (equipment != null) {
				const item = equipment.getEquipment("Mainhand");
				if (item != null) {
					if (item.typeId == "minecraft:bone_meal") {
						hasItem = true;
					}
				}
			}
			
			if (hasItem || newHerbChance) {
				const spreadRange = 1;
				for (let x = -1 * spreadRange; x <= spreadRange; x += 1) 
					for (let y = -1 * spreadRange; y <= spreadRange; y += 1)
						for (let z = -1 * spreadRange; z <= spreadRange; z += 1) {
							success = moonlitHerbSpreadTest(block.dimension.getBlock({x: block.location.x + x, y: block.location.y + y, z: block.location.z + z})) || success;
						}
			}
			
			if (success) {
				block.dimension.spawnParticle("minecraft:crop_growth_emitter", {x: block.location.x + 0.5, y: block.location.y + 0.5, z: block.location.z + 0.5})
				if ((player.getGameMode() != "creative") && !newHerbChance)
					util.decrement_item(e.player, "minecraft:bone_meal");
			}
		}
	}
	catch(err) {
		debug.error(`Moonglow Sprig Spread error: ${err}`);
	}
}

function moonlitHerbSpreadTest(block) {
	if (block == null)
		return false;
	
	if (canGrowOnBlocks.includes(block.typeId)) {
		const chance = Math.random();
		if (chance >= 0.5) {
			const checkBlock = block.above();
			if (checkBlock?.isAir || canReplaceBlocks.includes(checkBlock.typeId)) {
				checkBlock.setType("ljw_ww:moonglow_sprig");
				return true;
			}
		}
		else
			return false;
	}
	
	return false;
}