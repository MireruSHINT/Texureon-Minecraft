import {system, world} from "@minecraft/server";
import * as debug from "../debug_functions.js";
import * as util from "../util.js";

world.beforeEvents.worldInitialize.subscribe(e => {
	e.blockComponentRegistry.registerCustomComponent('ljw_ww:werewolf_enable_behavior', { onTick: werewolf_enable_tick });
});

function werewolf_enable_tick(e) {
	try {
		const block = e.block;
		for (const player of block.dimension.getPlayers({location: block.location, maxDistance: 32})) {
			if (player.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false) {
				const transformExtendTime = player.getDynamicProperty("ljw_ww:transformation_extend_time") ?? 0;
				player.setDynamicProperty("ljw_ww:transformation_extend_time", Math.max(20, transformExtendTime));
			}
		}
	}
	catch(err) {
		debug.error(`Werewolf Enable Block Tick error: ${err}`);
	}
}