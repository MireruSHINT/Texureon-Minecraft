import { system } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import * as debug from "../debug_functions";

export const wolfTypeIds = {
	"minecraft:wolf": 0,
	"ljw_wp:wolf": 0
	//"ljw_ww:black_wolf": 1,
	//"ljw_ww:blaze_wolf": 2,
	//"ljw_ww:dire_wolf": 3,
	//"ljw_ww:end_wolf": 4,
	//"ljw_ww:heal_wolf": 5,
	//"ljw_ww:orange_wolf": 6,
	//"ljw_ww:husky": 7,
	//"ljw_ww:tracer_wolf": 8,
	//"ljw_ww:wandering_wolf": 9,
	//"ljw_ww:white_wolf": 10,
	//"ljw_ww:wild_dog": 11,
	//"ljw_ww:zombie_wolf_cured": 12
}

export const wolfIDList = [
	"000", "100", "200", "300", "400", "500", "600", "700", "800"
]

export const trimLibrary = [
	"NULL",
	"bolt",
	"coast",
	"dune",
	"eye",
	"flow",
	"host",
	"raiser",
	"rib",
	"sentry",
	"shaper",
	"silence",
	"snout",
	"spire",
	"tide",
	"vex",
	"ward",
	"wayfinder",
	"wild"
];
export const trimMaterialLibrary = [
	"NULL",
	"iron",
	"copper",
	"gold",
	"lapis",
	"emerald",
	"diamond",
	"netherite",
	"redstone",
	"amethyst",
	"quartz",
	"resin",
	"moonlit"
];

export function open_appearance_menu(player) {
	try {
		const dialog = new ActionFormData();
		dialog.title({ translate: `ljw_ww.appearance_menu.title` });
		dialog.body({ translate: `ljw_ww.appearance_menu.body`, with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:lycan_forge" }]} });
			
		dialog.button({ translate: `ljw_ww.appearance_menu.button.coat_color`, with: { rawtext: [ { text: "\n" }]} });
		dialog.button({ translate: `ljw_ww.appearance_menu.button.armor`, with: { rawtext: [ { text: "\n" }]} });
		dialog.button({ translate: `ljw_ww.appearance_menu.button.eye_color`, with: { rawtext: [ { text: "\n" }]} });
		dialog.button({ translate: `ljw_ww.appearance_menu.button.trims`, with: { rawtext: [ { text: "\n" }]} });
		dialog.button({ translate: `ljw_ww.appearance_menu.button.voice_profile`, with: { rawtext: [ { text: "\n" }]} });
		
		dialog.show(player).then((response) => {
			const choice = response?.selection;
			if (choice != null) {
				switch(choice) {
					case 0:
						open_change_coat_menu(player);
						break;
					case 1:
						open_armor_menu(player);
						break;
					case 2:
						open_eye_color_menu(player);
						break;
					case 3:
						open_trims_menu(player);
						break;
					case 4:
						open_voice_profile_menu(player);
						break;
				}
			}
		});
	}
	catch (err) {
		debug.error(`Appearance Menu Error: ${err}`)
	}
}

function open_armor_menu(player) {
	try {
		const wolfLevel = player.getDynamicProperty("ljw_ww:werewolf_level") ?? 0;
		const armorSetting = player.getDynamicProperty(`ljw_ww:werewolf_armor_setting`) ?? 0;
		const armorTypeSetting = player.getDynamicProperty(`ljw_ww:werewolf_armor_type_setting`) ?? 0;
		
		const armorTypeArray = [];
		
		switch(wolfLevel) {
			case 4:
				armorTypeArray.unshift({ translate: "ljw_ww.armor_menu.armor_type.dropdown.netherite", with: { rawtext: [{ text: "\n" }] }});
			case 3:
				armorTypeArray.unshift({ translate: "ljw_ww.armor_menu.armor_type.dropdown.diamond", with: { rawtext: [{ text: "\n" }] }});
			case 2:
				armorTypeArray.unshift({ translate: "ljw_ww.armor_menu.armor_type.dropdown.gold", with: { rawtext: [{ text: "\n" }] }});
			default:
				armorTypeArray.unshift({ translate: "ljw_ww.armor_menu.armor_type.dropdown.iron", with: { rawtext: [{ text: "\n" }] }});
		}
		const armorSettingArray = [
			{ translate: "ljw_ww.armor_menu.armor_setting.dropdown.none", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.armor_menu.armor_setting.dropdown.light", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.armor_menu.armor_setting.dropdown.normal", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.armor_menu.armor_setting.dropdown.full", with: { rawtext: [{ text: "\n" }] }}
		];
		
		const dialog = new ModalFormData();
		dialog.title({ translate: `ljw_ww.armor_menu.title`, with: { rawtext: [ { text: "\n" }]} });
		
		dialog.dropdown({ translate: "ljw_ww.armor_menu.armor_type.dropdown.header", with: { rawtext: [{ text: "\n" }] }}, armorTypeArray, Math.min(armorTypeSetting, armorTypeArray.length - 1));
		dialog.dropdown({ translate: "ljw_ww.armor_menu.armor_setting.dropdown.header", with: { rawtext: [{ text: "\n" }] }}, armorSettingArray, armorSetting);
		
		dialog.show(player).then((formData) => {
			if (formData?.formValues != null) {
				player.setDynamicProperty(`ljw_ww:werewolf_armor_type_setting`, formData.formValues[0]);
				player.setDynamicProperty(`ljw_ww:werewolf_armor_setting`, formData.formValues[1]);
				player.setDynamicProperty(`ljw_ww:werewolf_ability_learned`, true);
			}
			
			open_appearance_menu(player);
		});
	}
	catch (err) {
		debug.error(`Armor Menu Error: ${err}`)
	}
}

export function open_change_coat_menu(player, shortcut = false) {
	try {
		const morphList = player.getDynamicProperty("ljw_ww:werewolf_form_list");
		
		
		if (morphList) {
			const dialog = new ActionFormData();
			dialog.title({ translate: `ljw_ww.change_coat_menu.title` });
			dialog.body({ translate: `ljw_ww.change_coat_menu.body`, with: { rawtext: [ { text: "\n" }, { translate: "item.ljw_ww:ability_coat_echo" }]} });
				
			const list = morphList.split(";");
			for (const id of list) {
				if (id.length > 0)
					dialog.button({ translate: `ljw_ww.wolf_name.${id}`, with: { rawtext: [ { text: "\n" }]} }, `textures/ljw/ww/ui/wolf/${id}`);
			}
			
			dialog.show(player).then((response) => {
				if (response?.selection != null) {
					player.setDynamicProperty("ljw_ww:selected_werewolf_form", list[response.selection]);
				}
				
				if (!shortcut)
					open_appearance_menu(player);
			});
		}
		else {
			const dialog = new ActionFormData();
			dialog.title({ translate: `ljw_ww.change_coat_menu.title` });
			dialog.body({ translate: `ljw_ww.change_coat_menu.body.never_transformed`, with: { rawtext: [ { text: "\n" }]} });
			
			dialog.button({ translate: `ljw_ww.general.button.okay`, with: { rawtext: [ { text: "\n" }]} });
			
			dialog.show(player).then((response) => {
				if (!shortcut)
					open_appearance_menu(player);
			});
		}
	}
	catch (err) {
		debug.error(`Coat Change Menu Error: ${err}`)
	}
}

function open_eye_color_menu(player) {
	try {
		const eyeColorSetting = player.getDynamicProperty(`ljw_ww:werewolf_eye_color_setting`) ?? 0;
		const eyeColorArray = [
			{ translate: "ljw_ww.color.yellow", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.blue", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.brown", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.cyan", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.gray", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.green", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.light_blue", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.light_gray", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.lime", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.magenta", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.orange", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.pink", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.purple", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.red", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.black", with: { rawtext: [{ text: "\n" }] }},
			{ translate: "ljw_ww.color.white", with: { rawtext: [{ text: "\n" }] }}
		];
		
		const dialog = new ModalFormData();
		dialog.title({ translate: `ljw_ww.eye_color_menu.title`, with: { rawtext: [ { text: "\n" }]} });
		
		dialog.dropdown({ translate: "ljw_ww.eye_color_menu.dropdown.header", with: { rawtext: [{ text: "\n" }] }}, eyeColorArray, eyeColorSetting);
		
		dialog.show(player).then((formData) => {
			if (formData?.formValues != null) {
				player.setDynamicProperty(`ljw_ww:werewolf_eye_color_setting`, formData.formValues[0]);
				player.setDynamicProperty(`ljw_ww:werewolf_ability_learned`, true);
			}
			
			open_appearance_menu(player);
		});
	}
	catch (err) {
		debug.error(`Eye Color Menu Error: ${err}`)
	}
}

function open_trims_menu(player) {
	try {
		const trimSetting = player.getDynamicProperty(`ljw_ww:werewolf_trim_setting`) ?? 0;
		const trimMaterialSetting = player.getDynamicProperty(`ljw_ww:werewolf_trim_material_setting`) ?? 0;
		const trimListString = player.getDynamicProperty("ljw_ww:trim_pack_list") ?? "";
		const trimList = trimListString.split(";");
		const trimMaterialListString = player.getDynamicProperty("ljw_ww:trim_material_list") ?? "";
		const trimMaterialList = trimMaterialListString.split(";");
		
		const availableTypeIndexes = [ 0 ];
		const availableTypes = [
			{ translate: "ljw_ww.trim_type.none", with: { rawtext: [{ text: "\n" }] }}
		];
		
		const availableMaterialIndexes = [ 0 ];
		const availableMaterials = [
			{ translate: "ljw_ww.trim_type.none", with: { rawtext: [{ text: "\n" }] }}
		];
		
		for (let i = 0; i < trimLibrary.length; i += 1) {
			const type = trimLibrary[i];
			if ((type != "NULL") && trimList.includes(type)) {
				availableTypes.push({ translate: `ljw_ww.trim_type.${type}`, with: { rawtext: [{ text: "\n" }] }});
				availableTypeIndexes.push(i);
			}
		}
		
		for (let i = 0; i < trimMaterialLibrary.length; i += 1) {
			const type = trimMaterialLibrary[i];
			if ((type != "NULL") && trimMaterialList.includes(type)) {
				availableMaterials.push({ translate: `ljw_ww.material.${type}`, with: { rawtext: [{ text: "\n" }] }});
				availableMaterialIndexes.push(i);
			}
		}
		
		const dialog = new ModalFormData();
		dialog.title({ translate: `ljw_ww.trim_settings_menu.title`, with: { rawtext: [ { text: "\n" }]} });
		
		dialog.dropdown({ translate: "ljw_ww.trim_settings_menu.dropdown.trim_type.header", with: { rawtext: [{ text: "\n" }] }}, availableTypes, availableTypeIndexes.indexOf(trimSetting));
		dialog.dropdown({ translate: "ljw_ww.trim_settings_menu.dropdown.trim_material.header", with: { rawtext: [{ text: "\n" }] }}, availableMaterials, availableMaterialIndexes.indexOf(trimMaterialSetting));
		
		dialog.show(player).then((formData) => {
			if (formData?.formValues != null) {
				debug.info(`Set ${availableTypeIndexes[formData.formValues[0]]}`);
				player.setDynamicProperty(`ljw_ww:werewolf_trim_setting`, availableTypeIndexes[formData.formValues[0]]);
				player.setDynamicProperty(`ljw_ww:werewolf_trim_material_setting`, availableMaterialIndexes[formData.formValues[1]]);
				player.setDynamicProperty(`ljw_ww:werewolf_ability_learned`, true);
			}
			
			open_appearance_menu(player);
		});
	}
	catch (err) {
		debug.error(`Trim Menu Error: ${err}`)
	}
}

function open_voice_profile_menu(player) {
	try {
		const voiceProfileSetting = player.getDynamicProperty(`ljw_ww:werewolf_voice_profile_setting`) ?? "default";
		const voiceProfileArray = [
			"default",
			"feral",
			"wolf_vanilla",
			"wolf_big",
			"wolf_grumpy",
			"wolf_mad",
			"wolf_cute",
			"wolf_puglin",
			"wolf_sad"
		];
		const voiceProfileOptionArray = [
			"ljw_ww.sound_variant.default",
			"ljw_ww.sound_variant.feral",
			"ljw_ww.sound_variant.wolf_vanilla",
			"ljw_ww.sound_variant.wolf_big",
			"ljw_ww.sound_variant.wolf_grumpy",
			"ljw_ww.sound_variant.wolf_mad",
			"ljw_ww.sound_variant.wolf_cute",
			"ljw_ww.sound_variant.wolf_puglin",
			"ljw_ww.sound_variant.wolf_sad"
		];
		
		const dialog = new ModalFormData();
		dialog.title({ translate: `ljw_ww.voice_profile_menu.title`, with: { rawtext: [ { text: "\n" }]} });
		
		dialog.dropdown({ translate: "ljw_ww.voice_profile_menu.dropdown.header", with: { rawtext: [{ text: "\n" }] }}, voiceProfileOptionArray, voiceProfileArray.indexOf(voiceProfileSetting));
		
		dialog.show(player).then((formData) => {
			if (formData?.formValues != null) {
				if (formData.formValues[0] == 0) {
					player.setDynamicProperty(`ljw_ww:werewolf_voice_profile_setting`);
				}
				else {
					player.setDynamicProperty(`ljw_ww:werewolf_voice_profile_setting`, voiceProfileArray[formData.formValues[0]]);
				}
				system.runTimeout(() => {player.runCommand(`/scriptevent ljw_ww:werewolf_sound angry`)}, 2);
			}
			
			open_appearance_menu(player);
		});
	}
	catch (err) {
		debug.error(`Voice Profile Menu Error: ${err}`)
	}
}

export function test_new_variant(player, wolf) {
	try {
		let morphList = player.getDynamicProperty("ljw_ww:werewolf_form_list") ?? "";
		debug.info(morphList)
		const id = wolfTypeIds[wolf.typeId];
		if (id == null) {
			system.runTimeout(() => {if (wolf != null) wolf.dimension.spawnParticle("ljw_ww:pointer_error", wolf.location);}, 7);
			if (wolf.typeId.includes("ljw_wp")) {
				player.sendMessage({ translate: "ljw_ww.coat_echo.scan_incompatible_wolves_plus", with: { rawtext: [ { text: "\n" }]} });
			}
			else {
				player.sendMessage({ translate: "ljw_ww.coat_echo.scan_incompatible", with: { rawtext: [ { text: "\n" }]} });
			}
			return;
		}
		
		const variant = wolf.getComponent("minecraft:variant")?.value ?? 0;
		const markVariant = wolf.getComponent("minecraft:mark_variant")?.value ?? 0;
		
		const scanId = (id || variant || markVariant) ? (id + variant * 100 + markVariant * 1000).toString() : "000";
		
		if (morphList.indexOf(scanId) == -1) {
			morphList += `${scanId};`;
			player.sendMessage({ translate: "ljw_ww.coat_echo.scan_success", with: { rawtext: [ { text: "\n" }, { translate: `ljw_ww.wolf_name.${scanId}` }]} });
			system.runTimeout(() => {if (wolf != null) wolf.dimension.spawnParticle("ljw_ww:pointer_new", wolf.location);}, 7);
			system.runTimeout(() => {if (wolf != null) wolf.dimension.spawnParticle("ljw_ww:detect_wave_1", player.location);}, 5);
			system.runTimeout(() => {if (wolf != null) wolf.dimension.spawnParticle("ljw_ww:detect_wave_2", player.location);}, 5);
			system.runTimeout(() => {if (wolf != null) wolf.dimension.spawnParticle("ljw_ww:scan_wave_1", wolf.location);}, 1);
			system.runTimeout(() => {if (wolf != null) wolf.dimension.spawnParticle("ljw_ww:scan_wave_2", wolf.location);}, 1);
			player.setDynamicProperty("ljw_ww:werewolf_form_list", morphList);
		}
		else {
			system.runTimeout(() => {if (wolf != null) wolf.dimension.spawnParticle("ljw_ww:pointer_existing", wolf.location);}, 7);
			player.sendMessage({ translate: "ljw_ww.coat_echo.scan_failed", with: { rawtext: [ { text: "\n" }]} });
			system.runTimeout(() => {open_change_coat_menu(player, true);}, 1);
		}
	}
	catch(err) {
		debug.error(`Variant test error: ${err}`);
	}
}