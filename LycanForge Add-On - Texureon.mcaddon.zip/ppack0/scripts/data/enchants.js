import { EnchantmentType } from "@minecraft/server";
export const vanishing = new EnchantmentType("vanishing");
export const protection = new EnchantmentType("protection");
export const respiration = new EnchantmentType("respiration");
export const aqua_affinity = new EnchantmentType("aqua_affinity");
export const swift_sneak = new EnchantmentType("swift_sneak");
export const feather_falling = new EnchantmentType("feather_falling");
export const depth_strider = new EnchantmentType("depth_strider");