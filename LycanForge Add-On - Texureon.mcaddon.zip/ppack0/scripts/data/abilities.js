export const miningStaminaMax = 100;
export const berserkerRageDuration = 20 * 60;
export const climbingDurations = [ 15, 30, 100, 1000 ];
export const packMenderCost = 0.25;
export const packMenderRestoreAmount = 8;
export const lycanGuardTimeLimitMS = 300000;
export const lycanGuardDistanceLimit = 1500;
export const baseDurabilityPenalty = 1.75;
export const durabilityPenaltyRecoveredPerLevel = 0.25;
export const werewolfDurabilityPenalty = 1;

export const list = {
	"howl": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 0 ], rechargeTime: 3000, activatedByItem: true },
	"coat_echo": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 0 ], activatedByItem: true },
	"defense_up": { maxLevel: 8, unlockLevels: [ 0, 1, 2, 3, 4, 4, 4, 4 ], unlockXP: [ 50, 75, 100, 125, 150, 175, 200, 300 ]},
	"hp_up": { maxLevel: 5, unlockLevels: [ 0, 1, 2, 3, 4 ], unlockXP: [ 150, 160, 170, 180, 200 ]},
	"agility": { maxLevel: 1, unlockLevels: [ 2 ], unlockXP: [ 80 ]},
	"dexterity": { maxLevel: 3, unlockLevels: [ 1, 2, 3 ], unlockXP: [ 150, 200, 250 ]},
	"form_shift": { maxLevel: 1, unlockLevels: [ 2 ], unlockXP: [ 200 ], rechargeTime: 10000, activatedByItem: true},
	"scent_tracker": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 100 ], activatedByItem: true },
	"auto_regen": { maxLevel: 2, unlockLevels: [ 1, 3 ], unlockXP: [ 50, 75 ] },
	"feather_falling": { maxLevel: 4, unlockLevels: [ 1, 2, 3, 4 ], unlockXP: [ 20, 30, 40, 50 ]},
	"cave_wolf": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 50 ]},
	"always_wolf": { maxLevel: 2, unlockLevels: [ 4, 4 ], unlockXP: [ 150, 500 ]},
	"night_vision": { maxLevel: 2, unlockLevels: [ 1, 3 ], unlockXP: [ 50, 100 ], cheatUnlockLevel: 1},
	"undercoat": { maxLevel: 2, unlockLevels: [ 0, 2 ], unlockXP: [ 15, 20 ]},
	"sharp_claws": { maxLevel: 5, unlockLevels: [ 0, 0, 1, 2, 3 ], unlockXP: [ 30, 40, 65, 75, 100 ]},
	"climbers_claws": { maxLevel: 4, unlockLevels: [ 0, 1, 2, 4 ], unlockXP: [ 40, 60, 80, 100 ]},
	"berserker_rage": { maxLevel: 1, unlockLevels: [ 3 ], unlockXP: [ 250 ], rechargeTime: 150000, activatedByItem: true},
	"lycan_guard": { maxLevel: 1, unlockLevels: [ 3 ], unlockXP: [ 200 ], activatedByItem: true},
	"wide_claw": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 25 ], rechargeTime: 1000, activatedByItem: true},
	"wild_claw": { maxLevel: 1, unlockLevels: [ 2 ], unlockXP: [ 75 ], rechargeTime: 750, activatedByItem: true},
	"mining_claw": { maxLevel: 1, unlockLevels: [ 1 ], unlockXP: [ 150 ], chargeMinimum: 0, activatedByItem: true},
	"tree_cutter": { maxLevel: 1, unlockLevels: [ 2 ], unlockXP: [ 200 ], rechargeTime: 5000, activatedByItem: true},
	"pack_mender": { maxLevel: 1, unlockLevels: [ 3 ], unlockXP: [ 150 ], chargeMinimum: 100 * packMenderCost, activatedByItem: true},
	"pack_call": { maxLevel: 1, unlockLevels: [ 1 ], unlockXP: [ 150 ], rechargeTime: 10000, activatedByItem: true},
	"pack_leader": { maxLevel: 1, unlockLevels: [ 2 ], unlockXP: [ 150 ]},
	
	"jump_dash": { maxLevel: 1, unlockLevels: [ 3 ], unlockXP: [ 100 ], emblemClass: "flow"},
	"wind_claw": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 25 ], activatedByItem: true, rechargeTime: 5000, emblemClass: "flow"},
	"battle_vigor": { maxLevel: 3, unlockLevels: [ 1, 3, 4 ], unlockXP: [ 50, 60, 100 ], emblemClass: "flow" },
	
	"diving_mastery": { maxLevel: 3, unlockLevels: [ 1, 3, 3 ], unlockXP: [ 80, 80, 80 ] },
	
	"enfeebling_howl": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 120 ], rechargeTime: 20000, activatedByItem: true, emblemClass: "echo"},
	"confusing_howl": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 120 ], rechargeTime: 20000, activatedByItem: true, emblemClass: "echo"},
	"battle_howl": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 120 ], rechargeTime: 20000, activatedByItem: true, emblemClass: "echo"},
	"speed_stealth": { maxLevel: 3, unlockLevels: [ 2, 3, 3 ], unlockXP: [ 25, 30, 40 ], emblemClass: "echo"},
	
	"starfang_strike": { maxLevel: 5, unlockLevels: [ 0, 1, 2, 3, 4 ], unlockXP: [ 100, 200, 300, 400, 500 ], rechargeTime: 30000, activatedByItem: true, emblemClass: "star" },
	
	"leap_of_flight": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 500 ], emblemClass: "end"},
	"lunar_leap": { maxLevel: 1, unlockLevels: [ 0 ], unlockXP: [ 100 ], activatedByItem: true, emblemClass: "end"}
}

export const emblemClasses = ["base", "flow", "echo", "star", "end"];

export const treeCutterMaxNumBlocks = 32;
export const treeCutterBlocks = [
	"minecraft:oak_log",
	"minecraft:spruce_log",
	"minecraft:birch_log",
	"minecraft:jungle_log",
	"minecraft:acacia_log",
	"minecraft:dark_oak_log",
	"minecraft:mangrove_log",
	"minecraft:cherry_log",
	"minecraft:mushroom_stem",
	"minecraft:red_mushroom_block",
	"minecraft:brown_mushroom_block",
	"minecraft:warped_stem",
	"minecraft:crimson_stem"
]
export function is_tree_cutter_block(block) {
	return (block.hasTag("log") || treeCutterBlocks.includes(block.typeId));
}
export const treeCutterGroundBlocks = [
	"minecraft:dirt",
	"minecraft:coarse_dirt",
	"minecraft:dirt_with_roots",
	"minecraft:grass_block",
	"minecraft:podzol",
	"minecraft:mycelium",
	"minecraft:moss_block",
	"minecraft:mud",
	"minecraft:netherrack",
	"minecraft:crimson_nylium",
	"minecraft:warped_nylium"
];
export function is_tree_cutter_ground_block(block) {
    return treeCutterGroundBlocks.includes(block.typeId);
}
export const starfangStrikeConfigs = [
  { dashDistance: 12, damage: 20 },
  { dashDistance: 24, damage: 24 },
  { dashDistance: 36, damage: 28 },
  { dashDistance: 48, damage: 32 },
  { dashDistance: 64, damage: 36 }
];