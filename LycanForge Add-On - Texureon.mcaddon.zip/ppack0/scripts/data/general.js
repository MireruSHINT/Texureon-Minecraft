export const lunarburnExposureMax = [35, 100];
export const lunarburnExposureEffectThreshold = lunarburnExposureMax[1] * 0.3;
export const lunarburnExposureHazardThreshold = lunarburnExposureMax[1] * 0.5;
export const lunarburnExposureDangerThreshold = lunarburnExposureMax[1] * 0.8;
