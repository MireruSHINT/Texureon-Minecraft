import {system, world, BlockPermutation} from "@minecraft/server";
const debugBuffer = 2000;
const delimiter = "–";

export function info(line) {
	log_message(`§bINFO§r: ${line}`);
	if (!(world.getDynamicProperty("ljw_ww:enable_debug_logging") ?? false)) return;
	sendMessage(`[DEBUG] §bINFO§r: ${line}`);
	console.warn(`[DEBUG] INFO: ${line}`);
}
export function warn(line) {
	log_message(`§eWARN§r: ${line}`);
	if (!(world.getDynamicProperty("ljw_ww:enable_debug_logging") ?? false)) return;
	sendMessage(`[DEBUG] §eWARN§r: ${line}`);
	console.warn(`[DEBUG] WARN: ${line}`);
}
export function error(line) {
	log_message(`§cERROR§r: ${line}`);
	if (!(world.getDynamicProperty("ljw_ww:enable_debug_logging") ?? false)) return;
	sendMessage(`[DEBUG] §cERROR§r: ${line}`);
	console.warn(`[DEBUG] ERROR: ${line}`);
}
function sendMessage(line) {
	const debugPlayers = world.getPlayers({tags: ["ljw_ww_debug_chat"]});
	for (const debugPlayer of debugPlayers) {
		debugPlayer.sendMessage(line);
	}
}

function log_message(line) {
	const current = (world.getDynamicProperty("ljw_ww:debug_log") ?? "");
	world.setDynamicProperty("ljw_ww:debug_log", (current + line + delimiter).substr(Math.max(0, current.length + line.length - debugBuffer), current.length + line.length + 1));
}

system.afterEvents.scriptEventReceive.subscribe(e => {
	if (e.id == "ljw_ww:toggle_debug")
	{
		world.setDynamicProperty("ljw_ww:enable_debug_logging", !(world.getDynamicProperty("ljw_ww:enable_debug_logging") ?? false));
		world.sendMessage(`Debug logging: ${(world.getDynamicProperty("ljw_ww:enable_debug_logging") ?? false)}`);
	}
	else if (e.id == "ljw_ww:debug_log")
	{
		const lines = (world.getDynamicProperty("ljw_ww:debug_log") ?? "").split(delimiter);
		for (const line of lines)
			world.sendMessage(`${line}`);
	}
	else if (e.id == "ljw_ww:password") {
		const entity = e.sourceEntity;
		const code = e.message.replaceAll(" ", "").toUpperCase();
		switch (code) {
			case "ACHEATTHATSPRETTYGREATTOCHANGEHOWWEREWOLVESANIMATE":
				entity.sendMessage("Code accepted.");
				world.setDynamicProperty("ljw_ww:setting_enable_custom_anims", !(world.getDynamicProperty("ljw_ww:setting_enable_custom_anims") ?? false));
				return;
			case "THISSECRETCODEENABLESFORGEDEBUGMODE":
				entity.sendMessage("Code accepted.");
				world.setDynamicProperty("ljw_ww:setting_forge_debug", !(world.getDynamicProperty("ljw_ww:setting_forge_debug") ?? false));
				return;
			case "ABILITIESNOWCOSTZEROXPSOTHERESMOREEXPERIENCEFORME":
				entity.sendMessage("Code accepted.");
				world.setDynamicProperty("ljw_ww:setting_free_abilities", !(world.getDynamicProperty("ljw_ww:setting_free_abilities") ?? false));
				return;
			case "WHYSPENDALLTHATTIMEWHENALLABILITIESCOULDBEMINE":
				entity.sendMessage("Code accepted.");
				entity.runCommandAsync("scriptevent ljw_ww:ability_unlock_cheat");
				return;
			case "NONEEDFORNETHERITEUSETHISCODETOREACHMAXMIGHT":
				entity.sendMessage("Code accepted.");
				entity.setDynamicProperty("ljw_ww:werewolf_level", 4);
				return;
			case "UNLOCKEVERYCUSTOMIZATIONFORYOURWEREWOLFTRANSFORMATION":
				entity.sendMessage("Code accepted.");
				entity.runCommandAsync("scriptevent ljw_ww:appearance_unlock_cheat");
				return;
			case "RESETALLCONFIGURATIONSTOTESTTHEWEREWOLFTRANSFORMATIONS":
				entity.sendMessage("Code accepted.");
				entity.runCommandAsync("scriptevent ljw_ww:reset_progress");
				entity.setDynamicProperty("ljw_ww:werewolf_form_list");
				entity.setDynamicProperty("ljw_ww:selected_werewolf_form");
				return;
			case "CLEARALLFORMSYOUGETWITHANAPPEARANCELISTRESET":
				entity.sendMessage("Code accepted.");
				entity.setDynamicProperty("ljw_ww:werewolf_form_list");
				entity.setDynamicProperty("ljw_ww:selected_werewolf_form");
				return;
			case "TOGGLEWEREWOLFTRANSFORMATIONFORDEBUGCONTEMPLATION":
				entity.sendMessage("Code accepted.");
				entity.setDynamicProperty("ljw_ww:werewolf_form_enabled", !(entity.getDynamicProperty("ljw_ww:werewolf_form_enabled") ?? false));
				return;
			case "HOWLFORCE_UP":
				entity.sendMessage("Code accepted.");
				const howlForceA = world.getDynamicProperty("ljw_ww:howl_force_modifier") ?? 0.0;
				world.setDynamicProperty("ljw_ww:howl_force_modifier", howlForceA + 2.0);
				return;
			case "HOWLFORCE_DOWN":
				entity.sendMessage("Code accepted.");
				const howlForceB = world.getDynamicProperty("ljw_ww:howl_force_modifier") ?? 0.0;
				world.setDynamicProperty("ljw_ww:howl_force_modifier", howlForceB - 2.0);
				return;
			case "HOWLFORCE_RESET":
				entity.sendMessage("Code accepted.");
				world.setDynamicProperty("ljw_ww:howl_force_modifier");
				return;
			case "EXPERIMENT_TRACKITEMS":
				entity.sendMessage("Code accepted.");
				world.setDynamicProperty("ljw_ww:item_tracking_experiment", !(world.getDynamicProperty("ljw_ww:item_tracking_experiment") ?? false));
				return;
			default:
				entity.sendMessage("Invalid code.");
		}
	}
});