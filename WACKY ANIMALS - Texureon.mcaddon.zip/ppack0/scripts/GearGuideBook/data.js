// IMPORTANT: DON'T CHANGE THAT FILE THAT CAN BREAK PROJECT IN GUIDEBOOK EDITOR
export default  {
  "pages": {
    "bd555": {
      "id": "bd555",
      "name": "Wacky Hamster",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_hamster.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 10\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Plains\n\u003e §6#text.wacky_animals.tameable_with.name~§r: Sweetberry, Carrot\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_hamster"
        }
      ]
    },
    "67ef3": {
      "id": "67ef3",
      "name": "Wacky Dog",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_dog.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Forest, Plains\n\u003e §6#text.wacky_animals.tameable_with.name~§r: Bone\n\n------[ Wild ]------\n\n\u003e §6#text.wacky_animals.attack.name~§r: #text.wacky_animals.skeleton.name, #text.wacky_animals.sheep.name, #text.wacky_animals.rabbit.name, #text.wacky_animals.fox.name\n\u003e §6#text.wacky_animals.avoids.name~§r: #text.wacky_animals.llama.name\n\u003e §6#text.wacky_animals.hp.name~§r: 40\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_dog"
        }
      ]
    },
    "5766c3": {
      "id": "5766c3",
      "name": "Zebra",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.zebra.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.avoids.name~§r: #text.wacky_animals.lion.name\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/zebra"
        }
      ]
    },
    "dfe29b": {
      "id": "dfe29b",
      "name": "T-Rex",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.trex.name"
      },
      "body": {
        "content": "§l-\u003e §c#text.wacky_animals.hostile.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 60\n\u003e §6#text.wacky_animals.attack.name~§r: #text.wacky_animals.player.name, #text.wacky_animals.deer.name, #text.wacky_animals.zebra.name, #text.wacky_animals.kiwi.name, #text.wacky_animals.duck.name, #text.wacky_animals.mouse.name, #text.wacky_animals.hamster.name, #text.wacky_animals.rabbit.name, #text.wacky_animals.guinea_pig.name, #text.wacky_animals.chicken.name, #text.wacky_animals.kangaroo.name, #text.wacky_animals.elephant.name\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Forest, Plains, Jungle\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/t_rex"
        }
      ]
    },
    "7ea277": {
      "id": "7ea277",
      "name": "Kiwi",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.kiwi.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 10\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Forest\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/kiwi"
        }
      ]
    },
    "e2a1f": {
      "id": "e2a1f",
      "name": "Wacky Snake",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_snake.name"
      },
      "body": {
        "content": "§l-\u003e §a#text.wacky_animals.neutral.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Swamp, Mangrove Swamp\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_snake"
        }
      ]
    },
    "fd8b3e": {
      "id": "fd8b3e",
      "name": "Butterfly",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.butterfly.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 3\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Plains\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/butterfly"
        }
      ]
    },
    "a4c013": {
      "id": "a4c013",
      "name": "Roccoon",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.raccoon.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Forest, Jungle\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/raccoon"
        }
      ]
    },
    "b90c7": {
      "id": "b90c7",
      "name": "Wacky Ferret",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_ferret.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 15\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Plains\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_ferret"
        }
      ]
    },
    "09be9": {
      "id": "09be9",
      "name": "Wacky Fish",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_fish.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 5\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Ocean, River\n\u003e §6#text.wacky_animals.avoids.name~§r: #text.wacky_animals.axolotl.name\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_fish"
        }
      ]
    },
    "0ad4d": {
      "id": "0ad4d",
      "name": "Wacky Frog",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_frog.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 15\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Swamp, Mangrove Swamp\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_frog"
        }
      ]
    },
    "1ab35": {
      "id": "1ab35",
      "name": "Wacky Cat",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_cat.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.tameable_with.name~§r: Fish (cod), Salmon\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Villages\n\n------[ Wild ]------\n\n\u003e §6#text.wacky_animals.attack.name~§r: #text.wacky_animals.rabbit.name, #text.wacky_animals.mouse.name\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_cat"
        }
      ]
    },
    "b2702": {
      "id": "b2702",
      "name": "Wacky Guinea Pig",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_guinea_pig.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 10\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Plains\n\u003e §6#text.wacky_animals.tameable_with.name~§r: Sweetberry, Carrot\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_guine_pig"
        }
      ]
    },
    "014975": {
      "id": "014975",
      "name": "Duck",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.duck.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 10\n\u003e §6#text.wacky_animals.spawn_on.name~§r: River\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/duck"
        }
      ]
    },
    "145886": {
      "id": "145886",
      "name": "Squirrel",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.squirrel.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 15\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Forest, Plains\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/squirrel"
        }
      ]
    },
    "05d789": {
      "id": "05d789",
      "name": "Hawk",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.hawk.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Mountains\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/hawk"
        }
      ]
    },
    "47354": {
      "id": "47354",
      "name": "Wacky Sloth",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_sloth.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Forest\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/sloth"
        }
      ]
    },
    "2920f": {
      "id": "2920f",
      "name": "Wacky Parrot",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_parrot.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 15\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Jungle\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_parrot"
        }
      ]
    },
    "88686": {
      "id": "88686",
      "name": "Wacky Pigeon",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_pigeon.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 10\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Plains, Forest\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_pigeon"
        }
      ]
    },
    "758935": {
      "id": "758935",
      "name": "Deer",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.deer.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.avoids.name~§r: #text.wacky_animals.lion.name, Wolf, Polarbear, #text.wacky_animals.not_sneaking_players.name\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Florest, Taiga\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/deer"
        }
      ]
    },
    "4af5ef": {
      "id": "4af5ef",
      "name": "Giraffe",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.giraffe.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/giraffe"
        }
      ]
    },
    "93df9b": {
      "id": "93df9b",
      "name": "Shark",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.shark.name"
      },
      "body": {
        "content": "§l-\u003e §c#text.wacky_animals.hostile.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.attack.name~§r: #text.wacky_animals.any_mob_water.name\n\u003e §6#text.wacky_animals.tameable_with.name~§r: none\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Ocean\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/shark"
        }
      ]
    },
    "15894": {
      "id": "15894",
      "name": "Wacky Turtle",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_turtle.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 30\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Swamp, Plains, Mangrove Swamp\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_turtle"
        }
      ]
    },
    "db3f41": {
      "id": "db3f41",
      "name": "dash",
      "title": {
        "content": "#text.wacky_animals.guidebook.name"
      },
      "body": {
        "content": ""
      },
      "content": "",
      "buttons": [
        {
          "destination": "fd8b3e",
          "text": "#text.wacky_animals.butterfly.name",
          "iconPath": "textures/wacky/animals/common/icons/butterfly"
        },
        {
          "destination": "34a617",
          "text": "#text.wacky_animals.cappybara.name",
          "iconPath": "textures/wacky/animals/common/icons/cappybara"
        },
        {
          "destination": "758935",
          "text": "#text.wacky_animals.deer.name",
          "iconPath": "textures/wacky/animals/common/icons/deer"
        },
        {
          "destination": "014975",
          "text": "#text.wacky_animals.duck.name",
          "iconPath": "textures/wacky/animals/common/icons/duck"
        },
        {
          "destination": "4bb9e2",
          "text": "#text.wacky_animals.elephant.name",
          "iconPath": "textures/wacky/animals/common/icons/elephant"
        },
        {
          "destination": "4af5ef",
          "text": "#text.wacky_animals.giraffe.name",
          "iconPath": "textures/wacky/animals/common/icons/giraffe"
        },
        {
          "destination": "05d789",
          "text": "#text.wacky_animals.hawk.name",
          "iconPath": "textures/wacky/animals/common/icons/hawk"
        },
        {
          "destination": "96b08a",
          "text": "#text.wacky_animals.kangaroo.name",
          "iconPath": "textures/wacky/animals/common/icons/kangaroo"
        },
        {
          "destination": "7ea277",
          "text": "#text.wacky_animals.kiwi.name",
          "iconPath": "textures/wacky/animals/common/icons/kiwi"
        },
        {
          "destination": "bd71bf",
          "text": "#text.wacky_animals.lion.name",
          "iconPath": "textures/wacky/animals/common/icons/lion"
        },
        {
          "destination": "f53c54",
          "text": "#text.wacky_animals.monkey.name",
          "iconPath": "textures/wacky/animals/common/icons/monkey"
        },
        {
          "destination": "230941",
          "text": "#text.wacky_animals.penguin.name",
          "iconPath": "textures/wacky/animals/common/icons/penguin"
        },
        {
          "destination": "a4c013",
          "text": "#text.wacky_animals.raccoon.name",
          "iconPath": "textures/wacky/animals/common/icons/raccoon"
        },
        {
          "destination": "21a5f5",
          "text": "#text.wacky_animals.seal.name",
          "iconPath": "textures/wacky/animals/common/icons/seal"
        },
        {
          "destination": "93df9b",
          "text": "#text.wacky_animals.shark.name",
          "iconPath": "textures/wacky/animals/common/icons/shark"
        },
        {
          "destination": "0592c5",
          "text": "#text.wacky_animals.sloth.name",
          "iconPath": "textures/wacky/animals/common/icons/sloth"
        },
        {
          "destination": "145886",
          "text": "#text.wacky_animals.squirrel.name",
          "iconPath": "textures/wacky/animals/common/icons/squirrel"
        },
        {
          "destination": "dfe29b",
          "text": "#text.wacky_animals.trex.name",
          "iconPath": "textures/wacky/animals/common/icons/t_rex"
        },
        {
          "destination": "95fdd4",
          "text": "#text.wacky_animals.hedgehog.name",
          "iconPath": "textures/wacky/animals/common/icons/hedgehog"
        },
        {
          "destination": "5766c3",
          "text": "#text.wacky_animals.zebra.name",
          "iconPath": "textures/wacky/animals/common/icons/zebra"
        },
        {
          "destination": "1ab35",
          "text": "#text.wacky_animals.wacky_cat.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_cat"
        },
        {
          "destination": "67ef3",
          "text": "#text.wacky_animals.wacky_dog.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_dog"
        },
        {
          "destination": "b90c7",
          "text": "#text.wacky_animals.wacky_ferret.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_ferret"
        },
        {
          "destination": "09be9",
          "text": "#text.wacky_animals.wacky_fish.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_fish"
        },
        {
          "destination": "a82c3",
          "text": "#text.wacky_animals.wacky_flamingo.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_flamingo"
        },
        {
          "destination": "0ad4d",
          "text": "#text.wacky_animals.wacky_frog.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_frog"
        },
        {
          "destination": "b2702",
          "text": "#text.wacky_animals.wacky_guinea_pig.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_guine_pig"
        },
        {
          "destination": "bd555",
          "text": "#text.wacky_animals.wacky_hamster.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_hamster"
        },
        {
          "destination": "8e8bd",
          "text": "#text.wacky_animals.wacky_koala.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_koala"
        },
        {
          "destination": "437a0",
          "text": "#text.wacky_animals.wacky_lizard.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_lizard"
        },
        {
          "destination": "84fc5",
          "text": "#text.wacky_animals.wacky_mouse.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_mouse"
        },
        {
          "destination": "2920f",
          "text": "#text.wacky_animals.wacky_parrot.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_parrot"
        },
        {
          "destination": "88686",
          "text": "#text.wacky_animals.wacky_pigeon.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_pigeon"
        },
        {
          "destination": "9f3ae",
          "text": "#text.wacky_animals.wacky_rabbit.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_rabbit"
        },
        {
          "destination": "47354",
          "text": "#text.wacky_animals.wacky_sloth.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_sloth"
        },
        {
          "destination": "e2a1f",
          "text": "#text.wacky_animals.wacky_snake.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_snake"
        },
        {
          "destination": "15894",
          "text": "#text.wacky_animals.wacky_turtle.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_turtle"
        }
      ]
    },
    "34a617": {
      "id": "34a617",
      "name": "Cappybara",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.cappybara.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Swamp\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/cappybara"
        }
      ]
    },
    "8e8bd": {
      "id": "8e8bd",
      "name": "Wacky Koala",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_koala.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Jungle\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_koala"
        }
      ]
    },
    "f53c54": {
      "id": "f53c54",
      "name": "Monkey",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.monkey.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Jungle\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/monkey"
        }
      ]
    },
    "230941": {
      "id": "230941",
      "name": "Penguin",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.penguin.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 15\n\u003e §6#text.wacky_animals.attack.name~§r: none\n\u003e §6#text.wacky_animals.tameable_with.name~§r: none\n\u003e §6#text.wacky_animals.avoids.name~§r: none\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Ice Plains, Ice Plains Spikers, Frozen Ocean\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/penguin"
        }
      ]
    },
    "84fc5": {
      "id": "84fc5",
      "name": "Wacky Mouse",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_mouse.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 10\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Plains, Forest\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_mouse"
        }
      ]
    },
    "21a5f5": {
      "id": "21a5f5",
      "name": "Seal",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.seal.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Ocean, Cold Ocean\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/seal"
        }
      ]
    },
    "437a0": {
      "id": "437a0",
      "name": "Wacky Lizard",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_lizard.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 15\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Swamp, Mangrove Swamp\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_lizard"
        }
      ]
    },
    "95fdd4": {
      "id": "95fdd4",
      "name": "Hedgehog",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_flamingo.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 10\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Forest, Desert\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/hedgehog"
        }
      ]
    },
    "bd71bf": {
      "id": "bd71bf",
      "name": "Lion",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.lion.name"
      },
      "body": {
        "content": "§l-\u003e §c#text.wacky_animals.hostile.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 30\n\u003e §6#text.wacky_animals.attack.name~§r: #text.wacky_animals.player.name, #text.wacky_animals.deer.name, #text.wacky_animals.zebra.name, #text.wacky_animals.kiwi.name, #text.wacky_animals.duck.name, #text.wacky_animals.mouse.name, #text.wacky_animals.hamster.name, #text.wacky_animals.rabbit.name, #text.wacky_animals.guinea_pig.name, #text.wacky_animals.kangaroo.name\n\u003e §6#text.wacky_animals.avoids.name~§r:  #text.wacky_animals.elephant.name\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/lion"
        }
      ]
    },
    "9f3ae": {
      "id": "9f3ae",
      "name": "Wacky Rabbit",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_rabbit.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 15\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Taiga, Flower Forest, Snowy Slopes, Grove, Meadow, Cherry Grove\n\u003e §6#text.wacky_animals.avoids.name~§r: #text.wacky_animals.lion.name\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_rabbit"
        }
      ]
    },
    "a82c3": {
      "id": "a82c3",
      "name": "Wacky Flamingo",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.wacky_flamingo.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Swamp\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_flamingo"
        }
      ]
    },
    "4bb9e2": {
      "id": "4bb9e2",
      "name": "Elephant",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.elephant.name"
      },
      "body": {
        "content": "§l-\u003e §a#text.wacky_animals.neutral.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 60\n\u003e §6#text.wacky_animals.avoids.name~§r: #text.wacky_animals.mouse.name\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna\n\n* #text.wacky_animals.knock_resistence.name\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/elephant"
        }
      ]
    },
    "96b08a": {
      "id": "96b08a",
      "name": "Kangaroo",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.kangaroo.name"
      },
      "body": {
        "content": "§l-\u003e §a#text.wacky_animals.neutral.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 30\n\u003e §6#text.wacky_animals.avoids.name~§r: #text.wacky_animals.lion.name\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/kangaroo"
        }
      ]
    },
    "0592c5": {
      "id": "0592c5",
      "name": "Sloth",
      "title": {
        "content": "#text.wacky_animals.guidebook.name | #text.wacky_animals.sloth.name"
      },
      "body": {
        "content": "§l-\u003e §b#text.wacky_animals.passive.name§r\n\n\u003e §6#text.wacky_animals.hp.name~§r: 20\n\u003e §6#text.wacky_animals.spawn_on.name~§r: Savanna, Forest\n"
      },
      "content": "",
      "buttons": [
        {
          "destination": "db3f41",
          "text": "#text.wacky_animals.back_button.name",
          "iconPath": "textures/wacky/animals/common/icons/wacky_sloth"
        }
      ]
    }
  },
  "id": "fef28a5b",
  "pack_id": "wacky_animals",
  "home_page": "db3f41"
}