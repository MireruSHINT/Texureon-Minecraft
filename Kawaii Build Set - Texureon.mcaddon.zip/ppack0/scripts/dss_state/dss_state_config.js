/**
 * DSS State System Configuration
 * Configuration constants for the block state cycling system
 */

// Debug settings
export const DEBUG = false;

// Block state configuration
export const STATE_NAME = "dss_block:state";
export const CUSTOM_COMPONENT = "dss_block:state";

// Block type suffixes and their state counts
export const BLOCK_TYPES = {
    "_12": { states: ["1", "2"], maxState: 2 },
    "_13": { states: ["1", "2", "3"], maxState: 3 },
    "_14": { states: ["1", "2", "3", "4"], maxState: 4 }
};

// Sound effects
export const STATE_CHANGE_SOUND = "random.click";

// Performance settings
export const INTERACTION_COOLDOWN = 5; // ticks
export const BATCH_SIZE = 10;

// UI settings
export const UI_DELAY = 20; // ticks 