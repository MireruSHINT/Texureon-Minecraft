/**
 * DSS State System - Main Entry Point
 * Exports all necessary functions and initializes the system
 */

import { world, system } from "@minecraft/server";
import { debug } from "./dss_state_utils.js";
import { 
    initializeDssStateSystem, 
    handleDssStateInteraction, 
    handleStateScriptEvent, 
    getStateSystemStats 
} from "./dss_state_main.js";
import "./dss_state_custom_component.js"; // Auto-registers custom components

//========== SYSTEM INITIALIZATION ==========//

/**
 * Initialize the complete DSS State System
 */
function initializeSystem() {
    debug("Starting DSS State System initialization...");
    // Initialize the main system
    initializeDssStateSystem();
    
    debug("DSS State System fully initialized");
}

//========== WORLD EVENT HANDLERS ==========//

/**
 * Handle world initialization
 */
world.afterEvents.worldInitialize.subscribe(() => {
    debug("World initialized, starting DSS State System...");
    initializeSystem();
});

//========== EXPORTED FUNCTIONS ==========//

// Export main interaction handler
export { handleDssStateInteraction };

// Export utility functions
export { getStateSystemStats };

// Export debug and monitoring functions
export { handleStateScriptEvent };

// Export configuration
export { BLOCK_TYPES, STATE_CHANGE_SOUND } from "./dss_state_config.js";

// Export utilities
export { 
    isDssStateBlock, 
    getCurrentState, 
    getBlockTypeSuffix, 
    formatPos 
} from "./dss_state_utils.js";

// Export custom component functions
export { 
    validateDssStateBlock, 
    initializeDssStateCustomComponents 
} from "./dss_state_custom_component.js";

//========== SYSTEM STATUS ==========//

/**
 * Get system status information
 * @returns {object} Status information
 */
export function getDssStateSystemStatus() {
    const stats = getStateSystemStats();
    
    return {
        initialized: true,
        version: "1.0.0",
        ...stats
    };
}

//========== DEBUG COMMANDS ==========//

/**
 * Debug function to test state cycling
 * @param {object} player - The player to test with
 * @param {object} block - The block to test
 */
export function debugStateCycling(player, block) {
    if (!player || !block) {
        debug("Invalid debug parameters", "warn");
        return false;
    }
    
    debug(`Debug: Testing state cycling for block ${block.typeId} at ${formatPos(block.location)}`);
    
    const result = handleDssStateInteraction(block, player);
    
    debug(`Debug: State cycling result: ${result}`);
    
    return result;
}

//========== SYSTEM READY ==========//

debug("DSS State System module loaded");

// Initialize immediately if world is already loaded
if (world.isValid) {
    system.runTimeout(initializeSystem, 1);
} 