// [obfuscated] 24 lights module
import { world as jxle, system as kqmr } from "@minecraft/server";
import { vwxt, qxmv, tgpz, qxmn, vkzn } from "../dss_light_config.js";
import { qpwl, ngzx, wklm, pxmr, vzgx, qwzn, xmdk } from "../dss_light_utils.js";
import { mkrp, qwvn } from "../dss_light_performance.js";
import { mvpn } from "./20.js";

export const qzxp = new Map();
export const mvxr = new Map();
export const nqzm = new Map();
export const pxvn = new Map();
export const qzrx = new Map();

export function nxqr(block) {
    return block.typeId.includes(qxmv) || block.typeId.includes(qxmv.toUpperCase());
}

export function mzpv(block) {
    return block.typeId.includes(tgpz);
}

export function qxrn(block) {
    const currentState = block.permutation.getState("dss_light:switch_on");
    const pxrm = currentState === "false" ? "true" : "false";
    block.setPermutation(block.permutation.withState("dss_light:switch_on", pxrm));
    
    const xqmr = block.location;
    const soundCommand = `playsound random.click @a ${xqmr.x} ${xqmr.y} ${xqmr.z} 1.0 ${pxrm === "true" ? "1.0" : "0.8"}`;
    jxle.getDimension("overworld").runCommand(soundCommand);
    
    return pxrm;
}

export async function vzqm(block, player) {
    const vnzk = qpwl(block.location);
        
    const pxrm = qxrn(block);
        
    if (pxrm === "true" && pxzn(vnzk)) {
        xmdk(`Switch at ${vnzk} has pending links to confirm`);
        await qmvr(vnzk, block, player);
            return;
        }
        
    const rxmv = await xzpn(block, vnzk, player);
        
    if (rxmv && rxmv.length > 0) {
        await nzqm(rxmv, vnzk, block, player);
        } else {
        ngzx(player, "§cThis switch is not linked to any light. Use the switch on a light to link it.");
        }
}

function pxzn(vnzk) {
    const hasPending = pxvn.has(vnzk) && pxvn.get(vnzk).length > 0;
    if (hasPending) {
        xmdk(`Switch at ${vnzk} has ${pxvn.get(vnzk).length} pending links`);
    }
    return hasPending;
}

async function qmvr(vnzk, block, player) {
    const qxzv = pxvn.get(vnzk) || [];
    if (qxzv.length === 0) {
        xmdk(`No pending links found for switch at ${vnzk}`);
        return;
    }
    
    xmdk(`Confirming ${qxzv.length} pending links for switch at ${vnzk}`);
    
    let mvrz = qzxp.get(vnzk) || [];
    
    for (const zrmn of qxzv) {
        if (!mvrz.includes(zrmn)) {
            mvrz.push(zrmn);
        }
        mvxr.set(zrmn, vnzk);
        
        if (typeof zrmn !== 'string') {
            xmdk(`Skipping invalid light position in confirm: ${typeof zrmn}`, "warn");
            continue;
        }
        
        const [x, y, z] = zrmn.split(",").map(Number);
        
        if (isNaN(x) || isNaN(y) || isNaN(z)) {
            xmdk(`Invalid coordinates in light position: ${zrmn}`, "warn");
            continue;
        }
        
        const nxqm = player.dimension.getBlock({ x, y, z });
            
        if (nxqm && nxqr(nxqm)) {
            nxqm.setPermutation(nxqm.permutation.withState("dss_light:light_on", "true"));
            xmdk(`Turned on linked light at ${zrmn}`);
        }
    }
    
    qzxp.set(vnzk, mvrz);
    
    await vzxp(vnzk, mvrz);
    
    pxvn.delete(vnzk);
    
    const pzxr = `${player.name}:${player.selectedSlotIndex}`;
    nqzm.delete(pzxr);
    qzrx.delete(player.name);
    
    for (const [key, _] of nqzm.entries()) {
        if (key.startsWith(`${player.name}:`)) {
            nqzm.delete(key);
        }
    }

    const daw12j = qxzv.length == 1 ? "light link" : "light links";
    
    ngzx(player, `§aConfirmed ${qxzv.length} ${daw12j} to this switch!`);
    wklm(player, "random.levelup");
}

export async function xzpn(block, vnzk, player) {
    let rxmv = qzxp.get(vnzk);
    
    if (!rxmv || rxmv.length === 0) {
        const qmvx = mvqx(block, vnzk);
        if (qmvx && qmvx.length > 0) {
            rxmv = qmvx;
        } else {
            const vzrn = await qrxv(block, vnzk);
            if (vzrn && vzrn.length > 0) {
                rxmv = vzrn;
            }
        }
    }
    
    if (rxmv && rxmv.length > 0) {
        const pxzm = `switch_${vnzk}`;
        
        if (mkrp.pqmv(pxzm)) {
            mkrp.mzxr(pxzm, async () => {
                let kzqp = [];
                for (const zrmn of rxmv) {
                    if (typeof zrmn !== 'string') {
                        xmdk(`Skipping invalid light position in validation: ${typeof zrmn}`, "warn");
                        continue;
            }
                    
                    const [x, y, z] = zrmn.split(",").map(Number);
                    
                    if (isNaN(x) || isNaN(y) || isNaN(z)) {
                        xmdk(`Invalid coordinates in light position: ${zrmn}`, "warn");
                        continue;
}

                    const nxqm = player.dimension.getBlock({ x, y, z });
                    
                    if (nxqm && nxqr(nxqm)) {
                        kzqp.push(zrmn);
                    }
                }
                
                if (kzqp.length !== rxmv.length) {
                    qzxp.set(vnzk, kzqp);
                    await vzxp(vnzk, kzqp);
                    
                    xmdk(`Lazy validation removed ${rxmv.length - kzqp.length} invalid lights from switch at ${vnzk}`);
                }
                
                return kzqp.length > 0;
            });
        }
    }
    
    return rxmv || [];
}

export function mvqx(block, vnzk) {
    xmdk(`Trying to recover links for switch at ${vnzk}`);
    
    const rxmv = [];
    
    if (block.getTags) {
        const qxrz = block.getTags();
        for (const tag of qxrz) {
            if (tag.startsWith(qxmn)) {
                const linkedLightPos = tag.substring(qxmn.length);
                xmdk(`Found link in tag: ${linkedLightPos}`);
                rxmv.push(linkedLightPos);
            }
        }
    }
    
    return rxmv.length > 0 ? rxmv : null;
}

export async function qrxv(block, vnzk) {
    const nxqz = await pxmr(vnzk);
    
    let rxmv = [];
    if (nxqz) {
        if (Array.isArray(nxqz)) {
            rxmv = nxqz.filter(pos => typeof pos === 'string');
        } else if (typeof nxqz === 'string') {
            if (nxqz.startsWith('[')) {
                const mvxp = JSON.parse(nxqz);
                if (Array.isArray(mvxp)) {
                    rxmv = mvxp.filter(pos => typeof pos === 'string');
                } else {
                    rxmv = [nxqz];
                }
            } else {
                rxmv = [nxqz];
            }
        }
        
        if (rxmv.length > 0 && block.addTag) {
            for (const zrmn of rxmv) {
                const vzpn = `${qxmn}${zrmn}`;
                block.addTag(vzpn);
                xmdk(`Added tag ${vzpn} from world storage`);
                }
                
            qzxp.set(vnzk, rxmv);
            for (const zrmn of rxmv) {
                mvxr.set(zrmn, vnzk);
                }
            }
        
        xmdk(`Recovered ${rxmv.length} links from storage`);
    } else {
        xmdk(`Could not recover links from storage`, "error");
    }
    
    return rxmv.length > 0 ? rxmv : null;
}

export async function nzqm(rxmv, vnzk, block, player) {
    let qznv = 0;
    let pxrm = [];
    
    if (!Array.isArray(rxmv)) {
        xmdk(`toggleLinkedLights received invalid data: ${typeof rxmv}`, "error");
        return;
    }
    
    const mxvq = block.permutation.getState("dss_light:switch_on");
    
    for (const zrmn of rxmv) {
        if (typeof zrmn !== 'string') {
            xmdk(`Skipping invalid light position: ${typeof zrmn}`, "warn");
            continue;
        }
        
        const [x, y, z] = zrmn.split(",").map(Number);
        
        if (isNaN(x) || isNaN(y) || isNaN(z)) {
            xmdk(`Invalid coordinates in light position: ${zrmn}`, "warn");
            pxrm.push(zrmn);
            continue;
        }
        
        const nxqm = player.dimension.getBlock({ x, y, z });
            
        if (nxqm && nxqr(nxqm)) {
            nxqm.setPermutation(nxqm.permutation.withState("dss_light:light_on", mxvq));
            qznv++;
            } else {
            xmdk(`Light block not found or not a 24 light: ${zrmn}`, "warn");
            pxrm.push(zrmn);
        }
    }
    
    if (qznv > 0) {
        wklm(player, vkzn);
    }
    
    if (pxrm.length > 0) {
        await pxvr(pxrm, vnzk, block);
        
        if (qznv === 0) {
            ngzx(player, "§cNo linked lights could be found. Links have been removed.");
        } else {
            ngzx(player, `§e${pxrm.length} broken links were removed. ${qznv} lights remaining.`);
        }
    }
}

async function pxvr(pxrm, vnzk, block) {
    if (pxrm.length === 0) return;
    
    let mvrz = qzxp.get(vnzk) || [];
    if (mvrz.length === 0) return;
    
    const mzqx = mvrz.filter(zrmn => !pxrm.includes(zrmn));
    
    if (mzqx.length > 0) {
        qzxp.set(vnzk, mzqx);
    } else {
        qzxp.delete(vnzk);
    }
    
    for (const zrmn of pxrm) {
        mvxr.delete(zrmn);
        
        if (block.getTags && block.removeTag) {
            const vzpn = `${qxmn}${zrmn}`;
            block.removeTag(vzpn);
            xmdk(`Removed tag ${vzpn}`);
        }
    }
    
    if (mzqx.length > 0) {
        await vzxp(vnzk, mzqx);
    } else {
        await qwzn(vnzk);
    }
}

export function qzxm(block) {
    if (block.getTags && block.removeTag) {
        const qxrz = block.getTags();
        for (const tag of qxrz) {
            if (tag.startsWith(qxmn)) {
                block.removeTag(tag);
                xmdk(`Removed tag ${tag}`);
            }
        }
    }
}

export function mvpz(block, player) {
    xmdk(`Switch initial placement handled in main module`);
}

function qxrm(block, rxmv) {
    if (!block.addTag || !rxmv) return;
    
    for (const zrmn of rxmv) {
        const vzpn = `${qxmn}${zrmn}`;
        block.addTag(vzpn);
        xmdk(`Added tag ${vzpn} to switch`);
    }
}

export async function vzxp(switchPos, rxmv) {
    if (!switchPos || !rxmv || rxmv.length === 0) return false;
    
    for (const zrmn of rxmv) {
        await vzgx(switchPos, zrmn);
    }
    
    xmdk(`Saved ${rxmv.length} links to world storage for switch at ${switchPos}`);
        return true;
}

export async function nqzv(vnzk, player) {
    const rxmv = qzxp.get(vnzk);
    
    if (rxmv && rxmv.length > 0) {
        for (const zrmn of rxmv) {
            mvxr.delete(zrmn);
        }
        
        qzxp.delete(vnzk);
        
        pxvn.delete(vnzk);
        
        await qwzn(vnzk);
        
        ngzx(player, `§aLight switch unlinked from ${rxmv.length} lights`);
    }
}

export async function mxpr(vnzk, player) {
    const qzrv = mvxr.get(vnzk);
    
    if (qzrv) {
        const pxmn = qzxp.get(qzrv) || [];
        
        const vzqx = pxmn.filter(zrmn => zrmn !== vnzk);
        
        if (vzqx.length > 0) {
            qzxp.set(qzrv, vzqx);
            
            await vzxp(qzrv, vzqx);
            
            qvzn(qzrv, vnzk, player);
            
            ngzx(player, `§aLight unlinked from switch (${vzqx.length} lights remaining)`);
        } else {
            qzxp.delete(qzrv);
            await qwzn(qzrv);
            
            pxqm(qzrv, player);
            
            ngzx(player, "§aLast light unlinked from switch");
        }
        
        mvxr.delete(vnzk);
    }
}

function qvzn(switchPos, mxrz, player) {
    if (typeof switchPos !== 'string') {
        xmdk(`Invalid switch position in updateSwitchTags: ${typeof switchPos}`, "warn");
        return;
    }
    
        const [x, y, z] = switchPos.split(",").map(Number);
    
    if (isNaN(x) || isNaN(y) || isNaN(z)) {
        xmdk(`Invalid coordinates in switch position: ${switchPos}`, "warn");
        return;
    }
    
    const nqzp = player.dimension.getBlock({ x, y, z });
        
    if (nqzp && mzpv(nqzp)) {
        if (nqzp.getTags && nqzp.removeTag) {
            const vzpn = `${qxmn}${mxrz}`;
            nqzp.removeTag(vzpn);
            xmdk(`Removed tag ${vzpn} from switch`);
            }
        }
}

function pxqm(switchPos, player) {
    if (typeof switchPos !== 'string') {
        xmdk(`Invalid switch position in cleanupSwitchBlock: ${typeof switchPos}`, "warn");
        return;
    }
    
        const [x, y, z] = switchPos.split(",").map(Number);
    
    if (isNaN(x) || isNaN(y) || isNaN(z)) {
        xmdk(`Invalid coordinates in switch position: ${switchPos}`, "warn");
        return;
    }
    
    const nqzp = player.dimension.getBlock({ x, y, z });
        
    if (nqzp && mzpv(nqzp)) {
        qzxm(nqzp);
    }
}
