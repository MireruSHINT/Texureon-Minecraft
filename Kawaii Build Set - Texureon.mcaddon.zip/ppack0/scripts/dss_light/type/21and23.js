// [obfuscated] item-based lights module
import { world as jxle } from "@minecraft/server";
import { pgxm, rxql, vkzn } from "../dss_light_config.js";
import { qrnx, xnpv, rgkl, xmdk } from "../dss_light_utils.js";

const mxqv = ["true", "false"];
const vzpn = jxle.getDimension("overworld");

export function pvrx() {
    jxle.afterEvents.playerInteractWithBlock.subscribe(qzmv);
}

function qzmv({ player, itemStack, block }) {
    if (!qrnx(itemStack, pgxm) || !qrnx(block, rxql)) {
        if (block.typeId.includes("_23")) vzpn.runCommandAsync(`title ${player.name} actionbar Need TV Remote to turn on/off`);
        else if (block.typeId.includes("_24")) vzpn.runCommandAsync(`title ${player.name} actionbar Need to link with a switch to turn on/off`);
        return;
    }

    xnpv(block, "dss_light:light_on", mxqv);

    rgkl(block, vkzn);
    
    xmdk(`Cycled item-based light state for block at ${block.location.x},${block.location.y},${block.location.z}`);
}
