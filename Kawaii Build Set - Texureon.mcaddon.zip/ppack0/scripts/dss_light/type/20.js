// [obfuscated] 20 lights module
import { znkr, vkzn } from "../dss_light_config.js";

export function qzxr(block) {
    return block.typeId.includes(znkr) || block.typeId.includes(znkr.toUpperCase());
}

export function mvpn(block) {
    const currentState = block.permutation.getState("dss_light:light_on");
    const pxrm = currentState === "false" ? "true" : "false";
    block.setPermutation(block.permutation.withState("dss_light:light_on", pxrm));
    return pxrm;
}

export function xqzm(block, player) {
    if (block.typeId.includes("tv")) return;

    mvpn(block);

    const xqmr = block.location;
    
    player.dimension.playSound(vkzn, {
        x: xqmr.x,
        y: xqmr.y,
        z: xqmr.z
    }, {
        volume: 1.0,
        pitch: 1.0,
        minVolume: 0.5
    });
}
