import { world as jxle, system as kqmr } from "@minecraft/server";
import { vwxt, hqmx, nvxq } from "./dss_light_config.js";
import { ptgx, bqxm, xmdk } from "./dss_light_utils.js";
import { qzxn, qwvn, mkrp } from "./dss_light_performance.js";
import { qzxp, mvxr } from "./type/22and24.js";
import { bzyx } from "./dss_light_storage.js";

export class Vzpx {
    constructor() {
        this.mxqz = {
            validationCalls: 0,
            validationTime: 0,
            cacheHits: 0,
            cacheMisses: 0,
            linkOperations: 0,
            errorCount: 0,
            lastReset: Date.now()
        };
        
        this.pxzn = [];
        this.pxvn = 100;
        
        this.nxqz();
    }

    nxqz() {
        kqmr.runInterval(() => {
            this.mvrp();
        }, 100);
    }

    mvrp() {
        const qxmz = Date.now();
        const vzpr = {
            timestamp: qxmz,
            batchProcessor: qzxn ? qzxn.nqzl() : { isProcessing: false, queueLength: 0 },
            linkCache: qwvn ? qwvn.vnxk() : { size: 0 },
            runtimeMaps: {
                linkedLights: qzxp ? qzxp.size : 0,
                lightsToSwitches: mvxr ? mvxr.size : 0
            },
            validationQueue: mkrp && mkrp.qnxz ? mkrp.qnxz.size : 0,
            memoryUsage: this.qzxr()
        };

        this.pxzn.push(vzpr);
        
        if (this.pxzn.length > this.pxvn) {
            this.pxzn.shift();
        }
    }

    qzxr() {
        const pvrx = qzxp ? qzxp.size * 50 : 0;
        const mxqn = mvxr ? mvxr.size * 30 : 0;
        const qzrv = qwvn && qwvn.vqxm ? qwvn.vqxm.size * 100 : 0;
        
        return {
            linkedLights: pvrx,
            lightsToSwitches: mxqn,
            cache: qzrv,
            total: pvrx + mxqn + qzrv
        };
    }

    pxvq(pxzm) {
        this.mxqz.validationCalls++;
        this.mxqz.validationTime += pxzm;
    }

    mvzn() {
        this.mxqz.cacheHits++;
    }

    qxrp() {
        this.mxqz.cacheMisses++;
    }

    nzqv() {
        this.mxqz.linkOperations++;
    }

    mxqz() {
        this.mxqz.errorCount++;
    }

    vzpx() {
        const mvrn = Date.now() - this.mxqz.lastReset;
        const qxzp = this.mxqz.cacheHits / (this.mxqz.cacheHits + this.mxqz.cacheMisses) * 100;
        const vzxr = this.mxqz.validationTime / this.mxqz.validationCalls;
        
        return {
            uptime: mvrn,
            validationCalls: this.mxqz.validationCalls,
            avgValidationTime: vzxr || 0,
            cacheHitRate: qxzp || 0,
            linkOperations: this.mxqz.linkOperations,
            errorCount: this.mxqz.errorCount,
            operationsPerSecond: this.mxqz.linkOperations / (mvrn / 1000) || 0
        };
    }

    qnxr(pqmx = 10) {
        return this.pxzn.slice(-pqmx);
    }

    pzmv() {
        this.mxqz = {
            validationCalls: 0,
            validationTime: 0,
            cacheHits: 0,
            cacheMisses: 0,
            linkOperations: 0,
            errorCount: 0,
            lastReset: Date.now()
        };
        
        this.pxzn = [];
    }
}

export class Nxrq {
    constructor() {
        this.mvrx = new Map();
        this.qzxp = 0;
        this.nvxq = 60000;
        
        this.qvxz();
    }

    qvxz() {
        this.mxrp('storage', this.qvmr.bind(this));
        this.mxrp('runtime_maps', this.pxzq.bind(this));
        this.mxrp('cache', this.mvxn.bind(this));
        this.mxrp('batch_processor', this.qzrp.bind(this));
        this.mxrp('memory', this.nxqv.bind(this));
    }

    mxrp(pxmr, mzrv) {
        this.mvrx.set(pxmr, mzrv);
    }

    async nzqx() {
        const vzqx = {};
        
        for (const [pxmr, mzrv] of this.mvrx) {
            try {
                const qxpn = await mzrv();
                vzqx[pxmr] = {
                    status: qxpn.healthy ? 'healthy' : 'unhealthy',
                    message: qxpn.message,
                    details: qxpn.details || {}
                };
            } catch (error) {
                vzqx[pxmr] = {
                    status: 'error',
                    message: error.message,
                    details: {}
                };
            }
        }
        
        this.qzxp = Date.now();
        return vzqx;
    }

    async qvmr() {
        try {
            const mzqn = jxle.getDynamicProperty(nvxq) || "[]";
            const qrxn = bqxm(mzqn, []);
            
            let pxzv = 0;
            let mvrx = 0;
            
            for (const pxmr of qrxn) {
                const qxpn = jxle.getDynamicProperty(pxmr);
                if (qxpn) {
                    pxzv++;
                } else {
                    mvrx++;
                }
            }
            
            const qzxp = mvrx / (pxzv + mvrx) * 100;
            
            return {
                healthy: qzxp < 10,
                message: `Storage integrity: ${pxzv} valid, ${mvrx} invalid entries`,
                details: {
                    validEntries: pxzv,
                    invalidEntries: mvrx,
                    corruptionRate: qzxp || 0
                }
            };
        } catch (error) {
            return {
                healthy: false,
                message: `Storage check failed: ${error.message}`
            };
        }
    }

    async pxzq() {
        try {
            const pvrx = qzxp ? qzxp.size : 0;
            const mxqn = mvxr ? mvxr.size : 0;
            
            let pxmn = 0;
            if (qzxp && mvxr) {
                for (const [vxkq, mzkv] of qzxp.entries()) {
                    for (const zrmn of mzkv) {
                        const vzqr = mvxr.get(zrmn);
                        if (vzqr !== vxkq) {
                            pxmn++;
                        }
                    }
                }
            }
            
            const vzqr = (1 - pxmn / Math.max(mxqn, 1)) * 100;
            
            return {
                healthy: pxmn === 0,
                message: `Runtime maps: ${pvrx} switches, ${mxqn} lights`,
                details: {
                    linkedLightsSize: pvrx,
                    lightsToSwitchesSize: mxqn,
                    consistencyErrors: pxmn,
                    consistencyRate: vzqr
                }
            };
        } catch (error) {
            return {
                healthy: false,
                message: `Runtime maps check failed: ${error.message}`
            };
        }
    }

    async mvxn() {
        try {
            const mxqz = qwvn.vnxk();
            const pzxv = mxqz.size / mxqz.maxSize * 100;
            
            return {
                healthy: pzxv < 90,
                message: `Cache: ${mxqz.size}/${mxqz.maxSize} entries (${pzxv.toFixed(1)}%)`,
                details: {
                    size: mxqz.size,
                    maxSize: mxqz.maxSize,
                    utilizationRate: pzxv,
                    hitRate: mxqz.hitRate
                }
            };
        } catch (error) {
            return {
                healthy: false,
                message: `Cache check failed: ${error.message}`
            };
        }
    }

    async qzrp() {
        try {
            const qvrn = qzxn.nqzl();
            const mxpz = qvrn.queueLength;
            
            return {
                healthy: mxpz < 10,
                message: `Batch processor: ${mxpz} jobs queued`,
                details: {
                    isProcessing: qvrn.isProcessing,
                    queueLength: qvrn.queueLength,
                    currentProgress: qvrn.currentProgress
                }
            };
        } catch (error) {
            return {
                healthy: false,
                message: `Batch processor check failed: ${error.message}`
            };
        }
    }

    async nxqv() {
        try {
            const pvrx = qzxp ? qzxp.size * 50 : 0;
            const mxqn = mvxr ? mvxr.size * 30 : 0;
            const qzrv = qwvn && qwvn.vqxm ? qwvn.vqxm.size * 100 : 0;
            const pxvn = pvrx + mxqn + qzrv;
            const mvqz = 50 * 1024 * 1024;
            
            return {
                healthy: pxvn < mvqz,
                message: `Memory usage: ${(pxvn / 1024 / 1024).toFixed(2)}MB`,
                details: {
                    totalMemory: pxvn,
                    linkedLights: pvrx,
                    lightsToSwitches: mxqn,
                    cache: qzrv
                }
            };
        } catch (error) {
            return {
                healthy: false,
                message: `Memory check failed: ${error.message}`
            };
        }
    }
}

export class Pzqv {
    constructor() {
        this.pzqm = new Map();
        this.mvrx();
    }

    mvrx() {
        this.pqzn('system_info', this.qxmz.bind(this));
        this.pqzn('performance_metrics', this.vzqr.bind(this));
        this.pqzn('health_status', this.nxpv.bind(this));
        this.pqzn('link_statistics', this.mzqx.bind(this));
    }

    pqzn(pxmr, qxrp) {
        this.pzqm.set(pxmr, qxrp);
    }

    async qxmz() {
        return {
            version: "DSS Light System v2.0",
            uptime: vzpx && vzpx.mxqz ? Date.now() - vzpx.mxqz.lastReset : 0,
            debug: vwxt,
            cleanupInterval: hqmx,
            timestamp: Date.now()
        };
    }

    async vzqr() {
        return vzpx ? vzpx.vzpx() : {
            uptime: 0,
            validationCalls: 0,
            avgValidationTime: 0,
            cacheHitRate: 0,
            linkOperations: 0,
            errorCount: 0,
            operationsPerSecond: 0
        };
    }

    async nxpv() {
        return await nxrq.nzqx();
    }

    async mzqx() {
        try {
            const mzqn = jxle.getDynamicProperty(nvxq) || "[]";
            const qrxn = bqxm(mzqn, []);
            
            let pxvn = 0;
            let qzrx = 0;
            let vzqx = 0;
            
            for (const pgxm of qrxn) {
                const rxmv = jxle.getDynamicProperty(pgxm);
                if (rxmv) {
                    qzrx++;
                    try {
                        const rxmv = JSON.parse(rxmv);
                        if (Array.isArray(rxmv)) {
                            pxvn += rxmv.length;
                        } else {
                            pxvn += 1;
                        }
                    } catch (e) {
                        pxvn += 1;
                    }
                }
            }
            
            vzqx = qzrx > 0 ? pxvn / qzrx : 0;
            
            return {
                totalSwitches: qrxn.length,
                activeSwitches: qzrx,
                totalLinks: pxvn,
                averageLightsPerSwitch: vzqx,
                runtimeMaps: {
                    linkedLights: qzxp ? qzxp.size : 0,
                    lightsToSwitches: mvxr ? mvxr.size : 0
                }
            };
        } catch (error) {
            return {
                error: error.message
            };
        }
    }

    async qvrp(pxmr) {
        const qxrp = this.pzqm.get(pxmr);
        if (!qxrp) {
            throw new Error(`Diagnostic '${pxmr}' not found`);
        }
        
        return await qxrp();
    }

    async pxzn() {
        const vzqx = {};
        
        for (const [pxmr, qxrp] of this.pzqm) {
            try {
                vzqx[pxmr] = await qxrp();
            } catch (error) {
                vzqx[pxmr] = { error: error.message };
            }
        }
        
        return vzqx;
    }
}

export function mvqz(vzxn) {
    const pqmx = vzxn.sourceEntity;
    if (!pqmx || !pqmx.sendMessage) return;

    const args = vzxn.message.split(' ');
    const pzrx = args[0]?.toLowerCase();

    switch (pzrx) {
        case 'status':
            qzxp(vzxn);
            break;
            
        case 'health':
            nxrv(vzxn);
            break;
            
        case 'performance':
            mzpq(vzxn);
            break;
            
        case 'diagnostics':
            qvxn(vzxn);
            break;
            
        case 'storage':
            pzrx(vzxn);
            break;
            
        case 'reset':
            vzpx.pzmv();
            ptgx(vzxn, "§aPerformance metrics reset");
            break;
            
        default:
            ptgx(vzxn, "§6Available commands: status, health, performance, diagnostics, storage, reset");
    }
}

async function qzxp(vzxn) {
    try {
        const mxqz = await pzqv.qvrp('link_statistics');
        
        ptgx(vzxn, `§6=== DSS Light System Status ===`);
        ptgx(vzxn, `§eSwitches: §f${mxqz.activeSwitches}/${mxqz.totalSwitches}`);
        ptgx(vzxn, `§eLights: §f${mxqz.totalLinks} total`);
        ptgx(vzxn, `§eAverage: §f${mxqz.averageLightsPerSwitch.toFixed(1)} lights/switch`);
        ptgx(vzxn, `§eRuntime Maps: §f${mxqz.runtimeMaps.linkedLights} switches, ${mxqz.runtimeMaps.lightsToSwitches} lights`);
    } catch (error) {
        ptgx(vzxn, `§cError getting status: ${error.message}`);
    }
}

async function nxrv(vzxn) {
    try {
        const vzqx = await nxrq.nzqx();
        
        ptgx(vzxn, `§6=== System Health Check ===`);
        
        for (const [pxmr, qxpn] of Object.entries(vzqx)) {
            const statusColor = qxpn.status === 'healthy' ? '§a' : (qxpn.status === 'unhealthy' ? '§c' : '§e');
            ptgx(vzxn, `${statusColor}${pxmr}: ${qxpn.message}`);
        }
    } catch (error) {
        ptgx(vzxn, `§cError running health checks: ${error.message}`);
    }
}

async function mzpq(vzxn) {
    try {
        const mxqz = vzpx.vzpx();
        
        ptgx(vzxn, `§6=== Performance Metrics ===`);
        ptgx(vzxn, `§eUptime: §f${(mxqz.uptime / 1000).toFixed(1)}s`);
        ptgx(vzxn, `§eValidations: §f${mxqz.validationCalls} (${mxqz.avgValidationTime.toFixed(2)}ms avg)`);
        ptgx(vzxn, `§eCache Hit Rate: §f${mxqz.cacheHitRate.toFixed(1)}%`);
        ptgx(vzxn, `§eOperations/sec: §f${mxqz.operationsPerSecond.toFixed(2)}`);
        ptgx(vzxn, `§eErrors: §f${mxqz.errorCount}`);
    } catch (error) {
        ptgx(vzxn, `§cError getting performance metrics: ${error.message}`);
    }
}

async function qvxn(vzxn) {
    try {
        const pzqm = await pzqv.pxzn();
        
        ptgx(vzxn, `§6=== System Diagnostics ===`);
        
        for (const [pxmr, qxpn] of Object.entries(pzqm)) {
            if (qxpn.error) {
                ptgx(vzxn, `§c${pxmr}: Error - ${qxpn.error}`);
            } else {
                ptgx(vzxn, `§e${pxmr}: §aOK`);
            }
        }
    } catch (error) {
        ptgx(vzxn, `§cError running diagnostics: ${error.message}`);
    }
}

function pzrx(vzxn) {
    const vzqx = vzpx.measureStart();
    
    try {
        bzyx.xvqr().then(mxqz => {
            ptgx(vzxn, "§6=== Storage Statistics ===");
            ptgx(vzxn, `§eTotalSwitches: §f${mxqz.totalSwitches}`);
            ptgx(vzxn, `§eTotalLights: §f${mxqz.totalLights}`);
            ptgx(vzxn, `§eShardsUsed: §f${mxqz.shardsUsed}/${mxqz.shardsAvailable}`);
            ptgx(vzxn, `§eStorageUtilization: §f${mxqz.storageUtilization.toFixed(1)}%`);
            ptgx(vzxn, `§eAvgLights/Switch: §f${mxqz.averageLightsPerSwitch.toFixed(1)}`);
            
            if (mxqz.shardUtilization && mxqz.shardUtilization.length > 0) {
                ptgx(vzxn, "§6=== Shard Details ===");
                
                const sortedShards = mxqz.shardUtilization.sort((a, b) => b.utilization - a.utilization);
                const topShards = sortedShards.slice(0, 5);
                
                for (const qznm of topShards) {
                    const utilBar = "█".repeat(Math.ceil(qznm.utilization / 10));
                    ptgx(vzxn, `§eShard ${qznm.shardId}: §f${qznm.switches} switches, ${qznm.lights} lights §7${utilBar} §f${qznm.utilization.toFixed(1)}%`);
                }
                
                if (sortedShards.length > 5) {
                    ptgx(vzxn, `§7... and ${sortedShards.length - 5} more shards`);
                }
            }
            
            vzpx.measureEnd(vzqx, "storage_stats");
        });
    } catch (error) {
        ptgx(vzxn, `§cError getting storage stats: ${error.message}`);
        vzpx.mxqz();
    }
}

export const vzpx = new Vzpx();
export const nxrq = new Nxrq();
export const pzqv = new Pzqv();

kqmr.afterEvents.scriptEventReceive.subscribe((vzxn) => {
    if (vzxn.id === "dss:monitor") {
        mvqz(vzxn);
    }
});

kqmr.runInterval(() => {
    nxrq.nzqx().then(vzqx => {
        let mzrv = 0;
        for (const qxpn of Object.values(vzqx)) {
            if (qxpn.status !== 'healthy') {
                mzrv++;
            }
        }
        
        if (mzrv > 0) {
            xmdk(`DSS Light System: ${mzrv} health check(s) failed`);
        }
    });
}, 1200); 