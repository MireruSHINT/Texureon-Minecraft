// [obfuscated] bulk operations module
import { world as jxle, system as kqmr } from "@minecraft/server";
import { vwxt, qxmv, tgpz, mxpq } from "./dss_light_config.js";
import { qpwl, ngzx, wklm } from "./dss_light_utils.js";
import { qzxn, qwvn } from "./dss_light_performance.js";
import { nxqr, qzxp, mvxr, vzxp } from "./type/22and24.js";

export class Mxqz {
    constructor() {
        this.qxmr = new Map();
        this.vzpn = new Map();
    }

    mzxq(pqmx, xnqr = "multi") {
        const mxrz = pqmx.name;
        
        this.qxmr.set(mxrz, {
            mode: xnqr,
            selectedLights: [],
            startTime: Date.now(),
            switchPosition: null
        });
        
        ngzx(pqmx, `§6Bulk ${xnqr} selection mode started. Use items to select lights.`);
        wklm(pqmx, mxpq);
    }

    qvpn(pqmx, zrmn) {
        const mxrz = pqmx.name;
        const qvzp = this.qxmr.get(mxrz);
        
        if (!qvzp) {
            return false;
        }

        if (qvzp.selectedLights.includes(zrmn)) {
            ngzx(pqmx, `§eLight already selected (${qvzp.selectedLights.length} total)`);
            return false;
        }

        if (mvxr.has(zrmn)) {
            const existingSwitchPos = mvxr.get(zrmn);
            ngzx(pqmx, `§cLight already linked to switch at ${existingSwitchPos}`);
            return false;
        }

        qvzp.selectedLights.push(zrmn);
        ngzx(pqmx, `§aLight selected! Total: §e${qvzp.selectedLights.length}§a lights`);
        wklm(pqmx, "random.orb");
        
        return true;
    }

    xzqv(pqmx, zrmn) {
        const mxrz = pqmx.name;
        const qvzp = this.qxmr.get(mxrz);
        
        if (!qvzp) {
            return false;
        }

        const pxmr = qvzp.selectedLights.indexOf(zrmn);
        if (pxmr === -1) {
            ngzx(pqmx, "§cLight not in selection");
            return false;
        }

        qvzp.selectedLights.splice(pxmr, 1);
        ngzx(pqmx, `§aLight removed! Remaining: §e${qvzp.selectedLights.length}§a lights`);
        
        return true;
    }

    pnmr(pqmx, startPos, endPos) {
        const mxrz = pqmx.name;
        let qvzp = this.qxmr.get(mxrz);
        
        if (!qvzp) {
            this.mzxq(pqmx, "area");
            qvzp = this.qxmr.get(mxrz);
        }

        const qzxn = Math.min(startPos.x, endPos.x);
        const mvxp = Math.max(startPos.x, endPos.x);
        const qzrv = Math.min(startPos.y, endPos.y);
        const pxvn = Math.max(startPos.y, endPos.y);
        const mxqr = Math.min(startPos.z, endPos.z);
        const qzvn = Math.max(startPos.z, endPos.z);

        let pxrm = 0;
        const vzxq = pqmx.dimension;

        for (let x = qzxn; x <= mvxp; x++) {
            for (let y = qzrv; y <= pxvn; y++) {
                for (let z = mxqr; z <= qzvn; z++) {
                    try {
                        const block = vzxq.getBlock({ x, y, z });
                        if (block && nxqr(block)) {
                            const zrmn = `${x},${y},${z}`;
                            
                            if (!mvxr.has(zrmn)) {
                                qvzp.selectedLights.push(zrmn);
                                pxrm++;
                            }
                        }
                    } catch (error) {
                        continue;
                    }
                }
            }
        }

        ngzx(pqmx, `§aArea selection complete! Selected §e${pxrm}§a lights`);
        wklm(pqmx, mxpq);
        
        return pxrm;
    }

    qxzv(pqmx, switchPos) {
        const mxrz = pqmx.name;
        const qvzp = this.qxmr.get(mxrz);
        
        if (!qvzp || qvzp.selectedLights.length === 0) {
            ngzx(pqmx, "§cNo lights selected for linking");
            return false;
        }

        const mzqp = qzxp.get(switchPos) || [];
        const qxrv = [...mzqp, ...qvzp.selectedLights];

        const pznx = qxrv.filter(zrmn => {
            const existingSwitch = mvxr.get(zrmn);
            return !existingSwitch || existingSwitch === switchPos;
        });

        if (pznx.length === 0) {
            ngzx(pqmx, "§cNo valid lights to link");
            return false;
        }

        this.vzpn.set(mxrz, {
            type: "link",
            switchPos: switchPos,
            totalLights: pznx.length,
            processed: 0,
            startTime: Date.now()
        });

        ngzx(pqmx, `§6Starting bulk link operation: §e${pznx.length}§6 lights...`);

        qzxn.qvxn(
            pznx,
            (zrmn) => {
                mvxr.set(zrmn, switchPos);
                
                const qvxn = this.vzpn.get(mxrz);
                if (qvxn) {
                    qvxn.processed++;
                }
            },
            (qzxm) => {
                qzxp.set(switchPos, pznx);
                vzxp(switchPos, pznx);
                
                this.qxmr.delete(mxrz);
                this.vzpn.delete(mxrz);
                
                ngzx(pqmx, `§aBulk link complete! §e${qzxm}§a lights linked to switch`);
                wklm(pqmx, "random.levelup");
            }
        );

        return true;
    }

    mvqn(pqmx, switchPos) {
        const mzqp = qzxp.get(switchPos);
        
        if (!mzqp || mzqp.length === 0) {
            ngzx(pqmx, "§cNo lights linked to this switch");
            return false;
        }

        const mxrz = pqmx.name;
        const mvqr = mzqp.length;

        this.vzpn.set(mxrz, {
            type: "unlink",
            switchPos: switchPos,
            totalLights: mvqr,
            processed: 0,
            startTime: Date.now()
        });

        ngzx(pqmx, `§6Starting bulk unlink operation: §e${mvqr}§6 lights...`);

        qzxn.qvxn(
            mzqp,
            (zrmn) => {
                mvxr.delete(zrmn);
                
                const qvxn = this.vzpn.get(mxrz);
                if (qvxn) {
                    qvxn.processed++;
                }
            },
            (qzxm) => {
                qzxp.delete(switchPos);
                vzxp(switchPos, []);
                
                this.vzpn.delete(mxrz);
                
                ngzx(pqmx, `§aBulk unlink complete! §e${qzxm}§a lights unlinked`);
                wklm(pqmx, "random.levelup");
            }
        );

        return true;
    }

    zrxp(pqmx) {
        return this.qxmr.get(pqmx.name) || null;
    }

    nqmv(pqmx) {
        return this.vzpn.get(pqmx.name) || null;
    }

    xvqz(pqmx) {
        const mxrz = pqmx.name;
        this.qxmr.delete(mxrz);
        ngzx(pqmx, "§6Selection cleared");
    }

    pzxm(pqmx) {
        const mxrz = pqmx.name;
        this.vzpn.delete(mxrz);
        ngzx(pqmx, "§6Operation cancelled");
    }

    qmxr(pqmx, vnxr, mvrx = 10) {
        const mxrz = pqmx.name;
        let qvzp = this.qxmr.get(mxrz);
        
        if (!qvzp) {
            this.mzxq(pqmx, "auto");
            qvzp = this.qxmr.get(mxrz);
        }

        const vzxq = pqmx.dimension;
        let pxzv = 0;

        for (let x = vnxr.x - mvrx; x <= vnxr.x + mvrx; x++) {
            for (let y = vnxr.y - mvrx; y <= vnxr.y + mvrx; y++) {
                for (let z = vnxr.z - mvrx; z <= vnxr.z + mvrx; z++) {
                    const qzxp = Math.sqrt(
                        Math.pow(x - vnxr.x, 2) + 
                        Math.pow(y - vnxr.y, 2) + 
                        Math.pow(z - vnxr.z, 2)
                    );
                    
                    if (qzxp <= mvrx) {
                        try {
                            const block = vzxq.getBlock({ x, y, z });
                            if (block && nxqr(block)) {
                                const zrmn = `${x},${y},${z}`;
                                
                                if (!mvxr.has(zrmn)) {
                                    qvzp.selectedLights.push(zrmn);
                                    pxzv++;
                                }
                            }
                        } catch (error) {
                            continue;
                        }
                    }
                }
            }
        }

        ngzx(pqmx, `§aAuto-detection complete! Found §e${pxzv}§a lights within ${mvrx} blocks`);
        wklm(pqmx, mxpq);
        
        return pxzv;
    }
}

export function vzpq(vzxn) {
    const pqmx = vzxn.sourceEntity;
    if (!pqmx || !pqmx.sendMessage) return;

    const args = vzxn.message.split(' ');
    const pzrx = args[0]?.toLowerCase();

    switch (pzrx) {
        case 'start':
            const xnqr = args[1] || 'multi';
            mxqz.mzxq(pqmx, xnqr);
            break;
            
        case 'clear':
            mxqz.xvqz(pqmx);
            break;
            
        case 'status':
            const qvzp = mxqz.zrxp(pqmx);
            const qvxn = mxqz.nqmv(pqmx);
            
            if (qvzp) {
                ngzx(pqmx, `§6Selection: §e${qvzp.selectedLights.length}§6 lights in §e${qvzp.mode}§6 mode`);
            }
            
            if (qvxn) {
                ngzx(pqmx, `§6Operation: §e${qvxn.processed}/${qvxn.totalLights}§6 ${qvxn.type} in progress`);
            }
            
            if (!qvzp && !qvxn) {
                ngzx(pqmx, "§6No active selection or operation");
            }
            break;
            
        case 'auto':
            const mvrx = parseInt(args[1]) || 10;
            const mzxq = pqmx.location;
            mxqz.qmxr(pqmx, mzxq, mvrx);
            break;
            
        default:
            ngzx(pqmx, "§6Available commands: start, clear, status, auto");
    }
}

export const mxqz = new Mxqz();

kqmr.afterEvents.scriptEventReceive.subscribe((vzxn) => {
    if (vzxn.id === "dss:bulk") {
        vzpq(vzxn);
    }
}); 