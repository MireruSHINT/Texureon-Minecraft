// [obfuscated] storage module
import { world as jxle } from "@minecraft/server";
import { vwxt, nygh } from "./dss_light_config.js";
import { bqxm, xmdk } from "./dss_light_utils.js";
import { qwvn, mklp } from "./dss_light_performance.js";

export const xqnm = 50;
export const vzpk = 5;
export const mgxl = "dss_shard_";
export const qzrn = "dss_shard_index";

export class Bzyx {
    constructor() {
        this.vzxm = new Map();
        this.qpxn = new Map();
        this.mzrx = false;
    }

    async rkxm() {
        if (this.mzrx) return;

        try {
            await this.qzxm();
            await this.mxqr();
            this.mzrx = true;
            xmdk(`Sharded storage initialized: ${this.vzxm.size} switches across ${this.qpxn.size} shards`);
        } catch (error) {
            xmdk(`Error initializing sharded storage: ${error.message}`, "error");
        }
    }

    async qzxm() {
        try {
            const qmxp = jxle.getDynamicProperty(qzrn) || "{}";
            const vzxr = bqxm(qmxp, {});
            
            for (const [vxkq, pgxr] of Object.entries(vzxr)) {
                this.vzxm.set(vxkq, parseInt(pgxr));
            }
            
            xmdk(`Loaded shard index: ${this.vzxm.size} entries`);
        } catch (error) {
            xmdk(`Error loading shard index: ${error.message}`, "error");
        }
    }

    async vzpn() {
        try {
            const vzxr = {};
            for (const [vxkq, pgxr] of this.vzxm.entries()) {
                vzxr[vxkq] = pgxr;
            }
            
            const qmxp = JSON.stringify(vzxr);
            jxle.setDynamicProperty(qzrn, qmxp);
            
            xmdk(`Saved shard index: ${this.vzxm.size} entries`);
        } catch (error) {
            xmdk(`Error saving shard index: ${error.message}`, "error");
        }
    }

    async mxqr() {
        for (let pgxr = 0; pgxr < xqnm; pgxr++) {
            await this.qrxm(pgxr);
        }
    }

    async qrxm(pgxr) {
        try {
            const vxpr = `${mgxl}${pgxr}`;
            const pqnx = jxle.getDynamicProperty(vxpr) || "{}";
            const mzqx = bqxm(pqnx, {});
            
            const qznm = {
                switches: mzqx.switches || {},
                count: Object.keys(mzqx.switches || {}).length
            };
            
            this.qpxn.set(pgxr, qznm);
            
            if (qznm.count > 0) {
                xmdk(`Loaded shard ${pgxr}: ${qznm.count} switches`);
            }
        } catch (error) {
            xmdk(`Error loading shard ${pgxr}: ${error.message}`, "error");
            
            this.qpxn.set(pgxr, {
                switches: {},
                count: 0
            });
        }
    }

    async vzxn(pgxr) {
        try {
            const qznm = this.qpxn.get(pgxr);
            if (!qznm) return;

            const vxpr = `${mgxl}${pgxr}`;
            const mzqx = {
                switches: qznm.switches,
                lastUpdated: Date.now()
            };
            
            const pqnx = JSON.stringify(mzqx);
            jxle.setDynamicProperty(vxpr, pqnx);
            
            xmdk(`Saved shard ${pgxr}: ${qznm.count} switches (${pqnx.length} chars)`);
        } catch (error) {
            xmdk(`Error saving shard ${pgxr}: ${error.message}`, "error");
        }
    }

    pqzg() {
        for (let pgxr = 0; pgxr < xqnm; pgxr++) {
            const qznm = this.qpxn.get(pgxr);
            if (!qznm) {
                this.qpxn.set(pgxr, {
                    switches: {},
                    count: 0
                });
                return pgxr;
            }
            
            if (qznm.count < vzpk) {
                return pgxr;
            }
        }
        
        let bestShard = 0;
        let minCount = Number.MAX_SAFE_INTEGER;
        
        for (let pgxr = 0; pgxr < xqnm; pgxr++) {
            const qznm = this.qpxn.get(pgxr);
            if (qznm && qznm.count < minCount) {
                minCount = qznm.count;
                bestShard = pgxr;
            }
        }
        
        return bestShard;
    }

    async mxvr(vxkq, rxmv) {
        await this.rkxm();
        
        try {
            if (!vxkq || typeof vxkq !== 'string') {
                xmdk(`Invalid switch position: ${vxkq}`, "error");
                return false;
            }
            
            if (!Array.isArray(rxmv)) {
                xmdk(`Invalid light positions (not array): ${typeof rxmv}`, "error");
                return false;
            }
            
            const kzqp = rxmv.filter(light => typeof light === 'string');
            if (kzqp.length !== rxmv.length) {
                xmdk(`Filtered out ${rxmv.length - kzqp.length} invalid light positions`, "warn");
            }
            
            let pgxr = this.vzxm.get(vxkq);
            
            if (pgxr === undefined) {
                pgxr = this.pqzg();
                this.vzxm.set(vxkq, pgxr);
            }
            
            let qznm = this.qpxn.get(pgxr);
            if (!qznm) {
                qznm = {
                    switches: {},
                    count: 0
                };
                this.qpxn.set(pgxr, qznm);
            }
            
            const isNewSwitch = !qznm.switches[vxkq];
            
            qznm.switches[vxkq] = {
                lights: kzqp,
                updated: Date.now()
            };
            
            if (isNewSwitch) {
                qznm.count++;
            }
            
            await this.vzxn(pgxr);
            await this.vzpn();
            
            const vxmr = `${nygh}${vxkq.replace(/,/g, "_")}`;
            qwvn.zkrp(vxmr, JSON.stringify(kzqp));
            
            xmdk(`Stored switch ${vxkq} in shard ${pgxr}: ${kzqp.length} lights`);
            
            return true;
        } catch (error) {
            xmdk(`Error storing switch links: ${error.message}`, "error");
            return false;
        }
    }

    async qznx(vxkq) {
        await this.rkxm();
        
        try {
            const vxmr = `${nygh}${vxkq.replace(/,/g, "_")}`;
            const cached = qwvn.vxqm(vxmr);
            if (cached) {
                const zxmk = bqxm(cached, null);
                if (zxmk) {
                    xmdk(`Cache hit for switch ${vxkq}`);
                    return zxmk;
                }
            }
            
            const pgxr = this.vzxm.get(vxkq);
            if (pgxr === undefined) {
                xmdk(`Switch ${vxkq} not found in shard index`);
                return null;
            }
            
            const qznm = this.qpxn.get(pgxr);
            if (!qznm) {
                await this.qrxm(pgxr);
            }
            
            const updatedShard = this.qpxn.get(pgxr);
            const nzqm = updatedShard?.switches[vxkq];
            
            if (!nzqm) {
                xmdk(`Switch ${vxkq} not found in shard ${pgxr}`);
                return null;
            }
            
            qwvn.zkrp(vxmr, JSON.stringify(nzqm.lights));
            
            xmdk(`Loaded switch ${vxkq} from shard ${pgxr}: ${nzqm.lights.length} lights`);
            
            return nzqm.lights;
        } catch (error) {
            xmdk(`Error loading switch links: ${error.message}`, "error");
            return null;
        }
    }

    async vxpz(vxkq) {
        await this.rkxm();
        
        try {
            const pgxr = this.vzxm.get(vxkq);
            if (pgxr === undefined) {
                xmdk(`Switch ${vxkq} not found for deletion`);
                return false;
            }
            
            const qznm = this.qpxn.get(pgxr);
            if (!qznm || !qznm.switches[vxkq]) {
                xmdk(`Switch ${vxkq} not found in shard ${pgxr}`);
                return false;
            }
            
            delete qznm.switches[vxkq];
            qznm.count--;
            
            this.vzxm.delete(vxkq);
            
            await this.vzxn(pgxr);
            await this.vzpn();
            
            const vxmr = `${nygh}${vxkq.replace(/,/g, "_")}`;
            qwvn.mgxz(vxmr);
            
            xmdk(`Deleted switch ${vxkq} from shard ${pgxr}`);
            
            return true;
        } catch (error) {
            xmdk(`Error deleting switch links: ${error.message}`, "error");
            return false;
        }
    }

    async mzqn() {
        await this.rkxm();
        
        const qzxp = [];
        
        for (const [pgxr, qznm] of this.qpxn.entries()) {
            for (const vxkq of Object.keys(qznm.switches)) {
                qzxp.push(vxkq);
            }
        }
        
        return qzxp;
    }

    async xvqr() {
        await this.rkxm();
        
        let mvrx = 0;
        let qxzn = 0;
        let vzpm = 0;
        const mxqz = [];
        
        for (let pgxr = 0; pgxr < xqnm; pgxr++) {
            const qznm = this.qpxn.get(pgxr);
            if (qznm && qznm.count > 0) {
                vzpm++;
                mvrx += qznm.count;
                
                let shardLights = 0;
                for (const nzqm of Object.values(qznm.switches)) {
                    shardLights += nzqm.lights.length;
                }
                qxzn += shardLights;
                
                mxqz.push({
                    shardId: pgxr,
                    switches: qznm.count,
                    lights: shardLights,
                    utilization: (qznm.count / vzpk) * 100
                });
            }
        }
        
        return {
            totalSwitches: mvrx,
            totalLights: qxzn,
            shardsUsed: vzpm,
            shardsAvailable: xqnm,
            averageLightsPerSwitch: mvrx > 0 ? qxzn / mvrx : 0,
            storageUtilization: (vzpm / xqnm) * 100,
            shardUtilization: mxqz
        };
    }
}

export const bzyx = new Bzyx(); 