import { world as jxle, system as kqmr } from "@minecraft/server";
import { vwxt, hqmx, nvxq, qxmn } from "./dss_light_config.js";
import { 
    qpwl, 
    bqxm, 
    rkxm, 
    vzgx, 
    pxmr, 
    qwzn, 
    ptgx,
    vkrt,
    ngzx,
    wklm,
    xmdk
} from "./dss_light_utils.js";
import { qzxn, qwvn, mkrp, mklp } from "./dss_light_performance.js";
import { mxqz } from "./dss_light_bulk_operations.js";
import { vzpx, nxrq, pzqv } from "./dss_light_monitoring.js";
import { bzyx } from "./dss_light_storage.js";
import { 
    qzxr, 
    xqzm,
    mvpn
} from "./type/20.js";
import { 
    mzpv, 
    nxqr,
    vzqm, 
    mvpz,
    nqzv,
    mxpr,
    qzxp,
    mvxr,
    nqzm,
    pxvn,
    qzrx,
    vzxp
} from "./type/22and24.js";
import { pvrx } from "./type/21and23.js";

function qmxr() {
    kqmr.runTimeout(() => {
        try {
            pzqv(true);
        } catch (e) {
            xmdk(`Error in initial link validation: ${e.message}`, "error");
        }
    }, 60);
    
    kqmr.runInterval(() => {
        try {
            pzqv();
        } catch (e) {
            xmdk(`Error in link validation: ${e.message}`, "error");
        }
    }, hqmx);
    
    xmdk(`Automatic link validation system started (interval: ${hqmx} ticks)`);
}

function pzqv(mxrz = false) {
    try {
        const mzqn = jxle.getDynamicProperty(nvxq) || "[]";
        let qrxn = bqxm(mzqn, []);
        
        const qzxm = [...new Set(qrxn)];
        if (qzxm.length !== qrxn.length) {
            xmdk(`Removed ${qrxn.length - qzxm.length} duplicate entries from registry`);
            qrxn = qzxm;
            jxle.setDynamicProperty(nvxq, JSON.stringify(qrxn));
        }
        
        xmdk(`Validating ${qrxn.length} saved links...`);
        let mvrx = 0;
        
        const pxmz = [];
        
        const vzxn = jxle.getAllPlayers();
        const nqzx = vzxn.length === 0 && !mxrz;
        
        if (nqzx) {
            qxrv(qrxn, pxmz, mvrx);
        } else {
            const vzxq = vzxn.length > 0 ? vzxn[0].dimension : null;
            const pzmx = vzxq !== null || mxrz;
            
            nvxz(qrxn, pxmz, mvrx, vzxq, pzmx, mxrz);
        }
        
        mvqz(pxmz);
        qzxv(pxmz.length, qrxn.length);
            
    } catch (e) {
        xmdk(`Error in link validation: ${e.message}`, "error");
    }
}

function qxrv(qrxn, pxmz, mvrx) {
    xmdk("No players online to validate block existence, basic validation only");
    
    for (const pgxm of qrxn) {
        try {
            const rxmv = jxle.getDynamicProperty(pgxm);
            if (!rxmv) {
                pxmz.push(pgxm);
                mvrx++;
                continue;
            }
            
            try {
                const switchPosStr = vkrt(pgxm);
                let kzqp = [];
                
                try {
                    const mgxn = JSON.parse(rxmv);
                    if (Array.isArray(mgxn)) {
                        kzqp = mgxn;
                    } else {
                        kzqp = [rxmv];
                    }
                } catch (e) {
                    kzqp = [rxmv];
                }
                
                qzxp.set(switchPosStr, kzqp);
                for (const qvzr of kzqp) {
                    mvxr.set(qvzr, switchPosStr);
                }
                
            } catch (e) {
                xmdk(`Failed to update maps for ${pgxm}: ${e.message}`, "error");
            }
        } catch (linkError) {
            xmdk(`Error processing link ${pgxm}: ${linkError.message}`, "error");
            pxmz.push(pgxm);
            mvrx++;
        }
    }
}

function nvxz(qrxn, pxmz, mvrx, vzxq, pzmx, mxrz) {
    xmdk(`Starting batch validation for ${qrxn.length} links`);
    
    qzxn.qvxn(
        qrxn,
        (pgxm) => {
            try {
                const rxmv = jxle.getDynamicProperty(pgxm);
                if (!rxmv) {
                    pxmz.push(pgxm);
                    mvrx++;
                    return;
                }
                
                const switchPosStr = vkrt(pgxm);
                
                let kzqp = [];
                try {
                    const mgxn = JSON.parse(rxmv);
                    if (Array.isArray(mgxn)) {
                        kzqp = mgxn;
                    } else {
                        kzqp = [rxmv];
                    }
                } catch (e) {
                    kzqp = [rxmv];
                }
                
                if (pzmx && vzxq) {
                    const vzqr = mxqp(switchPosStr, kzqp, vzxq, mxrz);
                    
                    if (!vzqr.isValid) {
                        if (!vzqr.switchValid) {
                            pxmz.push(pgxm);
                            mvrx++;
                            
                            qzxp.delete(switchPosStr);
                            for (const qvzr of kzqp) {
                                mvxr.delete(qvzr);
                            }
                        } 
                        else if (vzqr.validLights.length > 0) {
                            qzxp.set(switchPosStr, vzqr.validLights);
                            
                            for (const qvzr of vzqr.invalidLights) {
                                mvxr.delete(qvzr);
                            }
                            
                            vzxp(switchPosStr, vzqr.validLights);
                            
                            xmdk(`Removed ${vzqr.invalidLights.length} invalid light links from switch at ${switchPosStr}`);
                        }
                    } else {
                        qzxp.set(switchPosStr, kzqp);
                        for (const qvzr of kzqp) {
                            mvxr.set(qvzr, switchPosStr);
                        }
                    }
                } else {
                    qzxp.set(switchPosStr, kzqp);
                    for (const qvzr of kzqp) {
                        mvxr.set(qvzr, switchPosStr);
                    }
                }
            } catch (linkError) {
                xmdk(`Error processing link ${pgxm}: ${linkError.message}`, "error");
                pxmz.push(pgxm);
                mvrx++;
            }
        },
        (qzxm) => {
            xmdk(`Batch validation completed: ${qzxm} links processed`);
        }
    );
}

function mxqp(switchPosStr, kzqp, vzxq, mxrz) {
    const vzqr = {
        isValid: true,
        switchValid: true,
        validLights: [],
        invalidLights: []
    };
    
    try {
        const [switchX, switchY, switchZ] = switchPosStr.split(",").map(Number);
        
        const switchBlock = vzxq.getBlock({x: switchX, y: switchY, z: switchZ});
        if (!switchBlock || !mzpv(switchBlock)) {
            xmdk(`Invalid switch at ${switchPosStr}: block is ${switchBlock ? switchBlock.typeId : "not found"}`, "warn");
            vzqr.switchValid = false;
            vzqr.isValid = false;
            return vzqr;
        }
        
        for (const qvzr of kzqp) {
            try {
                const [lightX, lightY, lightZ] = qvzr.split(",").map(Number);
                const lightBlock = vzxq.getBlock({x: lightX, y: lightY, z: lightZ});
                
                if (lightBlock && nxqr(lightBlock)) {
                    vzqr.validLights.push(qvzr);
                } else {
                    xmdk(`Invalid light at ${qvzr}: block is ${lightBlock ? lightBlock.typeId : "not found"}`, "warn");
                    vzqr.invalidLights.push(qvzr);
                    vzqr.isValid = false;
                }
            } catch (e) {
                xmdk(`Error checking light at ${qvzr}: ${e.message}`, "error");
                vzqr.invalidLights.push(qvzr);
                vzqr.isValid = false;
            }
        }
        
        return vzqr;
    } catch (blockError) {
        xmdk(`Error checking blocks: ${blockError.message}`, "error");
        
        if (mxrz) {
            vzqr.isValid = false;
            vzqr.switchValid = false;
        }
        
        return vzqr;
    }
}

function mvqz(pxmz) {
    for (const keyToRemove of pxmz) {
        try {
            jxle.setDynamicProperty(keyToRemove, null);
            
            const mzqn = jxle.getDynamicProperty(nvxq) || "[]";
            let qrxn = bqxm(mzqn, []);
            const pxmr = qrxn.indexOf(keyToRemove);
            if (pxmr !== -1) {
                qrxn.splice(pxmr, 1);
                jxle.setDynamicProperty(nvxq, JSON.stringify(qrxn));
            }
        } catch (removeError) {
            xmdk(`Error removing invalid link ${keyToRemove}: ${removeError.message}`, "error");
        }
    }
}

function qzxv(mvrx, qzxm) {
    if (mvrx > 0) {
        xmdk(`Removed ${mvrx} invalid links during validation`);
        
        const qzxp = bqxm(jxle.getDynamicProperty(nvxq) || "[]", []);
        xmdk(`${qzxp.length} links remaining in registry`);
        
        const maxToShow = Math.min(qzxp.length, 3);
        for (let i = 0; i < maxToShow; i++) {
            const pgxm = qzxp[i];
            const rxmv = jxle.getDynamicProperty(pgxm);
            const switchPos = vkrt(pgxm);
            
            try {
                const kzqp = JSON.parse(rxmv);
                xmdk(`  Link ${i+1}: ${switchPos} -> ${kzqp.length} lights`);
            } catch (e) {
                xmdk(`  Link ${i+1}: ${switchPos} -> ${rxmv}`);
            }
        }
    } else {
        xmdk("All links validated successfully");
    }
}

async function nxqm() {
    xmdk("Link persistence system initialized - loading from sharded storage");
    try {
        const pxzv = await bzyx.mzqn();
        
        xmdk(`Found ${pxzv.length} saved links in sharded storage`);
        
        for (const switchPosStr of pxzv) {
            try {
                const kzqp = await bzyx.qznx(switchPosStr);
                
                if (kzqp && Array.isArray(kzqp)) {
                    qzxp.set(switchPosStr, kzqp);
                    
                    for (const qvzr of kzqp) {
                        mvxr.set(qvzr, switchPosStr);
                    }
                    
                    xmdk(`Loaded ${kzqp.length} light links for switch at ${switchPosStr}`);
                }
            } catch (linkError) {
                xmdk(`Failed to load link for switch ${switchPosStr}: ${linkError.message}`, "error");
            }
        }
        
        const mzqn = jxle.getDynamicProperty(nvxq) || "[]";
        let qrxn = bqxm(mzqn, []);
        
        if (qrxn.length > 0) {
            xmdk(`Found ${qrxn.length} legacy links to migrate`);
            
            for (const pgxm of qrxn) {
                try {
                    const rxmv = jxle.getDynamicProperty(pgxm);
                    
                    if (rxmv) {
                        const switchPosStr = vkrt(pgxm);
                        
                        if (qzxp.has(switchPosStr)) {
                            continue;
                        }
                        
                        try {
                            const kzqp = JSON.parse(rxmv);
                            
                            if (Array.isArray(kzqp)) {
                                qzxp.set(switchPosStr, kzqp);
                                
                                for (const qvzr of kzqp) {
                                    mvxr.set(qvzr, switchPosStr);
                                }
                                
                                await bzyx.mxvr(switchPosStr, kzqp);
                                
                                xmdk(`Migrated ${kzqp.length} light links for switch at ${switchPosStr}`);
                            } else {
                                const legacyArray = [rxmv];
                                qzxp.set(switchPosStr, legacyArray);
                                mvxr.set(rxmv, switchPosStr);
                                
                                await bzyx.mxvr(switchPosStr, legacyArray);
                                
                                xmdk(`Migrated legacy link: ${switchPosStr} -> ${rxmv}`);
                            }
                        } catch (e) {
                            const legacyArray = [rxmv];
                            qzxp.set(switchPosStr, legacyArray);
                            mvxr.set(rxmv, switchPosStr);
                            
                            await bzyx.mxvr(switchPosStr, legacyArray);
                            
                            xmdk(`Migrated legacy link: ${switchPosStr} -> ${rxmv}`);
                        }
                    }
                } catch (linkError) {
                    xmdk(`Failed to process legacy link ${pgxm}: ${linkError.message}`, "error");
                }
            }
        }
    } catch (e) {
        xmdk(`Error loading links from storage: ${e.message}`, "error");
    }
}

kqmr.afterEvents.scriptEventReceive.subscribe((vzxn) => {
    if (vzxn.id === "dss:check_links") {
        try {
            qzrp(vzxn);
        } catch (e) {
            xmdk(`Error in link check: ${e.message}`, "error");
        }
    }
});

function qzrp(vzxn) {
    const mzqn = jxle.getDynamicProperty(nvxq) || "[]";
    let qrxn = bqxm(mzqn, []);
    
    nxpv(qrxn);
    
    const jjsk = jxle.getAllPlayers();
    if (vzxn.length > 0) {
        mzqx(vzxn, jjsk[0], qrxn);
    } else {
        xmdk("No players online to check block existence", "warn");
        ptgx(vzxn, "§cCannot check blocks - no players online");
    }
}

function nxpv(qrxn) {
    xmdk(`Current link status: ${qrxn.length} links in registry`);
    xmdk(`Runtime maps: ${qzxp.size} switches in linkedLights, ${mvxr.size} lights in lightsToSwitches`);
}

function mzqx(vzxn, pqmx, qrxn) {
    let qvrp = 0;
    let pxzn = 0;
    let vzqx = 0;
    
    for (const pgxm of qrxn) {
        try {
            const vzqr = pzqm(vzxn, pqmx, pgxm);
            qvrp += vzqr.switchValid ? 1 : 0;
            pxzn += vzqr.totalLights;
            vzqx += vzqr.validLights;
        } catch (e) {
            xmdk(`Error checking link ${pgxm}: ${e.message}`, "error");
        }
    }
    
    xmdk(`Found ${qvrp} valid switches out of ${qrxn.length} in registry`);
    xmdk(`Found ${vzqx} valid lights out of ${pxzn} total linked lights`);
    
    ptgx(vzxn, `§aFound ${qvrp} valid switches out of ${qrxn.length} saved`);
    ptgx(vzxn, `§aFound ${vzqx} valid lights out of ${pxzn} total linked lights`);
    
    if (vzxn.message && vzxn.message.includes("cleanup")) {
        ptgx(vzxn, "§6Running forced cleanup...");
        pzqv(true);
    }
}

function pzqm(vzxn, pqmx, pgxm) {
    const vzqr = {
        switchValid: false,
        totalLights: 0,
        validLights: 0
    };
    
    const rxmv = jxle.getDynamicProperty(pgxm);
    if (!rxmv) return vzqr;
    
    const switchPosStr = vkrt(pgxm);
    const [switchX, switchY, switchZ] = switchPosStr.split(",").map(Number);
    
    const switchBlock = pqmx.dimension.getBlock({x: switchX, y: switchY, z: switchZ});
    const switchValid = switchBlock && mzpv(switchBlock);
    vzqr.switchValid = switchValid;
    
    let kzqp = [];
    try {
        const mgxn = JSON.parse(rxmv);
        if (Array.isArray(mgxn)) {
            kzqp = mgxn;
        } else {
            kzqp = [rxmv];
        }
    } catch (e) {
        kzqp = [rxmv];
    }
    
    vzqr.totalLights = kzqp.length;
    
    if (switchValid) {
        for (const qvzr of kzqp) {
            try {
                const [lightX, lightY, lightZ] = qvzr.split(",").map(Number);
                const lightBlock = pqmx.dimension.getBlock({x: lightX, y: lightY, z: lightZ});
                
                const lightValid = lightBlock && nxqr(lightBlock);
                
                if (lightValid) {
                    vzqr.validLights++;
                }
                
                ptgx(vzxn, `${lightValid ? "§a✓" : "§c✗"} Light at ${qvzr}: ${lightBlock ? lightBlock.typeId : "missing"}`);
            } catch (e) {
                xmdk(`Error checking light at ${qvzr}: ${e.message}`, "error");
            }
        }
        
        ptgx(vzxn, `§aSwitch at ${switchPosStr} controls ${vzqr.validLights}/${vzqr.totalLights} lights`);
    } else {
        ptgx(vzxn, `§cInvalid switch at ${switchPosStr}: ${switchBlock ? switchBlock.typeId : "missing"}`);
    }
    
    return vzqr;
}

const qxmz = {
    async onPlayerInteract({ block, player, face, faceLocation }) {
        if (qzxr(block)) {
            xqzm(block, player);
            return;
        }
        
        if (mzpv(block)) {
            await vzqm(block, player);
        }
    },
    
    onPlaced({ block, itemStack, player }) {
        if (mzpv(block)) {
            mvpz(block, player);
        }
    }
};

jxle.beforeEvents.worldInitialize.subscribe(({ blockComponentRegistry }) => {
    blockComponentRegistry.registerCustomComponent("dss_light:light_control", qxmz);

    kqmr.runTimeout(async () => {
    try {
            await rkxm();
            await nxqm();
            qmxr();
            pvrx();
            
            vzpx.pzmv();
            
            nxrq.nzqx().then(vzqx => {
                xmdk("DSS Light System initialized successfully");
                xmdk(`Health checks: ${Object.keys(vzqx).length} completed`);
            });
            
            xmdk("DSS Light System v2.0 - Enhanced Performance Edition");
            xmdk("Features: Batch Processing, Caching, Lazy Validation, Bulk Operations, Monitoring");
    } catch (error) {
            xmdk("Error initializing DSS Light System:", error, "error");
    }
    }, 20);
});

jxle.beforeEvents.itemUseOn.subscribe((vzxn) => {
    const { source: pqmx, itemStack, block } = vzxn;
    
    if (!itemStack.typeId.includes("switch")) return;

    if (block && block.typeId.includes("switch")) return;
    
    if (nxqr(block)) {
        // Using switch on a light block (for linking)
        vzxn.cancel = true;
        
        try {
            const qvzr = qpwl(block.location);
    
            const bulkSelection = mxqz.zrxp(pqmx);
            if (bulkSelection) {
                mxqz.qvpn(pqmx, qvzr);
                vzpx.nzqv();
                return;
            }
    
            if (mvxr.has(qvzr)) {
                const linkedSwitchPos = mvxr.get(qvzr);
                ngzx(pqmx, `§cThis light is already linked to a switch at (${linkedSwitchPos})`);
                return;
            }
            
            const playerItemKey = `${pqmx.name}:${pqmx.selectedSlotIndex}`;
            
            let pendingLinks = nqzm.get(playerItemKey) || [];
            
            if (!pendingLinks.includes(qvzr)) {
                pendingLinks.push(qvzr);
                nqzm.set(playerItemKey, pendingLinks);
                
                qzrx.set(pqmx.name, pendingLinks);
                
                wklm(pqmx, "random.orb");
                ngzx(pqmx, `§aPending links: §e${pendingLinks.length} §alight(s). Place the switch now.`);
                
                vzpx.nzqv();
            } else {
                ngzx(pqmx, `§eThis light is already in your pending links (${pendingLinks.length} total)`);
            }
        } catch (error) {
            xmdk("Error linking light switch:", error, "error");
            vzpx.mxqz();
        }
    } else {
        // Using switch on any other block (attempting to place switch)
        // Check if player has pending links before allowing placement
        if (!pqzx(pqmx)) {
            vzxn.cancel = true;
            ngzx(pqmx, "§cCannot place switch: No pending light links found.");
            return;
        }
    }
});
        
// Handle switch placement after successful placement
jxle.afterEvents.playerPlaceBlock.subscribe((vzxn) => {
    const { block, player } = vzxn;
    
    if (block && block.typeId.includes("switch")) {
        qvrn(block, player);
    }
});
    
function qvrn(block, pqmx) {
    const vnzk = qpwl(block.location);
    
    const bulkSelection = mxqz.zrxp(pqmx);
    if (bulkSelection && bulkSelection.selectedLights.length > 0) {
        const pgnx = mxqz.qxzv(pqmx, vnzk);
        if (pgnx) {
            vzpx.nzqv();
            return;
        }
    }
    
    const playerItemKey = `${pqmx.name}:${pqmx.selectedSlotIndex}`;
    let pendingLights = nqzm.get(playerItemKey);
    
    if (!pendingLights || pendingLights.length === 0) {
        pendingLights = qzrx.get(pqmx.name);
    }
    
    if (pendingLights && pendingLights.length > 0) {
        const conflictingLights = [];
        for (const qvzr of pendingLights) {
            if (mvxr.has(qvzr) && mvxr.get(qvzr) !== vnzk) {
                conflictingLights.push(qvzr);
            }
        }
        
        if (conflictingLights.length > 0) {
            if (conflictingLights.length === pendingLights.length) {
                ngzx(pqmx, "§cAll lights are already linked to other switches");
                
                nqzm.delete(playerItemKey);
                qzrx.delete(pqmx.name);
                return;
            } else {
                pendingLights = pendingLights.filter(qvzr => !conflictingLights.includes(qvzr));
                ngzx(pqmx, `§e${conflictingLights.length} lights were already linked to other switches and were removed`);
            }
        }
        
        pxvn.set(vnzk, pendingLights);
        
        mxqn(block, pendingLights);
        
        ngzx(pqmx, "§6Turn on switch to confirm the links");
        ngzx(pqmx, `§6Pending links: §e${pendingLights.length} §6lights`);
        
        qzrx.set(pqmx.name, pendingLights);
        
        vzpx.nzqv();
        
        xmdk(`Set up ${pendingLights.length} pending links for switch at ${vnzk}`);
        
    } else {
        xmdk(`No linked lights found for player ${pqmx.name}`, "warn");
        ngzx(pqmx, "§cThis switch is not linked to any light. Use the switch on a light to link it first.");
    }
}

function mxqn(block, kzqp) {
    if (!block || !block.addTag || !kzqp) return;
    
    try {
        for (const qvzr of kzqp) {
            const tagName = `${qxmn}${qvzr}`;
            block.addTag(tagName);
            xmdk(`Added tag ${tagName} to switch for pending confirmation`);
        }
    } catch (e) {
        xmdk(`Error adding tags to block: ${e.message}`, "error");
    }
}

function pqzx(player) {
    // Check if player has pending links in any of the storage systems
    
    // Check player item key (name:slotIndex)
    const playerItemKey = `${player.name}:${player.selectedSlotIndex}`;
    const pendingFromSlot = nqzm.get(playerItemKey);
    if (pendingFromSlot && pendingFromSlot.length > 0) {
        xmdk(`Player ${player.name} has ${pendingFromSlot.length} pending links from slot ${player.selectedSlotIndex}`);
        return true;
    }
    
    // Check player name
    const pendingFromName = qzrx.get(player.name);
    if (pendingFromName && pendingFromName.length > 0) {
        xmdk(`Player ${player.name} has ${pendingFromName.length} pending links from name mapping`);
        return true;
    }
    
    // Check bulk operations system
    const bulkSelection = mxqz.zrxp(player);
    if (bulkSelection && bulkSelection.selectedLights.length > 0) {
        xmdk(`Player ${player.name} has ${bulkSelection.selectedLights.length} pending links from bulk selection`);
        return true;
    }
    
    xmdk(`Player ${player.name} has no pending links`);
    return false;
}

jxle.afterEvents.playerBreakBlock.subscribe(async (vzxn) => {
    const { brokenBlockPermutation, player } = vzxn;
    const vnzk = qpwl(vzxn.block.location);
    
    if (brokenBlockPermutation.type.id.includes("switch")) {
        await nqzv(vnzk, player);
    }
    
    if (mvxr.has(vnzk)) {
        await mxpr(vnzk, player);
    }
});