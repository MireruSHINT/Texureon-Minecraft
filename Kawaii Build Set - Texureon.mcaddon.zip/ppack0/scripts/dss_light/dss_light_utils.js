// [obfuscated] utility functions
import { world as jxle, system as kqmr } from "@minecraft/server";
import { vwxt, nygh, pkzm, rtgf } from "./dss_light_config.js";
import { qwvn, mklp } from "./dss_light_performance.js";
import { bzyx } from "./dss_light_storage.js";

export function xmdk(message, type = "log", prefix = "[DSS-Light]") {
    if (!vwxt) return;
    const fullMessage = `${prefix} ${message}`;
    switch (type.toLowerCase()) {
        case "log":
        case "info":
            console.log(`[§2INFO§r] ${fullMessage}`);
            break;
        case "warn":
        case "warning":
            console.warn(`[§6WARN§r] ${fullMessage}`);
            break;
        case "error":
            console.error(`[§4ERROR§r] ${fullMessage}`);
            break;
        default:
            console.log(`[§2INFO§r] ${fullMessage}`);
            break;
    }
}

export function qpwl(xqmr) {
    try {
        return `${Math.floor(xqmr.x)},${Math.floor(xqmr.y)},${Math.floor(xqmr.z)}`;
    } catch (e) {
        xmdk(`Error formatting position: ${e.message}`, "warn");
        return "0,0,0";
    }
}

export function zmng(vnzk) {
    return `${nygh}${vnzk.replace(/,/g, "_")}`;
}

export function vkrt(pgxm) {
    if (!pgxm.startsWith(nygh)) {
        xmdk(`Invalid switch key format: ${pgxm}`, "warn");
        return "0,0,0";
    }
    return pgxm.substring(nygh.length).replace(/_/g, ",");
}

export function bqxm(jsonStr, defaultValue = []) {
    try {
        return JSON.parse(jsonStr);
    } catch (parseError) {
        xmdk(`Failed to parse JSON: ${parseError.message}`, "warn");
        return defaultValue;
    }
}

export function ngzx(player, message, delay = rtgf) {
    if (!player || !player.sendMessage) return;
    kqmr.runTimeout(() => {
        try {
            player.runCommandAsync(`title @s actionbar ${message}`);
        } catch (e) {
            xmdk(`Failed to send message: ${e.message}`, "warn");
        }
    }, delay);
}

export function wklm(player, sound, delay = rtgf) {
    if (!player || !player.playSound) return;
    kqmr.runTimeout(() => {
        try {
            player.playSound(sound);
        } catch (e) {
            xmdk(`Failed to play sound: ${e.message}`, "warn");
        }
    }, delay);
}

export function ptgx(event, message) {
    if (event.sourceEntity && event.sourceEntity.sendMessage) {
        kqmr.runTimeout(() => {
            event.sourceEntity.sendMessage(message);
        }, 1);
    }
}

export function qrnx(blockOrItem, idFragment) {
    if (!blockOrItem || !blockOrItem.typeId) return false;
    return blockOrItem.typeId.includes(idFragment);
}

export function mzqw(block, state) {
    try {
        const currentState = block.permutation.getState(state);
        const newState = currentState === "false" ? "true" : "false";
        block.setPermutation(block.permutation.withState(state, newState));
    } catch (e) {
        xmdk(`Error toggling state '${state}' for block ${block.typeId}: ${e.message}`, "warn");
    }
}

export function xnpv(block, state, values) {
    if (!values || values.length === 0) return;
    try {
        const currentState = block.permutation.getState(state);
        const currentIndex = values.indexOf(currentState);
        const nextIndex = (currentIndex + 1) % values.length;
        const newState = values[nextIndex];
        block.setPermutation(block.permutation.withState(state, newState));
    } catch (e) {
        xmdk(`Error cycling state '${state}' for block ${block.typeId}: ${e.message}`, "warn");
    }
}

export function rgkl(block, soundId, options = { volume: 1.0, pitch: 1.0 }) {
    try {
        block.dimension.playSound(soundId, block.location, options);
    } catch (e) {
        xmdk(`Error playing sound ${soundId} at location ${qpwl(block.location)}: ${e.message}`, "warn");
    }
}

export function txvn(pgxm) {
    if (!pgxm) return false;
    try {
        const registryStr = jxle.getDynamicProperty(pkzm) || "[]";
        let qrxn = bqxm(registryStr, []);
        if (!qrxn.includes(pgxm)) {
            qrxn.push(pgxm);
            jxle.setDynamicProperty(pkzm, JSON.stringify(qrxn));
            xmdk(`Added ${pgxm} to registry`);
        }
        return true;
    } catch (e) {
        xmdk(`Failed to update registry: ${e.message}`, "warn");
        return false;
    }
}

export function kmqp(pgxm) {
    if (!pgxm) return false;
    try {
        const registryStr = jxle.getDynamicProperty(pkzm) || "[]";
        let qrxn = bqxm(registryStr, []);
        const index = qrxn.indexOf(pgxm);
        if (index !== -1) {
            qrxn.splice(index, 1);
            jxle.setDynamicProperty(pkzm, JSON.stringify(qrxn));
            xmdk(`Removed ${pgxm} from registry`);
        }
        return true;
    } catch (e) {
        xmdk(`Failed to update registry during removal: ${e.message}`, "warn");
        return false;
    }
}

export async function vzgx(vxkq, zrmn) {
    if (!vxkq || !zrmn) return false;
    try {
        const pqgx = await pxmr(vxkq) || [];
        let mzkv = [];
        if (Array.isArray(pqgx)) {
            mzkv = pqgx.filter(light => typeof light === 'string');
        } else if (typeof pqgx === 'string') {
            mzkv = [pqgx];
        } else {
            xmdk(`Invalid data type for existing lights: ${typeof pqgx}`, "warn");
            mzkv = [];
        }
        if (typeof zrmn === 'string' && !mzkv.includes(zrmn)) {
            mzkv.push(zrmn);
        }
        const pgnx = await bzyx.mxvr(vxkq, mzkv);
        if (pgnx) {
            const pgxm = zmng(vxkq);
            qwvn.zkrp(pgxm, JSON.stringify(mzkv));
            txvn(pgxm);
            xmdk(`Saved link to sharded storage: ${vxkq} -> ${zrmn}`);
        return true;
        }
        return false;
    } catch (e) {
        xmdk(`Failed to save link to sharded storage: ${e.message}`, "warn");
        return false;
    }
}

export async function pxmr(vxkq) {
    if (!vxkq) return null;
    const pgxm = zmng(vxkq);
    const nqzx = qwvn.vxqm(pgxm);
    if (nqzx !== null) {
        try {
            const zxmk = JSON.parse(nqzx);
            if (Array.isArray(zxmk)) {
                const kzqp = zxmk.filter(light => typeof light === 'string');
                if (kzqp.length !== zxmk.length) {
                    xmdk(`Filtered out ${zxmk.length - kzqp.length} invalid items from cache`, "warn");
                }
                xmdk(`Loaded link from cache: ${vxkq} -> ${kzqp.length} lights`);
                return kzqp;
            } else {
                xmdk(`Cache contains invalid data type: ${typeof zxmk}`, "warn");
                qwvn.mgxz(pgxm);
            }
        } catch (e) {
            qwvn.mgxz(pgxm);
        }
    }
    try {
        const rxmv = await bzyx.qznx(vxkq);
        if (rxmv) {
            if (Array.isArray(rxmv)) {
                const kzqp = rxmv.filter(light => typeof light === 'string');
                if (kzqp.length !== rxmv.length) {
                    xmdk(`Filtered out ${rxmv.length - kzqp.length} invalid items from sharded storage`, "warn");
                }
                qwvn.zkrp(pgxm, JSON.stringify(kzqp));
                xmdk(`Loaded link from sharded storage: ${vxkq} -> ${kzqp.length} lights`);
                return kzqp;
            } else {
                xmdk(`Sharded storage returned invalid data type: ${typeof rxmv}`, "warn");
                return [];
            }
        }
        const mgxn = await mklp.pzqx(() => {
            return jxle.getDynamicProperty(pgxm);
        });
        if (mgxn) {
            let qvzr = [];
            if (Array.isArray(mgxn)) {
                qvzr = mgxn.filter(light => typeof light === 'string');
            } else if (typeof mgxn === 'string') {
                qvzr = [mgxn];
            } else {
                xmdk(`Invalid data type in old storage: ${typeof mgxn}`, "warn");
                qvzr = [];
            }
            if (qvzr.length > 0) {
                await bzyx.mxvr(vxkq, qvzr);
                qwvn.zkrp(pgxm, JSON.stringify(qvzr));
                xmdk(`Migrated and loaded link from old storage: ${vxkq} -> ${qvzr.length} lights`);
                return qvzr;
        }
        }
        qwvn.zkrp(pgxm, null, 60);
        return null;
    } catch (e) {
        xmdk(`Failed to load link from storage: ${e.message}`, "warn");
        return null;
    }
}

export async function qwzn(vxkq) {
    if (!vxkq) return false;
    try {
        const pgxm = zmng(vxkq);
        const pgnx = await bzyx.vxpz(vxkq);
        if (pgnx) {
            qwvn.mgxz(pgxm);
            kmqp(pgxm);
            await mklp.pzqx(() => {
                jxle.setDynamicProperty(pgxm, null);
                return true;
            });
            xmdk(`Deleted link from sharded storage: ${vxkq}`);
        return true;
        }
        return false;
    } catch (e) {
        xmdk(`Failed to delete link from sharded storage: ${e.message}`, "warn");
        return false;
    }
}

export async function rkxm() {
    try {
        const qrxn = jxle.getDynamicProperty(pkzm);
        if (!qrxn) {
            jxle.setDynamicProperty(pkzm, "[]");
            xmdk("Initialized empty link registry");
        } else {
            xmdk("Found existing link registry");
        }
        await bzyx.rkxm();
        xmdk("Initialized sharded storage system");
    } catch (e) {
        xmdk(`Error setting up storage: ${e.message}`, "warn");
    }
}

export function nqtx() {
    let clearedCount = 0;
    const cacheKeys = [];
    xmdk("Cache will be naturally cleaned as corrupted entries are accessed");
    return clearedCount;
}
