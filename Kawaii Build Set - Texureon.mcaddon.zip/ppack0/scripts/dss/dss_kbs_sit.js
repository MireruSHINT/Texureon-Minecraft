import { world, BlockPermutation } from '@minecraft/server';

// Configuration for different furniture types
const KBS_CONFIG = {
    "tub": { yOffset: 0.0 },
    "float_lounger": { yOffset: 0.0 },
    "rocking_chair": { yOffset: 0.45 },
    "stool": { yOffset: 0.30 },
    "sun_lounger": { yOffset: 0.23 },
    "bench": { yOffset: 0.23 },
    "sofa": { yOffset: 0.23 },
    "couch": { yOffset: 0.23 },
    "chair_1": { yOffset: 0.45 },
    "chair_4": { yOffset: 0.55 },
    "chair": { yOffset: 0.23 },
    "bed": { yOffset: 0.30 },
    "toilet": { yOffset: 0.6 }
}

const BBS_CONFIG = {
    "bathtub": { yOffset: 0.0 },
    "float_lounger": { yOffset: 0.0 },
    "rocking_chair": { yOffset: 0.45 },
    "stool": { yOffset: 0.30 },
    "sun_lounger": { yOffset: 0.23 },
    "bench": { yOffset: 0.23 },
    "sofa": { yOffset: 0.35 },
    "couch": { yOffset: 0.23 },
    "chair": { yOffset: 0.4 },
    "toilet": { yOffset: 0.4 },
};

// Entity and configuration mappings with their custom components
const ENTITY_CONFIG_MAP = [
    {
        entity: "dss_kbs:kbs_sitting",
        config: KBS_CONFIG,
        customComponent: "dss:kbs_sittings"
    },
    {
        entity: "dss_bbs:bbs_sitting", 
        config: BBS_CONFIG,
        customComponent: "dss:bbs_sittings"
    }
];

const state = "dss:sitting";

// Helper function to get furniture type and offset from any configuration
function getFurnitureConfig(blockId, configObj) {
    // Check for exact match first
    if (configObj[blockId]) {
        return { type: blockId, ...configObj[blockId] };
    }
    
    // Check for partial matches
    for (const [key, config] of Object.entries(configObj)) {
        if (blockId.includes(key)) {
            return { type: key, ...config };
        }
    }
    
    return null;
}

// Helper function to create sitting entity
function createSittingEntity(block, player, entityType, yOffset) {
    const location = block.location;
    const ride_location = { 
        x: location.x + 0.5, 
        y: location.y + yOffset, 
        z: location.z + 0.5 
    };
    
    const ride = block.dimension.spawnEntity(entityType, ride_location);
    
    // Update block state
    let newPermutation = BlockPermutation.resolve(block.typeId, {
        ...block.permutation.getAllStates(),
        [state]: true
    });
    block.setPermutation(newPermutation);
    
    // Add player as rider
    const addrider = ride.getComponent("rideable");
    addrider.addRider(player);
}

// Helper function to check and remove sitting entity for specific entity type
function checkAndRemoveSittingEntity(block, entityType, yOffset) {
    const location = block.location;
    const ride_location = { 
        x: location.x + 0.5, 
        y: location.y + yOffset, 
        z: location.z + 0.5 
    };
    
    try {
        const ride = block.dimension.getEntities({ 
            type: entityType, 
            location: ride_location, 
            maxDistance: 0.1 
        });

        for (const entity of ride) {
            const despawn = entity.getComponent("is_stunned");
            if (despawn) {
                let newPermutation = BlockPermutation.resolve(block.typeId, {
                    ...block.permutation.getAllStates(),
                    [state]: false
                });
                block.setPermutation(newPermutation);
                return true;
            }
        }
    } catch (error) {
        // Handle any errors silently
    }
    
    return false;
}

// Factory function to create custom components for each entity/config pair
function createRideComponent(entityType, configObj) {
    return {
        onPlayerInteract(event) {
            const { block, player } = event;
            const block_ride = block.permutation.getState(state);

            // Only proceed if the block is not already being sat on
            if (block_ride === false) {
                const config = getFurnitureConfig(block.typeId, configObj);
                if (config) {
                    createSittingEntity(block, player, entityType, config.yOffset);
                }
            }
        },
        
        onTick(event) {
            const { block } = event;
            const block_ride = block.permutation.getState(state);
            
            // Only check blocks that are being sat on
            if (block_ride === true) {
                const config = getFurnitureConfig(block.typeId, configObj);
                if (config) {
                    checkAndRemoveSittingEntity(block, entityType, config.yOffset);
                }
            }
        }
    };
}

// Handle block breaking - remove all possible sitting entities
world.afterEvents.playerBreakBlock.subscribe((event) => {
    const { block } = event;
    const block_ride = block.permutation.getState(state);
    if (block_ride === true) {
        block.setPermutation(BlockPermutation.resolve(block.typeId, { [state]: false }));
    }
    const location = block.location;
    const ride_location = { 
        x: location.x + 0.5, 
        y: location.y + 0.5, 
        z: location.z + 0.5 
    };

    // Remove all possible sitting entities
    for (const mapping of ENTITY_CONFIG_MAP) {
        const rideEntities = block.dimension.getEntities({ 
            type: mapping.entity, 
            location: ride_location 
        });

        rideEntities.forEach(ride => {
            ride.remove(); // Remove the sitting entity
        });
    }
});

// Register all custom components
world.beforeEvents.worldInitialize.subscribe(({ blockComponentRegistry }) => {
    for (const mapping of ENTITY_CONFIG_MAP) {
        const rideComponent = createRideComponent(mapping.entity, mapping.config);
        blockComponentRegistry.registerCustomComponent(mapping.customComponent, rideComponent);
    }
});
