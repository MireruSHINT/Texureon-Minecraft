import * as mc from "@minecraft/server";
import "./mech_guidebook";

const autoSmeltItems = new Map([
    ["minecraft:raw_copper", "minecraft:copper_ingot"],
    ["minecraft:raw_gold", "minecraft:gold_ingot"],
    ["minecraft:raw_iron", "minecraft:iron_ingot"],
    ["minecraft:cobblestone", "minecraft:stone"],
    ["minecraft:sand", "minecraft:glass"]
]);

const indestructibleBlocks = [
    "minecraft:bedrock", "minecraft:barrier",
    "minecraft:command_block", "minecraft:structure_block",
    "minecraft:end_portal", "minecraft:reinforced_deepslate",
    "minecraft:water", "minecraft:flowing_water",
    "minecraft:lava", "minecraft:flowing_lava", "minecraft:end_portal_frame"
];

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity}) => {
    const [ entityPos, entityRot, entityYaw, dimension ] = [ entity.location, entity?.getRotation(), entity.getProperty('nv_me:yaw'), entity.dimension ];
    const velocityMap = entity.getVelocity();
    const forwardSpeed = velocityMap.x * -Math.sin(entityYaw * (Math.PI / 180)) + velocityMap.z * Math.cos(entityYaw * (Math.PI / 180));
    const torsoRotation = Math.min(Math.max(((entityRot.y - entityYaw + 540) % 360 - 180) * 6, -10), 10);
    const fuel = entity.getProperty('nv_me:fuel');
    const health = entity.getComponent('minecraft:health');
    const displayWarn = entity.getProperty('nv_me:display_warn');
    const skillLevel = entity.getProperty('nv_me:skill_level');
    const protectionLevel = entity.getProperty('nv_me:protection_level');
    const mining = entity.getProperty('nv_me:mining');
    const flamethrower = entity.getProperty('nv_me:flamethrower');
    const hasBlock = entity.getProperty('nv_me:has_block');

    // Rotation System
    if (forwardSpeed > 0.01 || forwardSpeed < -0.01) entity.setProperty('nv_me:yaw', entityRot.y);
    else entity.setRotation({ x: 0, y: entityYaw });
    entity.setProperty('nv_me:torso', torsoRotation);

    if (forwardSpeed < -0.01) entity.addEffect('speed', 2, {showParticles: false, amplifier: 2});

    if (fuel == 0) {
        entity.addEffect('slowness', 5, {showParticles: false, amplifier: 255});
        if (entity.typeId == 'nv_me:battle_mech') entity.setProperty('nv_me:punch', 0);
        if (flamethrower) entity.setProperty('nv_me:flamethrower', false);
    };
    if (forwardSpeed > 0.01 || forwardSpeed < -0.01) {
        if (entity.typeId == 'nv_me:mining_mech' && mining && hasBlock) {
            entity.setProperty('nv_me:fuel', Math.max(fuel - 0.01, 0));
        } else if (entity.typeId == 'nv_me:jump_mech' && !entity.isOnGround) {
            entity.setProperty('nv_me:fuel', Math.max(fuel - 0.01, 0));
        } else if (entity.typeId == 'nv_me:flamethrower_mech' && flamethrower) {
            entity.setProperty('nv_me:fuel', Math.max(fuel - 0.02, 0));
        } else entity.setProperty('nv_me:fuel', Math.max(fuel - 0.005, 0));
    } else if (entity.typeId == 'nv_me:flamethrower_mech' && flamethrower) {
        entity.setProperty('nv_me:fuel', Math.max(fuel - 0.01, 0));
    };

    // Add tag to player
    const mechRider = entity.getComponent('minecraft:rideable').getRiders();
    mechRider[0]?.playAnimation('animation.nv_me.player_rotation', {nextState: 'none', blendOutTime: 0,  stopExpression: `return !q.is_riding;`});
    if (!mechRider[0]?.hasTag('nv_me:in_mech')) {
        entity.addEffect('slowness', 6, {showParticles: false, amplifier: 255});
        mc.system.run(() => { mechRider[0]?.addTag('nv_me:in_mech'); });
    };
    
    // Headlight System
    const headlight = entity.getProperty('nv_me:headlight');
    const oldHeadlightPos = entity.getDynamicProperty('nv_me:headlightPos');
    const relativeHeadlightPos = relativeLocation({ x: 0, y: entityYaw }, {x: 0, y: 1, z: -1});
    const newHeadlightPos = { x: entityPos.x+relativeHeadlightPos.x, y: entityPos.y+relativeHeadlightPos.y, z: entityPos.z+relativeHeadlightPos.z };
    if (headlight) {
        if (oldHeadlightPos) entity.dimension.setBlockType(oldHeadlightPos, 'minecraft:air');
        if (entity.dimension.getBlock(newHeadlightPos)?.isAir) {
            entity.setDynamicProperty('nv_me:headlightPos', newHeadlightPos);
            entity.dimension.setBlockType(newHeadlightPos, 'minecraft:light_block_15');
        } else entity.setDynamicProperty('nv_me:headlightPos', undefined);
    } else if (oldHeadlightPos) {
        entity.dimension.setBlockType(oldHeadlightPos, 'minecraft:air');
        entity.setDynamicProperty('nv_me:headlightPos', undefined);
    };

    // Removes tag to player
    const playersOut = dimension.getPlayers({location: entityPos, maxDistance: 6}).filter(p => !mechRider.includes(p));
    if (playersOut.length > 0) playersOut.forEach(player => {
        if (player.hasTag('nv_me:in_mech') && !player.getComponent('minecraft:riding')?.entityRidingOn) {
            player.playAnimation('animation.player.attack.positions', {nextState: 'none', blendOutTime: 0,  stopExpression: `return !q.is_riding;`});
            player.removeTag('nv_me:in_mech');
        };
    });

    if (!mechRider[0] || fuel == 0) {
        if (entity.typeId == 'nv_me:mining_mech' && mining) {
            entity.setProperty('nv_me:mining', false);
            entity.runCommand('/stopsound @a[r=10] nv_me:mech.actived_drill');
        };
        if (entity.typeId == 'nv_me:flamethrower_mech' && flamethrower) {
            entity.setProperty('nv_me:flamethrower', false);
            entity.runCommand('/stopsound @a[r=10] nv_me:mech.flamethrower_sound');
        };
        if (headlight) {
            entity.setProperty('nv_me:headlight', false);
            entity.dimension.setBlockType(oldHeadlightPos, 'minecraft:air');
            entity.setDynamicProperty('nv_me:headlightPos', undefined);
        };
    };

    // Display
    if (displayWarn) {
        const currentHealth = health.currentValue;
        if (currentHealth < 10 && fuel > 0) {
            mechRider[0]?.onScreenDisplay.setActionBar({rawtext: [
                {text: `§b`}, {translate: 'nv_me.mech.fuel'}, {text: ` ${mechDisplay(fuel)}`}, {text: ` (§e${fuel.toFixed()}%§r)\n§9`},
                {translate: 'nv_me.mech.skill_level'}, {text: ` §e${entity.typeId.includes('standard') ? 'X' : skillLevel}`}, {text: '   §9'},
                {translate: 'nv_me.mech.protection_level'}, {text: ` §e${protectionLevel}`},
                {text: '\n§c'}, {translate: 'nv_me.mech.low_health'}
            ]});
        };
        if (currentHealth >= 10 && fuel == 0) {
            mechRider[0]?.onScreenDisplay.setActionBar({rawtext: [
                {text: `§b`}, {translate: 'nv_me.mech.fuel'}, {text: ` ${mechDisplay(fuel)}`}, {text: ` (§e${fuel.toFixed()}%§r)\n§9`},
                {translate: 'nv_me.mech.skill_level'}, {text: ` §e${entity.typeId.includes('standard') ? 'X' : skillLevel}`}, {text: '   §9'},
                {translate: 'nv_me.mech.protection_level'}, {text: ` §e${protectionLevel}`},
                {text: '\n§6'}, {translate: 'nv_me.mech.low_fuel'}
            ]});
        };
        if (currentHealth < 10 && fuel == 0) {
            mechRider[0]?.onScreenDisplay.setActionBar({rawtext: [
                {text: `§b`}, {translate: 'nv_me.mech.fuel'}, {text: ` ${mechDisplay(fuel)}`}, {text: ` (§e${fuel.toFixed()}%§r)\n§9`},
                {translate: 'nv_me.mech.skill_level'}, {text: ` §e${entity.typeId.includes('standard') ? 'X' : skillLevel}`}, {text: '   §9'},
                {translate: 'nv_me.mech.protection_level'}, {text: ` §e${protectionLevel}`},
                {text: '\n§c'}, {translate: 'nv_me.mech.low_health'}, {text: '   §r'},
                {text: '§6'}, {translate: 'nv_me.mech.low_fuel'}
            ]});
        };
    } else {
        mechRider[0]?.onScreenDisplay.setActionBar({rawtext: [
            {text: `§b`}, {translate: 'nv_me.mech.fuel'}, {text: ` ${mechDisplay(fuel)}`}, {text: ` (§e${fuel.toFixed()}%§r)\n§9`},
            {translate: 'nv_me.mech.skill_level'}, {text: ` §e${entity.typeId.includes('standard') ? 'X' : skillLevel}`}, {text: '   §9'},
            {translate: 'nv_me.mech.protection_level'}, {text: ` §e${protectionLevel}`},
        ]});
    };

    
    // Jumping
    if (entity.isOnGround && mechRider[0]?.isJumping) entity.addTag('nv_me:first_jump');
    if (entity.hasTag('nv_me:first_jump') && !entity.isOnGround) {
        entity.removeTag('nv_me:first_jump');
        entity.addTag('nv_me:is_jumping');
    };
    if (entity.hasTag('nv_me:is_jumping') && entity.isOnGround) {
        entity.removeTag('nv_me:is_jumping');
        const hitEntities = entity.dimension.getEntities({location: entity.location, maxDistance: 5}).filter(targetEntity => ![mechRider[0]?.id, entity.id].includes(targetEntity.id));
        hitEntities.forEach(hitEntity => {
            if (!['minecraft:item', 'minecraft:xp_orb', 'minecraft:arrow'].includes(hitEntity.typeId) && !(hitEntity.typeId == 'minecraft:player' && hitEntity.getComponent('minecraft:riding')?.entityRidingOn.typeId.includes('mech'))) {
                hitEntity.applyDamage(10);
                hitEntity?.applyKnockback(0, 0, 0.2, 0.7);
            };
        });
    };
    if (entity.typeId == 'nv_me:jump_mech' && entity.hasTag('nv_me:is_jumping')) {
        const skillLevel = entity.getProperty('nv_me:skill_level');
        const direction = entity.getViewDirection();
        if (!entity.isOnGround) entity.applyImpulse({ x: direction.x * ((skillLevel/1.2) * 0.01), y: 0.065, z: direction.z * ((skillLevel/1.2) * 0.01), });
    };

    // Mining
    if (entity.typeId == 'nv_me:mining_mech' && mining) {
        const yawRad = (entityYaw + 90) * (Math.PI / 180);
        const targetBlock = entity.dimension.getBlockFromRay(
            { x: entity.location.x, y: entity.location.y + 2, z: entity.location.z },
            { x: Math.cos(yawRad), y: 0, z: Math.sin(yawRad) },
            { maxDistance: 6 }
        );
        if (targetBlock) entity.setProperty('nv_me:has_block', true);
        else entity.setProperty('nv_me:has_block', false);
    };    
}, {eventTypes: ['nv_me:ticking']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    const currentFuel = entity.getProperty('nv_me:fuel') || 0;
    let newFuel = Math.min(100, currentFuel + (eventId == 'nv_me:refuel_lava' ? 30 : 2.5));
    entity.setProperty('nv_me:fuel', newFuel);
    entity.dimension.playSound('nv_me:mech.fuel_insert', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
}, {eventTypes: ['nv_me:refuel_coal', 'nv_me:refuel_lava']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    entity.dimension.playSound('note.bass', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z}, {volume: 0.5, pitch: 1.5});
    entity.dimension.getPlayers({location: entity.location, maxDistance: 4}).forEach(player => {
        player.onScreenDisplay.setActionBar({rawtext: [{text: `§c`}, {translate: 'nv_me.mech.max_fuel'}]});
    });
}, {eventTypes: ['nv_me:max_refuel']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    entity.dimension.playSound('note.bell', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z}, {volume: 0.5});
    entity.dimension.getPlayers({location: entity.location, maxDistance: 4}).forEach(player => {
        player.onScreenDisplay.setActionBar({rawtext: [{text: `§e`}, {translate: 'nv_me.mech.no_fuel'}]});
    });
}, {eventTypes: ['nv_me:no_fuel']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    const currentFuel = entity.getProperty('nv_me:fuel');
    let newFuel = Math.max(0, currentFuel - 1);
    entity.setProperty('nv_me:fuel', newFuel);
}, {eventTypes: ['nv_me:spend_fuel']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    const state = entity.getProperty('nv_me:headlight');
    entity.setProperty('nv_me:headlight', !state);
    entity.dimension.playSound('nv_me:mech.headlight_turn', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
}, {eventTypes: ['nv_me:headlight']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(async ({entity, eventId}) => {
    entity.addTag('nv_me:disassemble');
    entity.playAnimation('animation.nv_me.mech.disassemble', {blendOutTime: 9999999});
    entity.dimension.playSound('nv_me:mech.disassemble', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
    entity.dimension.spawnParticle('nv_me:construct_smoke', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
    await mc.system.waitTicks(20);
    entity.dimension.spawnItem(new mc.ItemStack(entity.typeId + '_item', 1), entity.location);
    const skillLevel = entity.getProperty('nv_me:skill_level');
    const protectionLevel = entity.getProperty('nv_me:protection_level');
    if (skillLevel > 1) entity.dimension.spawnItem(new mc.ItemStack('nv_me:skill_upgrade_lv' + skillLevel), entity.location);
    if (protectionLevel > 1) entity.dimension.spawnItem(new mc.ItemStack('nv_me:protection_upgrade_lv' + protectionLevel), entity.location);
    entity.remove();
}, {eventTypes: ['nv_me:despawn']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    entity.addEffect('instant_health', 5, {showParticles: false, amplifier: 255});
    entity.dimension.playSound('nv_me:mech.spawn_mech', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
}, {eventTypes: ['nv_me:repair_mech']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    entity.dimension.playSound('nv_me:mech.warn', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
}, {eventTypes: ['nv_me:sound_warn']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    if (entity.typeId == 'nv_me:battle_mech') entity.setProperty('nv_me:punch', Math.min(entity.getProperty('nv_me:punch') + 1, 2));
    if (entity.typeId == 'nv_me:mining_mech') {
        const state = entity.getProperty('nv_me:mining');
        if (state) entity.setProperty('nv_me:has_block', false);
        entity.setProperty('nv_me:mining', !state);
        entity.dimension.playSound('nv_me:mech.headlight_turn', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
    };
    if (entity.typeId == 'nv_me:flamethrower_mech') {
        const state = entity.getProperty('nv_me:flamethrower');
        if (state) entity.dimension.playSound('nv_me:mech.jetpack_end', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
        entity.setProperty('nv_me:flamethrower', !state);
        
    };
}, {eventTypes: ['nv_me:hit_action']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    const skillLevel = entity.getProperty('nv_me:skill_level');
    entity.setProperty('nv_me:punch', Math.max(entity.getProperty('nv_me:punch') - 1, 0));
    const punchLocation = relativeLocation({ x: 0, y: entity.getProperty('nv_me:yaw') }, {x: 0, y: 1, z: -2});
    const mechRider = entity.getComponent('minecraft:rideable').getRiders();
    const hitEntities = entity.dimension.getEntities({location: {
        x: entity.location.x + punchLocation.x,
        y: entity.location.y + punchLocation.y,
        z: entity.location.z + punchLocation.z
    }, maxDistance: 4}).filter(targetEntity => ![mechRider[0]?.id, entity.id].includes(targetEntity.id));
    const knockbackDir = entity.getViewDirection();
    hitEntities.forEach(hitEntity => {
        if (!['minecraft:item', 'minecraft:xp_orb', 'minecraft:arrow'].includes(hitEntity.typeId) && !(hitEntity.typeId == 'minecraft:player' && hitEntity.getComponent('minecraft:riding')?.entityRidingOn.typeId.includes('mech'))) {
            hitEntity.applyDamage(5 + (5 * skillLevel));
            if (skillLevel >= 4) hitEntity?.applyKnockback(knockbackDir.x, knockbackDir.z, skillLevel, skillLevel/7);
            if (skillLevel >= 5) hitEntity?.setOnFire(5);
        };
    });
}, {eventTypes: ['nv_me:punch']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    const skillLevel = entity.getProperty('nv_me:skill_level');
    const entityYaw = entity.getProperty('nv_me:yaw');
    const velocityMap = entity.getVelocity();
    const forwardSpeed = velocityMap.x * -Math.sin(entityYaw * (Math.PI / 180)) + velocityMap.z * Math.cos(entityYaw * (Math.PI / 180));
    const fireLocation = relativeLocation({ x: 0, y: entity.getProperty('nv_me:yaw') }, {x: 0, y: 1, z: forwardSpeed > 0.1 ? 0 : -3});
    const mechRider = entity.getComponent('minecraft:rideable').getRiders();
    const fireEntities = entity.dimension.getEntities({location: {
        x: entity.location.x + fireLocation.x,
        y: entity.location.y + fireLocation.y,
        z: entity.location.z + fireLocation.z
    }, maxDistance: 4}).filter(targetEntity => ![mechRider[0]?.id, entity.id].includes(targetEntity.id));
    fireEntities.forEach(fireEntity => {
        if (!['minecraft:item', 'minecraft:xp_orb'].includes(fireEntity.typeId) && !(fireEntity.typeId == 'minecraft:player' && fireEntity.getComponent('minecraft:riding')?.entityRidingOn.typeId.includes('mech')) && !fireEntity.typeId.includes('mech')) {
            fireEntity.applyDamage(5 + skillLevel);
            fireEntity.setOnFire(5 * skillLevel, true);
        };
    });
    const forwardDirection = {
        x: -Math.sin(entityYaw * (Math.PI / 180)),
        z: Math.cos(entityYaw * (Math.PI / 180))
    };
    const rightDirection = {
        x: Math.cos(entityYaw * (Math.PI / 180)),
        z: Math.sin(entityYaw * (Math.PI / 180))
    };
    const fireDistance = forwardSpeed > 0.1 ? 3 : 5 + skillLevel*0.8;
    for (let i = 2; i <= fireDistance; i++) { 
        for (let j = -1; j <= 1; j++) {
            const fireBlockLocation = {
                x: Math.floor(entity.location.x + forwardDirection.x * i + rightDirection.x * j),
                y: Math.floor(entity.location.y - 1),
                z: Math.floor(entity.location.z + forwardDirection.z * i + rightDirection.z * j)
            };
            const targetBlock = entity.dimension.getBlock(fireBlockLocation);
            if (targetBlock && !targetBlock.isAir && !targetBlock.typeId.includes('water')) {
                const aboveBlock = targetBlock.above();
                if (aboveBlock.isAir) aboveBlock.setType('minecraft:fire');
            };
        };
    };
}, {eventTypes: ['nv_me:flamethrower']});

mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(({entity, eventId}) => {
    const skillLevel = entity.getProperty('nv_me:skill_level');
    const entityYaw = entity.getProperty('nv_me:yaw');
    const yawRad = (entityYaw + 90) * (Math.PI / 180);
    const targetBlock = entity.dimension.getBlockFromRay(
        { x: entity.location.x, y: entity.location.y + 2, z: entity.location.z },
        { x: Math.cos(yawRad), y: 0, z: Math.sin(yawRad) },
        { maxDistance: 5 }
    );

    let thisFace = targetBlock?.face.toLowerCase();    
    for (let x = -2; x <= 3; x++) {
        for (let z = -2; z <= 3; z++) {
            if (!targetBlock?.block) return;
            let thisBlock;
            if (thisFace == "above" || thisFace == "below") {
                thisBlock = targetBlock?.block.dimension.getBlock({x:targetBlock?.block.x+x, y:targetBlock?.block.y, z:targetBlock?.block.z+z});
            };
            if (thisFace == "north" || thisFace == "south") {
                thisBlock = targetBlock?.block.dimension.getBlock({x:targetBlock?.block.x+x, y:targetBlock?.block.y+z, z:targetBlock?.block.z});
            };
            if (thisFace == "west" || thisFace == "east") {
                thisBlock = targetBlock?.block.dimension.getBlock({x:targetBlock?.block.x, y:targetBlock?.block.y+x, z:targetBlock?.block.z+z});
            };
            if (thisBlock && indestructibleBlocks.includes(thisBlock.typeId)) continue;
            if (!thisBlock?.isAir && thisBlock) {
                if (skillLevel >= 5) {
                    const oreToItemMap = {
                        'minecraft:diamond_ore': 'minecraft:diamond',
                        'minecraft:gold_ore': 'minecraft:gold_ingot',
                        'minecraft:iron_ore': 'minecraft:iron_ingot',
                        'minecraft:lapis_ore': 'minecraft:lapis_lazuli',
                        'minecraft:redstone_ore': 'minecraft:redstone',
                        'minecraft:emerald_ore': 'minecraft:emerald',
                        'minecraft:coal_ore': 'minecraft:coal',
                        'minecraft:nether_quartz_ore': 'minecraft:nether_quartz'
                    };
                
                    if (oreToItemMap[thisBlock?.typeId]) {
                        const itemType = oreToItemMap[thisBlock?.typeId];
                        const fortuneMultiplier = Math.max(1, Math.floor(Math.random() * 2) + 1);
                        const amount = Math.min(Math.floor(Math.random() * 10 / 2), 3) * fortuneMultiplier;
                        thisBlock?.dimension.spawnItem(new mc.ItemStack(itemType, amount), thisBlock?.location);
                    }
                };
                targetBlock?.block.dimension.runCommand(`setblock ${thisBlock.x} ${thisBlock.y} ${thisBlock.z} air destroy`);
                if (skillLevel >= 4) {
                    const blockLocation = targetBlock.block.center(); 
                    mc.system.run(() => {
                        const droppedItems = targetBlock?.block.dimension.getEntities({location: blockLocation, type: 'minecraft:item', maxDistance: 4});
                        for (let item of droppedItems) {
                            const itemStack = item?.getComponent('minecraft:item').itemStack;
                            if (autoSmeltItems.has(itemStack.typeId)) {
                                item.dimension.spawnItem(new mc.ItemStack(autoSmeltItems.get(itemStack.typeId), itemStack.amount), item.location);
                                item.dimension.spawnParticle('minecraft:basic_flame_particle', item.location);
                                if (skillLevel >= 4)
                                item.remove();
                            };
                        };
                    });
                };
            };
        };
    };

    entity.setProperty('nv_me:has_block', false);
}, {eventTypes: ['nv_me:mining1', 'nv_me:mining2', 'nv_me:mining3', 'nv_me:mining4', 'nv_me:mining5']});


mc.world.afterEvents.entityHitEntity.subscribe(({damagingEntity: player, hitEntity: entity}) => {
    if (player.typeId != 'minecraft:player') return;
    const rideMech = player.getComponent('minecraft:riding')?.entityRidingOn;
    if (rideMech?.typeId.includes('mech')) {
        if (rideMech.typeId == 'nv_me:battle_mech') rideMech.setProperty('nv_me:punch', Math.min(rideMech.getProperty('nv_me:punch') + 1, 2));
    };
});

mc.world.afterEvents.entityHurt.subscribe(({damage, damageSource, hurtEntity}) => {
    if (hurtEntity?.typeId.includes('mech')) {
        const health = hurtEntity?.getComponent('minecraft:health');
        if (health.currentValue < 20) {
            hurtEntity.dimension.playSound('nv_me:mech.warn', {x: hurtEntity.location.x, y: hurtEntity.location.y + 1, z: hurtEntity.location.z});
            hurtEntity.dimension.spawnParticle('nv_me:construct_smoke', {x: hurtEntity.location.x, y: hurtEntity.location.y+ 3, z: hurtEntity.location.z});
        };
    };
});

mc.world.afterEvents.entityLoad.subscribe(({entity}) => {
    if (!entity.typeId.includes('mech')) return;
    entity.removeTag('nv_me:is_jumping');
    entity.removeTag('nv_me:first_jump');
    if (entity.hasTag('nv_me:disassemble')) {
        entity.dimension.spawnItem(new mc.ItemStack(entity.typeId + '_item', 1), entity.location);
        const skillLevel = entity.getProperty('nv_me:skill_level');
        const protectionLevel = entity.getProperty('nv_me:protection_level');
        if (skillLevel > 1) entity.dimension.spawnItem(new mc.ItemStack('nv_me:skill_upgrade_lv' + skillLevel), entity.location);
        if (protectionLevel > 1) entity.dimension.spawnItem(new mc.ItemStack('nv_me:protection_upgrade_lv' + protectionLevel), entity.location);
        entity.remove();
    };
});

mc.world.afterEvents.entitySpawn.subscribe(({ entity }) => {
    if (entity.typeId.includes('mech')) {
        const player = entity.dimension.getPlayers({location: entity.location, maxDistance: 10})[0];
        const rotation = player.getRotation();
        entity.dimension.playSound('nv_me:mech.spawn_mech', {x: entity.location.x, y: entity.location.y + 1, z: entity.location.z});
        entity.dimension.spawnParticle('nv_me:construct_smoke', {x: entity.location.x, y: entity.location.y+ 1, z: entity.location.z});
        entity.dimension.spawnParticle('nv_me:construct_smoke', {x: entity.location.x + 1, y: entity.location.y + 2, z: entity.location.z});
        entity.dimension.spawnParticle('nv_me:construct_smoke', {x: entity.location.x, y: entity.location.y + 3, z: entity.location.z + 1});
        entity.setProperty('nv_me:yaw', (((rotation.y + 180) % 360) + 540) % 360 - 180);
        entity.setRotation({x: 0, y: (((rotation.y + 180) % 360) + 540) % 360 - 180});
    };
});

mc.world.afterEvents.playerInteractWithEntity.subscribe(({player, target, beforeItemStack: ItemStack}) => {
    if (!target.typeId.includes('standard') && target.typeId.includes('mech') && ItemStack?.typeId.includes('skill_upgrade')) {
        const skillLevel = target.getProperty('nv_me:skill_level');
        const skillTarget = Number(ItemStack.typeId.replace('nv_me:skill_upgrade_lv', ''));
        if (skillLevel > 1) player.dimension.spawnItem(new mc.ItemStack('nv_me:skill_upgrade_lv' + skillLevel), player.location);
        removeItem(player, 'nv_me:skill_upgrade_lv' + skillTarget, 1);
        target.setProperty('nv_me:skill_level', skillTarget);
        target.dimension.playSound('nv_me:mech.fuel_insert', {x: target.location.x, y: target.location.y + 1, z: target.location.z});
    };
    if (target.typeId.includes('mech') && ItemStack?.typeId.includes('protection_upgrade')) {
        const protectionLevel = target.getProperty('nv_me:protection_level');
        const protectionTarget = Number(ItemStack.typeId.replace('nv_me:protection_upgrade_lv', ''));
        if (protectionLevel > 1) player.dimension.spawnItem(new mc.ItemStack('nv_me:protection_upgrade_lv' + protectionLevel), player.location);
        removeItem(player, 'nv_me:protection_upgrade_lv' + protectionTarget, 1);
        target.setProperty('nv_me:protection_level', protectionTarget);
        target.dimension.playSound('nv_me:mech.fuel_insert', {x: target.location.x, y: target.location.y + 1, z: target.location.z});
    };
    if (target.typeId.includes('standard') && target.typeId.includes('mech') && ItemStack?.typeId.includes('skill_upgrade')) {
        target.dimension.playSound('note.bass', {x: target.location.x, y: target.location.y + 1, z: target.location.z}, {volume: 0.5, pitch: 1.5});
        target.dimension.getPlayers({location: target.location, maxDistance: 5}).forEach(player => {
            player.onScreenDisplay.setActionBar({rawtext: [{text: `§c`}, {translate: 'nv_me.mech.no_upgrade'}]});
        });
    };
});

mc.world.afterEvents.playerSpawn.subscribe(({player}) => {
    if (player.hasTag('nv_me:in_mech')) {
        player.playAnimation('animation.player.attack.positions', {nextState: 'none', blendOutTime: 0,  stopExpression: `return !q.is_riding;`});
        player.removeTag('nv_me:in_mech');
    };
});

function relativeLocation(rotation, location) {
    const yaw = ((rotation.y + 180) / 180) * Math.PI;
    const rotatedX = location.x * Math.cos(yaw) - location.z * Math.sin(yaw);
    const rotatedZ = location.x * Math.sin(yaw) + location.z * Math.cos(yaw);
    return { x: rotatedX, y: location?.y ?? 0, z: rotatedZ };
};

function mechDisplay(fuel) {
    const totalBars = 50;
    const filledBars = Math.round((fuel / 100) * totalBars);
    const emptyBars = totalBars - filledBars;
    const filledText = "§e" + "|".repeat(filledBars);
    const emptyText = "§r" + "|".repeat(emptyBars);
    return filledText + emptyText;
};

function removeItem(player, searchId, amount) {
    const playerInv = player.getComponent('minecraft:inventory').container;
    for (let slot = 0; slot < playerInv.size; slot++) {
        const itemSearched = playerInv.getItem(slot);
        if (itemSearched?.typeId == searchId) {
            if (itemSearched.amount < amount) return;
            const replacementItem = new mc.ItemStack(itemSearched?.typeId, itemSearched.amount > amount ?  itemSearched.amount-amount : 1);
            if (amount) playerInv.setItem(slot, itemSearched.amount > amount ? replacementItem : undefined);
            return true;
        };
    };
};