import * as mc from "@minecraft/server"
import * as mcui from "@minecraft/server-ui"

mc.world.afterEvents.playerSpawn.subscribe(data => {
    if (data.initialSpawn && !data.player.hasTag('nv_me:guidebook_initial')) {
        data.player.addTag('nv_me:guidebook_initial');
        data.player.dimension.spawnItem(new mc.ItemStack('nv_me:mech_guidebook'), data.player.location);
    }
})


const guideConfig = {

};

mc.world.beforeEvents.itemUse.subscribe(event => {
    const item = event.itemStack;
    const player = event.source;
    if (item?.typeId == 'nv_me:mech_guidebook') {
        mc.system.runTimeout(() => guidebookMain(player));
    };
});

function guidebookMain(player) {
    const guideMain = new mcui.ActionFormData()
    .title('guide.main.title')
    .body('%guide.main.body');
    guideMain.button(`guide.standard.title`, `textures/nv_me/common/guidebook/standard_icon`);
    guideMain.button(`guide.mining.title`, `textures/nv_me/common/guidebook/mining_icon`);
    guideMain.button(`guide.jump.title`, `textures/nv_me/common/guidebook/jump_icon`);
    guideMain.button(`guide.battle.title`, `textures/nv_me/common/guidebook/battle_icon`);
    guideMain.button(`guide.fire.title`, `textures/nv_me/common/guidebook/fire_icon`);
    guideMain.button(`guide.upgrades.title`, `textures/nv_me/common/items/skill_upgrade_lv4`);
    guideMain.button(`guide.other.title`, `textures/nv_me/common/guidebook/other_info`);
    guideMain.show(player)?.then(form => {
        if (form?.canceled) return;
        if (form.selection == 0) {
            const uiForm = new mcui.ActionFormData()
            uiForm.title('guide.standard.title')
            uiForm.body('%guide.standard.body')
            uiForm.button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button')
            uiForm.show(player)?.then((form)=>{
                if (!form?.canceled) {
                    if (form.selection == 0) {
                        guidebookMain(player);
                    };
                };
            });
        };
        if (form.selection == 1) {
            const uiForm = new mcui.ActionFormData()
            uiForm.title('guide.mining.title')
            uiForm.body('%guide.mining.body')
            uiForm.button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button')
            uiForm.show(player)?.then((form)=>{
                if (!form?.canceled) {
                    if (form.selection == 0) {
                        guidebookMain(player);
                    };
                };
            });
        };
        if (form.selection == 2) {
            const uiForm = new mcui.ActionFormData()
            uiForm.title('guide.jump.title')
            uiForm.body('%guide.jump.body')
            uiForm.button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button')
            uiForm.show(player)?.then((form)=>{
                if (!form?.canceled) {
                    if (form.selection == 0) {
                        guidebookMain(player);
                    };
                };
            });
        };
        if (form.selection == 3) {
            const uiForm = new mcui.ActionFormData()
            uiForm.title('guide.battle.title')
            uiForm.body('%guide.battle.body')
            uiForm.button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button')
            uiForm.show(player)?.then((form)=>{
                if (!form?.canceled) {
                    if (form.selection == 0) {
                        guidebookMain(player);
                    };
                };
            });
        };
        if (form.selection == 4) {
            const uiForm = new mcui.ActionFormData()
            uiForm.title('guide.fire.title')
            uiForm.body('%guide.fire.body')
            uiForm.button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button')
            uiForm.show(player)?.then((form)=>{
                if (!form?.canceled) {
                    if (form.selection == 0) {
                        guidebookMain(player);
                    };
                };
            });
        };
        if (form.selection == 5) {
            const uiForm = new mcui.ActionFormData()
            uiForm.title('guide.upgrades.title')
            uiForm.body('%guide.upgrades.body')
            uiForm.button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button')
            uiForm.show(player)?.then((form)=>{
                if (!form?.canceled) {
                    if (form.selection == 0) {
                        guidebookMain(player);
                    };
                };
            });
        };
        if (form.selection == 6) {
            const uiForm = new mcui.ActionFormData()
            uiForm.title('guide.other.title')
            uiForm.body('%guide.other.body')
            uiForm.button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button')
            uiForm.show(player)?.then((form)=>{
                if (!form?.canceled) {
                    if (form.selection == 0) {
                        guidebookMain(player);
                    };
                };
            });
        };
    });
};

function categoryMenu(player, category) {
    const categoryForm = new mcui.ActionFormData()
        .title(`guide.${category}.title`)
        .body(`%guide.${category}.body`);
    
    guideConfig[category].forEach((item, index) => {
        categoryForm.button(`%guide.${category}.${item}`, `textures/nv_me/common/guidebook/${category}/${item}`);
    });
    
    categoryForm.button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button');
    
    categoryForm.show(player)?.then(form => {
        if (!form?.canceled) {
            if (form.selection < guideConfig[category].length) {
                itemDescription(player, category, guideConfig[category][form.selection]);
            } else
            {
                guidebookMain(player)
            }
        } else {
            guidebookMain(player);
        }
    });
}

function itemDescription(player, category, item) {
    const itemForm = new mcui.ActionFormData()
        .title(`guide.${category}.${item}`)
        .body(`%guide.${item}.description`)
        .button('%guide.main.return', 'textures/nv_me/common/guidebook/return_button');
    
    itemForm.show(player)?.then(form => {
        if (!form?.canceled) {
            categoryMenu(player, category);
        } else {
            guidebookMain(player);
        }
    });
}
