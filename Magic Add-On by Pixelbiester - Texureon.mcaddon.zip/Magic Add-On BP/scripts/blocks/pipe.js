import * as mc from "@minecraft/server";

export class pipeManager {
    static beforeplace(data) {
        const block = data.block;

        const north = block.north();
        const east = block.east();
        const south = block.south();
        const west = block.west();
        const top = block.above();
        const bottom = block.below();

        let northConnects = (north.hasTag("pb_scraft_mana_network"));
        let eastConnects = (east.hasTag("pb_scraft_mana_network"));
        let southConnects = (south.hasTag("pb_scraft_mana_network"));
        let westConnects = (west.hasTag("pb_scraft_mana_network"));
        let topConnects = (top.hasTag("pb_scraft_mana_network"));
        let bottomConnects = (bottom.hasTag("pb_scraft_mana_network"));

        if (northConnects) north.setPermutation(north.permutation.withState('pb_scraft:pipe_south', 1));
        if (eastConnects) east.setPermutation(east.permutation.withState('pb_scraft:pipe_west', 1));
        if (southConnects) south.setPermutation(south.permutation.withState('pb_scraft:pipe_north', 1));
        if (westConnects) west.setPermutation(west.permutation.withState('pb_scraft:pipe_east', 1));
        if (topConnects && top.hasTag("pb_scraft_pipe")) top.setPermutation(top.permutation.withState('pb_scraft:pipe_bottom', 1));
        if (bottomConnects && bottom.hasTag("pb_scraft_pipe")) bottom.setPermutation(bottom.permutation.withState('pb_scraft:pipe_top', 1));

        let network_range = 0;

        data.permutationToPlace = mc.BlockPermutation.resolve(data.permutationToPlace.type.id, {
            'pb_scraft:network_range': network_range,
            'pb_scraft:pipe_north': northConnects ? 1 : 0,
            'pb_scraft:pipe_south': southConnects ? 1 : 0,
            'pb_scraft:pipe_east': eastConnects ? 1 : 0,
            'pb_scraft:pipe_west': westConnects ? 1 : 0,
            'pb_scraft:pipe_top': topConnects ? 1 : 0,
            'pb_scraft:pipe_bottom': bottomConnects ? 1 : 0,
        });

    }

    static destroy(data) {

        const northConnects = data.destroyedBlockPermutation.getState("pb_scraft:pipe_north");
        const eastConnects = data.destroyedBlockPermutation.getState("pb_scraft:pipe_east");
        const southConnects = data.destroyedBlockPermutation.getState("pb_scraft:pipe_south");
        const westConnects = data.destroyedBlockPermutation.getState("pb_scraft:pipe_west");
        const topConnects = data.destroyedBlockPermutation.getState("pb_scraft:pipe_top");
        const bottomConnects = data.destroyedBlockPermutation.getState("pb_scraft:pipe_bottom");

        const block = data.block;
        const north = block.north();
        const east = block.east();
        const south = block.south();
        const west = block.west();
        const top = block.above();
        const bottom = block.below();

        try {
            if (northConnects) north.setPermutation(north.permutation.withState('pb_scraft:pipe_south', 0));
            if (eastConnects) east.setPermutation(east.permutation.withState('pb_scraft:pipe_west', 0));
            if (southConnects) south.setPermutation(south.permutation.withState('pb_scraft:pipe_north', 0));
            if (westConnects) west.setPermutation(west.permutation.withState('pb_scraft:pipe_east', 0));
        } catch (error) {

        }

        if (topConnects && top.hasTag("pb_scraft_pipe")) top.setPermutation(top.permutation.withState('pb_scraft:pipe_bottom', 0));
        if (bottomConnects && bottom.hasTag("pb_scraft_pipe")) bottom.setPermutation(bottom.permutation.withState('pb_scraft:pipe_top', 0));
    }

    //recursively check network blocks to make range go up
    static checkNetworkBlock(block, network_range) {
        //if range is minimum no point in checking further
        if (network_range <= 1) return;

        const permutation = block.permutation;
        const north = block.north();
        const east = block.east();
        const south = block.south();
        const west = block.west();
        const top = block.above();
        const bottom = block.below();

        const northConnects = permutation.getState("pb_scraft:pipe_north");
        const eastConnects = permutation.getState("pb_scraft:pipe_east");
        const southConnects = permutation.getState("pb_scraft:pipe_south");
        const westConnects = permutation.getState("pb_scraft:pipe_west");
        const topConnects = permutation.getState("pb_scraft:pipe_top");
        const bottomConnects = permutation.getState("pb_scraft:pipe_bottom");

        if (northConnects && north.permutation.getState("pb_scraft:network_range") < network_range) {
            north.setPermutation(north.permutation.withState('pb_scraft:network_range', network_range - 1));
            this.checkNetworkBlock(north, network_range - 1);
        }
        if (eastConnects && east.permutation.getState("pb_scraft:network_range") < network_range) {
            east.setPermutation(east.permutation.withState('pb_scraft:network_range', network_range - 1));
            this.checkNetworkBlock(east, network_range - 1);
        }
        if (southConnects && south.permutation.getState("pb_scraft:network_range") < network_range) {
            south.setPermutation(south.permutation.withState('pb_scraft:network_range', network_range - 1));
            this.checkNetworkBlock(south, network_range - 1);
        }
        if (westConnects && west.permutation.getState("pb_scraft:network_range") < network_range) {
            west.setPermutation(west.permutation.withState('pb_scraft:network_range', network_range - 1));
            this.checkNetworkBlock(west, network_range - 1);
        }
        if (topConnects && top.permutation.getState("pb_scraft:network_range") < network_range) {
            top.setPermutation(top.permutation.withState('pb_scraft:network_range', network_range - 1));
            this.checkNetworkBlock(top, network_range - 1);
        }
        if (bottomConnects && bottom.permutation.getState("pb_scraft:network_range") < network_range) {
            bottom.setPermutation(bottom.permutation.withState('pb_scraft:network_range', network_range - 1));
            this.checkNetworkBlock(bottom, network_range - 1);
        }
    }

    //cut network, set range to 0
    static cutNetworkBlocks(block) {

        const permutation = block.permutation;
        const network_range = block.permutation.getState("pb_scraft:network_range");
        const north = block.north();
        const east = block.east();
        const south = block.south();
        const west = block.west();
        const top = block.above();
        const bottom = block.below();

        const northConnects = permutation.getState("pb_scraft:pipe_north");
        const eastConnects = permutation.getState("pb_scraft:pipe_east");
        const southConnects = permutation.getState("pb_scraft:pipe_south");
        const westConnects = permutation.getState("pb_scraft:pipe_west");
        const topConnects = permutation.getState("pb_scraft:pipe_top");
        const bottomConnects = permutation.getState("pb_scraft:pipe_bottom");

        if (northConnects && north.permutation.getState("pb_scraft:network_range") < network_range) this.cutNetworkBlocks(north);
        if (eastConnects && east.permutation.getState("pb_scraft:network_range") < network_range) this.cutNetworkBlocks(east);
        if (southConnects && south.permutation.getState("pb_scraft:network_range") < network_range) this.cutNetworkBlocks(south);
        if (westConnects && west.permutation.getState("pb_scraft:network_range") < network_range) this.cutNetworkBlocks(west);
        if (topConnects && top.permutation.getState("pb_scraft:network_range") < network_range) this.cutNetworkBlocks(top);
        if (bottomConnects && bottom.permutation.getState("pb_scraft:network_range") < network_range) this.cutNetworkBlocks(bottom);

        block.setPermutation(block.permutation.withState('pb_scraft:network_range', 0));
    }
}
