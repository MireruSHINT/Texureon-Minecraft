import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as lib from '../lib/lib';
import * as config from '../pb_scraft_config';
import * as altarconfig from '../pb_scraft_altar_config';
import * as manatank from "./mana_tank";
import * as mana_network from '../lib/mana_network';
import { getPedestalEntity } from "./arcane_pedestal";
import { beamBetweenLocations } from "../lib/beam_utils";
import * as item_assembler from "../lib/item_assembler";

export const GLYPHS = [
    {
        identifier: "pb_scraft:no_glyph",
        name: "No Glyph"
    },
    {
        identifier: "pb_scraft:glyph_accelerate",
        name: "Accelerate §6[- Cast Time]"
    },
    {
        identifier: "pb_scraft:glyph_alleviate",
        name: "Alleviate §6[- Manacost]"
    },
    {
        identifier: "pb_scraft:glyph_intensify",
        name: "Intensify §6[+ Damage]"
    }
]

export class arcaneAltarCreativeManager {

    static interact(data) {
        const block = data.block;
        const player = data.player;
        const location = block.location;

        conjureMenu(player, block);
    }
}


//special menus
function conjureMenu(player, block) {

    let form = new ui.ModalFormData();
    form.title("§u§lCreative Altar");

    let staffs = [];
    let spells = [];
    let glyphs = [];

    config.CAST_ITEM_LIST.forEach(element => {
        staffs.push(element.shortname);
    });
    config.SPELL_LIST.forEach(element => {
        spells.push(element.display_name);
    });

    GLYPHS.forEach(element => {
        glyphs.push(element.name);
    });


    form.dropdown("§lStaff Type:", staffs);
    form.dropdown("§lSpell:", spells);

    form.dropdown("§lGlyph Slot 1:", glyphs);
    form.dropdown("§lGlyph Slot 2:", glyphs);

    form.submitButton("Conjure!");

    form.show(player).then(result => {
        if (result.canceled) return;

        let item = new mc.ItemStack(config.CAST_ITEM_LIST[result.formValues[0]].identifier, 1);
        let itemdata = config.CAST_ITEM_LIST[result.formValues[0]];
        let spelldata = config.SPELL_LIST[result.formValues[1]]
        let g1 = GLYPHS[result.formValues[2]].identifier
        let g2 = GLYPHS[result.formValues[3]].identifier
        const resultItem = item_assembler.applySpell(item, itemdata, spelldata, g1, g2);
        player.dimension.playSound("pb_scraft.altar_item_creation", block.location);
        mc.world.getDimension(player.dimension.id).spawnParticle("pb_scraft:altar_clear", block.center());

        //spawn item
        const itementity = mc.world.getDimension(block.dimension.id).spawnItem(resultItem, block.above().center());
        itementity.clearVelocity();
        itementity.applyImpulse({ x: 0, y: 0.2, z: 0 });
    });
}