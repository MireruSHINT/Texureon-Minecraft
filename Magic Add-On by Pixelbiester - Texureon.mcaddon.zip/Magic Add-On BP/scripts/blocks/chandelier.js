import * as mc from "@minecraft/server";

const particle_coordinates = [
    { x: 0.375, y: 0.58, z: -0.375 },
    { x: 0.375, y: 0.58, z: 0.375 },
    { x: -0.375, y: 0.58, z: -0.375 },
    { x: -0.375, y: 0.58, z: 0.375 },

    { x: 0.188, y: 0.88, z: -0.188 },
    { x: 0.188, y: 0.88, z: 0.188 },
    { x: -0.188, y: 0.88, z: -0.188 },
    { x: -0.188, y: 0.88, z: 0.188 }
]

export class chandelierManager {
    static interact(data) {
        const block = data.block;
        const player = data.player;
        const location = block.location;

        const lit = data.block.permutation.getState("pb_scraft:lit");
        if (lit == 0) {
            const mainhand = player.getComponent(mc.EntityEquippableComponent.componentId).getEquipmentSlot(mc.EquipmentSlot.Mainhand);
            const heldItem = mainhand.getItem();
            if (heldItem == undefined) return;

            if (heldItem.typeId == "minecraft:flint_and_steel") {
                block.setPermutation(mc.BlockPermutation.resolve(block.type.id, { 'pb_scraft:lit': 1 }));
                this.playParticles(block);
            }
        }
        else {
            block.setPermutation(mc.BlockPermutation.resolve(block.type.id, { 'pb_scraft:lit': 0 }));
        }
    }

    static tick(data) {
        if (data.block.permutation.getState("pb_scraft:lit") == 0) return;
        this.playParticles(data.block);
    }

    static playParticles(block) {
        const location = block.bottomCenter();
        const dimension = block.dimension;

        particle_coordinates.forEach(element => {
            const target_location = { x: location.x + element.x, y: location.y + element.y, z: location.z + element.z }
            mc.world.getDimension(dimension.id).spawnParticle("minecraft:candle_flame_particle", target_location);
        });
    }
}
