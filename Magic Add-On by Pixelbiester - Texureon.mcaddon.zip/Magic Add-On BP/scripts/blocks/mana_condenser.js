import * as mc from "@minecraft/server";
import * as mana_network from '../lib/mana_network';
import * as lib from '../lib/lib';
import * as manatank from "./mana_tank";

const MANA_TRANSFER_PER_OPERATION = 2;

export class manaCondenserManager {
    static beforeplace(data) {
        data.permutationToPlace = mana_network.connectToPipes(data.block, data.permutationToPlace);
    }

    static destroy(data) {
        mana_network.disconnectFromPipes(data.block, data.destroyedBlockPermutation);
    }

    static tick(data) {
        const block = data.block;
        const fuel = data.block.permutation.getState("pb_scraft:fuel");

        if (fuel > 0) {
            const dimension = block.dimension;
            const location = block.bottomCenter();

            mc.world.getDimension(dimension.id).spawnParticle("pb_scraft:pink_smoke", location);

            const permutation = block.permutation;
            const north = block.north();
            const east = block.east();
            const south = block.south();
            const west = block.west();

            const northConnects = permutation.getState("pb_scraft:pipe_north");
            const eastConnects = permutation.getState("pb_scraft:pipe_east");
            const southConnects = permutation.getState("pb_scraft:pipe_south");
            const westConnects = permutation.getState("pb_scraft:pipe_west");

            const blockmap = new Map();
            blockmap.set(lib.locString(block.location), block);
            const network_range = 16;

            if (northConnects) mana_network.findTanks(north, blockmap, network_range);
            if (eastConnects) mana_network.findTanks(east, blockmap, network_range);
            if (southConnects) mana_network.findTanks(south, blockmap, network_range);
            if (westConnects) mana_network.findTanks(west, blockmap, network_range);

            
            for (let element of blockmap.values()) {

                if (element.type.id == "pb_scraft:mana_tank") {
                    if (manatank.addMana(element, MANA_TRANSFER_PER_OPERATION)) {
                        //try to push 2 mana per operation into nearest tank
                        dimension.playSound("random.potion.brewed", location);
                        block.setPermutation(block.permutation.withState('pb_scraft:fuel', fuel - MANA_TRANSFER_PER_OPERATION));
                        break;
                    }
                }
            }
                
        }
    }

    static interact(data) {
        const block = data.block;
        const dimension = block.dimension;
        const player = data.player;
        const location = block.bottomCenter();

        const fuel = data.block.permutation.getState("pb_scraft:fuel");

        if (fuel == 0) {
            const mainhand = player.getComponent(mc.EntityEquippableComponent.componentId).getEquipmentSlot(mc.EquipmentSlot.Mainhand);
            const heldItem = mainhand.getItem();
            if (heldItem == undefined) return;

            if (heldItem.typeId != "minecraft:amethyst_shard") {
                player.sendMessage("§u[Magic]§r Only Amethyst Shards can be condensed into Mana");
                return;
            }
            dimension.playSound("mob.blaze.shoot", location);

            //place item
            block.setPermutation(block.permutation.withState('pb_scraft:fuel', 10));
            mc.world.getDimension(dimension.id).spawnParticle("pb_scraft:pink_smoke", location);
            mc.world.getDimension(dimension.id).spawnParticle("pb_scraft:condenser_activate", location);

            if (player.getGameMode() == mc.GameMode.creative) return;
            mainhand.setItem(itemManager.reduceAmount(heldItem, 1));
            return;
        }
        else {
            player.sendMessage("§u[Magic]§r Condenser is busy ...");
            player.dimension.playSound("pb_scraft.spell_fail", location);
        }
    }
}