import * as mc from "@minecraft/server";

const particle_coordinates_eastwest = [
    { x: 0.0, y: 1.4, z: 0.0 },
    { x: 0.0, y: 1.2, z: 0.25 },
    { x: 0.0, y: 1.2, z: -0.25 }
]

const particle_coordinates_northsouth = [
    { x: 0.0, y: 1.4, z: 0.0 },
    { x: 0.25, y: 1.2, z: 0.0 },
    { x: -0.25, y: 1.2, z: 0.0 }
]

export class candelabrumManager {
    static interact(data) {
        const block = data.block;
        const player = data.player;
        const location = block.location;

        const lit = data.block.permutation.getState("pb_scraft:lit");
        if (lit == 0) {
            const mainhand = player.getComponent(mc.EntityEquippableComponent.componentId).getEquipmentSlot(mc.EquipmentSlot.Mainhand);
            const heldItem = mainhand.getItem();
            if (heldItem == undefined) return;

            if (heldItem.typeId == "minecraft:flint_and_steel") {
                block.setPermutation(mc.BlockPermutation.resolve(block.type.id, { "minecraft:cardinal_direction": block.permutation.getState("minecraft:cardinal_direction"), "pb_scraft:lit": 1 }));
                this.playParticles(block);
            }
        }
        else {
            block.setPermutation(mc.BlockPermutation.resolve(block.type.id, { "minecraft:cardinal_direction": block.permutation.getState("minecraft:cardinal_direction"), "pb_scraft:lit": 0 }));
        }
    }

    static tick(data) {
        if (data.block.permutation.getState("pb_scraft:lit") == 0) return;
        this.playParticles(data.block);
    }

    static playParticles(block) {
        const location = block.bottomCenter();
        const dimension = block.dimension;
        const cardinal = block.permutation.getState("minecraft:cardinal_direction");

        if (cardinal == "north" || cardinal == "south") {
            particle_coordinates_northsouth.forEach(element => {
                const target_location = { x: location.x + element.x, y: location.y + element.y, z: location.z + element.z }
                mc.world.getDimension(dimension.id).spawnParticle("minecraft:candle_flame_particle", target_location);
            });
        }
        else {
            particle_coordinates_eastwest.forEach(element => {
                const target_location = { x: location.x + element.x, y: location.y + element.y, z: location.z + element.z }
                mc.world.getDimension(dimension.id).spawnParticle("minecraft:candle_flame_particle", target_location);
            });
        }

    }
}
