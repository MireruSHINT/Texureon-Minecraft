import * as mc from "@minecraft/server"
import { pipeManager } from "./pipe";
import { manaTankManager } from "./mana_tank";
import { manaHarvesterManager } from "./mana_harvester";
import { arcanePedestalManager } from "./arcane_pedestal";
import { chandelierManager } from "./chandelier";
import { candelabrumManager } from "./candelabrum";
import { potManager } from "./pot";
import { arcaneAltarManager } from "./arcane_altar";
import { manaHarvesterTopManager } from "./mana_harvester_top";
import { arcaneAltarCreativeManager } from "./arcane_altar creative";
import { manaCondenserManager } from "./mana_condenser";

const blockComponents = [
    {
        id: "pb_scraft:pipe",
        code: {
            beforeOnPlayerPlace: (data) => {
                pipeManager.beforeplace(data)
            },
            onPlayerDestroy: (data) => {
                pipeManager.destroy(data)
            }
        }
    },
    {
        id: "pb_scraft:tank_block",
        code: {
            beforeOnPlayerPlace: (data) => {
                manaTankManager.beforeplace(data)
            }
        }
    },
    {
        id: "pb_scraft:mana_tank",
        code: {
            onPlayerDestroy: (data) => {
                manaTankManager.destroy(data)
            },
            onPlayerInteract: (data) => {
                manaTankManager.interact(data)
            },
            onTick: (data) => {
                manaTankManager.tick(data)
            }
        }
    },
    {
        id: "pb_scraft:mana_harvester",
        code: {
            onPlayerDestroy: (data) => {
                manaHarvesterManager.destroy(data)
            },
            beforeOnPlayerPlace: (data) => {
                manaHarvesterManager.beforeplace(data)
            },
            onTick: (data) => {
                manaHarvesterManager.tick(data)
            }
        }
    },
    {
        id: "pb_scraft:mana_harvester_top",
        code: {
            beforeOnPlayerPlace: (data) => {
                manaHarvesterTopManager.beforeplace(data)
            },
            onPlayerInteract: (data) => {
                manaHarvesterTopManager.interact(data)
            },
        }
    },
    {
        id: "pb_scraft:arcane_pedestal",
        code: {
            onPlayerInteract: (data) => {
                arcanePedestalManager.interact(data)
            },
            onPlayerDestroy: (data) => {
                arcanePedestalManager.destroy(data)
            }
        }
    },
    {
        id: "pb_scraft:arcane_altar",
        code: {
            onPlayerDestroy: (data) => {
                arcaneAltarManager.destroy(data)
            },
            beforeOnPlayerPlace: (data) => {
                arcaneAltarManager.beforeplace(data)
            },
            onPlayerInteract: (data) => {
                arcaneAltarManager.interact(data)
            },
            onTick: (data) => {
                arcaneAltarManager.tick(data)
            }
        }
    },
    {
        id: "pb_scraft:chandelier",
        code: {
            onPlayerInteract: (data) => {
                chandelierManager.interact(data)
            },
            onTick: (data) => {
                chandelierManager.tick(data)
            }
        }
    },
    {
        id: "pb_scraft:candelabrum",
        code: {
            onPlayerInteract: (data) => {
                candelabrumManager.interact(data)
            },
            onTick: (data) => {
                candelabrumManager.tick(data)
            }
        }
    },
    {
        id: "pb_scraft:pot",
        code: {
            onPlayerInteract: (data) => {
                potManager.interact(data)
            },
            onTick: (data) => {
                potManager.tick(data)
            }
        }
    },
    {
        id: "pb_scraft:creative_arcane_altar",
        code: {
            onPlayerInteract: (data) => {
                arcaneAltarCreativeManager.interact(data)
            }
        }
    },
    {
        id: "pb_scraft:mana_condenser",
        code: {
            onPlayerDestroy: (data) => {
                manaCondenserManager.destroy(data)
            },
            beforeOnPlayerPlace: (data) => {
                manaCondenserManager.beforeplace(data)
            },
            onPlayerInteract: (data) => {
                manaCondenserManager.interact(data)
            },
            onTick: (data) => {
                manaCondenserManager.tick(data)
            }
        }
    }
];

initBlockComponents();

let reload = 0;
function initBlockComponents() {
    mc.world.beforeEvents.worldInitialize.subscribe((data) => {
        //reload trick to still have reload capability with this and other add-ons
        reload = reload + 1;
        if (reload > 1) return;

        //register custom crops
        for (const comp of blockComponents) {
            data.blockComponentRegistry.registerCustomComponent(comp.id, comp.code);
        }
    });
}

export function hithere(){};