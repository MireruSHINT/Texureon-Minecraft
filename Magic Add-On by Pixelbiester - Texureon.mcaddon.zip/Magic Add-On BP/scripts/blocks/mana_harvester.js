import * as mc from "@minecraft/server";
import * as mana_network from '../lib/mana_network';
import * as lib from '../lib/lib';
import * as manatank from "./mana_tank";


const FLORA_RADIUS = 4;

export class manaHarvesterManager {
    static beforeplace(data) {
        data.permutationToPlace = mana_network.connectToPipes(data.block, data.permutationToPlace);
    }

    static destroy(data) {
        mana_network.disconnectFromPipes(data.block, data.destroyedBlockPermutation);
    }

    static tick(data) {
        const block = data.block;
        const location = block.center();
        const dimension = block.dimension;

        const fuel = block.permutation.getState("pb_scraft:fuel");

        let mana_amount = 0;

        //creative harvester
        if (block.type.id == "pb_scraft:creative_mana_harvester") {
            mana_amount += 4;
            mc.world.getDimension(dimension.id).spawnParticle("pb_scraft:harvester_generate", block.below().center());
        };

        //moonlight scope
        if (block.above().type.id == "pb_scraft:mana_harvester_scope") {
            const time = mc.world.getTimeOfDay();

            if (time > 12000 && time < 23000) {
                mana_amount += 1;
                mc.world.getDimension(dimension.id).spawnParticle("pb_scraft:harvester_generate", block.center());
            }
        };

        //flora scope
        if (block.above().type.id == "pb_scraft:mana_harvester_flora") {
            const location = { x: block.location.x - FLORA_RADIUS, y: block.location.y, z: block.location.z - FLORA_RADIUS };
            let flora_found = 0;

            for (let i = 0; i < FLORA_RADIUS * 2 + 1; i++) {
                for (let j = 0; j < FLORA_RADIUS * 2 + 1; j++) {
                    const florablock = dimension.getBlock({ x: location.x + i, y: location.y, z: location.z + j });

                    if (florablock?.hasTag("fertilize_area")) {
                        flora_found++;
                    }
                }
            };

            if (flora_found > 0) {
                mana_amount = 1;
                mc.world.getDimension(dimension.id).spawnParticle("pb_scraft:harvester_generate", block.center());
            }
        };

        //push generated mana into mana network
        if (mana_amount > 0) {

            const permutation = block.permutation;
            const north = block.north();
            const east = block.east();
            const south = block.south();
            const west = block.west();

            const northConnects = permutation.getState("pb_scraft:pipe_north");
            const eastConnects = permutation.getState("pb_scraft:pipe_east");
            const southConnects = permutation.getState("pb_scraft:pipe_south");
            const westConnects = permutation.getState("pb_scraft:pipe_west");

            const blockmap = new Map();
            blockmap.set(lib.locString(block.location), block);
            const network_range = 16;

            if (northConnects) mana_network.findTanks(north, blockmap, network_range);
            if (eastConnects) mana_network.findTanks(east, blockmap, network_range);
            if (southConnects) mana_network.findTanks(south, blockmap, network_range);
            if (westConnects) mana_network.findTanks(west, blockmap, network_range);

            for (let element of blockmap.values()) {

                if (element.type.id == "pb_scraft:mana_tank") {
                    if (manatank.addMana(element, mana_amount)) break; //try to push mana into nearest tank
                }
            }
        }
    }
}

function applyBlocksFromOrigin(origin, height) {
    let type = "pb_scraft:mana_harvester";

    for (let index = 0; index <= height; index++) {
        let multiblock = origin.above(index);

        if (index == 0) multiblock.setPermutation(mc.BlockPermutation.resolve(type, { "minecraft:cardinal_direction": origin.permutation.getState("minecraft:cardinal_direction"), 'pb_scraft:height': 0 }))
        if (index == 1) multiblock.setPermutation(mc.BlockPermutation.resolve(type, { "minecraft:cardinal_direction": origin.permutation.getState("minecraft:cardinal_direction"), 'pb_scraft:height': 1 }))

        lib.highlightBlock(multiblock);
    }
}