import * as mc from "@minecraft/server";
import * as altarconfig from '../pb_scraft_altar_config';
import { itemManager } from "../lib/lib";

export class arcanePedestalManager {
    static interact(data) {
        const block = data.block;
        const player = data.player;
        const location = block.location;



        const item_displayed = data.block.permutation.getState("pb_scraft:item_displayed");
        if (item_displayed == 0) {
            const mainhand = player.getComponent(mc.EntityEquippableComponent.componentId).getEquipmentSlot(mc.EquipmentSlot.Mainhand);
            const heldItem = mainhand.getItem();
            if (heldItem == undefined) return;

            if (!altarconfig.PEDESTAL_ITEMS.includes(heldItem.typeId)) {
                mc.world.sendMessage("§u[Magic]§r This item cannot be placed on here");
                return;
            }
            player.dimension.playSound("pb_scraft.altar_item_placed", location);

            const display_entity = mc.world.getDimension(player.dimension.id).spawnEntity("pb_scraft:display", { x: location.x + 0.5, y: location.y + 1, z: location.z + 0.5 });
            const display_location = display_entity.location;

            //store item in display inventory
            const inventory = display_entity.getComponent('minecraft:inventory').container;
            const addItem = heldItem.clone();
            addItem.amount = 1;
            inventory.addItem(addItem);

            display_entity.setDynamicProperty("pb_scraft_id", heldItem.typeId);

            //set glyph data for spell orbs
            const spell_identifier = heldItem.getDynamicProperty("pb_scraft_spell");
            const glyph_1 = heldItem.getDynamicProperty("pb_scraft_glyph_1");
            const glyph_2 = heldItem.getDynamicProperty("pb_scraft_glyph_2");

            if(spell_identifier != undefined) display_entity.setDynamicProperty("pb_scraft_spell", spell_identifier);
            if(glyph_1 != undefined) display_entity.setDynamicProperty("pb_scraft_glyph_1", glyph_1);
            if(glyph_2 != undefined) display_entity.setDynamicProperty("pb_scraft_glyph_2", glyph_2);

            //place item
            mc.world.getDimension(player.dimension.id).runCommandAsync("/execute positioned " + display_location.x + " " + display_location.y + " " + display_location.z + " run /replaceitem entity @e[type=pb_scraft:display,r=0.2]  slot.weapon.mainhand 1 " + heldItem.typeId);
            block.setPermutation(block.permutation.withState('pb_scraft:item_displayed', 1));

            if (player.getGameMode() == mc.GameMode.creative) return;
            mainhand.setItem(itemManager.reduceAmount(heldItem, 1));
            return;
        }
        else {
            const display_entity = getPedestalEntity(block);
            if (display_entity != undefined) {

                const inventory = display_entity.getComponent('minecraft:inventory').container;
                let returnItem = inventory.getItem(0);

                mc.world.getDimension(player.dimension.id).spawnItem(returnItem, { x: location.x + 0.5, y: location.y + 1.1, z: location.z + 0.5 });
                display_entity.remove();
            };
            block.setPermutation(block.permutation.withState('pb_scraft:item_displayed', 0));
        }
    }

    static destroy(data) {
        const block = data.block;
        const player = data.player;
        const location = block.location;

        const display_entity = getPedestalEntity(block);
        if(display_entity != undefined)
        {
            const inventory = display_entity.getComponent('minecraft:inventory').container;
            let returnItem = inventory.getItem(0);
            mc.world.getDimension(player.dimension.id).spawnItem(returnItem, { x: location.x + 0.5, y: location.y + 1.1, z: location.z + 0.5 });
            display_entity.remove();
        }
        
    }
}

export function getPedestalEntity(block) {
    const location = block.location;
    return mc.world.getDimension(block.dimension.id).getEntities({ location: { x: location.x + 0.5, y: location.y + 1, z: location.z + 0.5 }, families: ["pb_scraft_display"], maxDistance: 1 })[0];
}

