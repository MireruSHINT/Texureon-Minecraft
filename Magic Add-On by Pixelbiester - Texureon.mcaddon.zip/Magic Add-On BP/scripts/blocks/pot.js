import * as mc from "@minecraft/server";

const particle_coordinates = [
    { x: 0.0, y: 0.9, z: 0.0 }
]

export class potManager {
    static interact(data) {
        const block = data.block;

        const lit = data.block.permutation.getState("pb_scraft:lit");
        if (lit == 0) {
            block.setPermutation(mc.BlockPermutation.resolve(block.type.id, { "minecraft:cardinal_direction": block.permutation.getState("minecraft:cardinal_direction"), "pb_scraft:lit": 1 }));
            this.playParticles(block);
        }
        else {
            block.setPermutation(mc.BlockPermutation.resolve(block.type.id, { "minecraft:cardinal_direction": block.permutation.getState("minecraft:cardinal_direction"), "pb_scraft:lit": 0 }));
        }
    }

    static tick(data) {
        if (data.block.permutation.getState("pb_scraft:lit") == 0) return;
        this.playParticles(data.block);
    }

    static playParticles(block) {
        const location = block.bottomCenter();
        const dimension = block.dimension;

        particle_coordinates.forEach(element => {
            const target_location = { x: location.x + element.x, y: location.y + element.y, z: location.z + element.z }
            mc.world.getDimension(dimension.id).spawnParticle("pb_scraft:pot_ambient", target_location);
        });
    }
}
