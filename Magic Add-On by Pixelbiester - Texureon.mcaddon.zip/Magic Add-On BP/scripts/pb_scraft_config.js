import * as mc from '@minecraft/server';

export const VERSION = "1.0.0";

export var SCALING = 1.0;
export var MANA_REG = 5;
export var PVP = {
    enabled: false,
    scaling: 1.0
}

export function updateGlobalSettings() {
    MANA_REG = mc.world.scoreboard.getObjective("pb_scraft_settings").getScore("MANA_REG");
    SCALING = mc.world.scoreboard.getObjective("pb_scraft_settings").getScore("DMG_SCALING") / 100;
    PVP.scaling = mc.world.scoreboard.getObjective("pb_scraft_settings").getScore("PVP_SCALING") / 100;
    if (PVP.scaling > 0) PVP.enabled = true; else PVP.enabled = false;
}

export const CAST_ITEM_LIST = [
    {
        identifier: "pb_scraft:fire_staff_1",
        name: "§r§cFlamecore Staff\n§6§l[§c><§6]§r§f Lv.1 Fire Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§cFire Staff Lv.1",
        element: "fire",
        spellPower: 0,
        spellSlots: 1
    },
    {
        identifier: "pb_scraft:fire_staff_2",
        name: "§r§cPhoenix Staff\n§6§l[§c><§6]§r§f Lv.2 Fire Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§cFire Staff Lv.2",
        element: "fire",
        spellPower: 5,
        spellSlots: 2
    },
    {
        identifier: "pb_scraft:fire_staff_3",
        name: "§r§cSun Staff\n§6§l[§c><§6]§r§f Lv.3 Fire Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§cFire Staff Lv.3",
        element: "fire",
        spellPower: 10,
        spellSlots: 3
    },
    {
        identifier: "pb_scraft:ice_staff_1",
        name: "§r§bFrostcore Staff\n§6§l[§b<>§6]§r§f Lv.1 Frost Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§bIce Staff Lv.1",
        element: "ice",
        spellPower: 0,
        spellSlots: 1
    },
    {
        identifier: "pb_scraft:ice_staff_2",
        name: "§r§bZephyr Staff\n§6§l[§b<>§6]§r§f Lv.2 Frost Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§bIce Staff Lv.2",
        element: "ice",
        spellPower: 5,
        spellSlots: 2
    },
    {
        identifier: "pb_scraft:ice_staff_3",
        name: "§r§bVortex Staff\n§6§l[§b<>§6]§r§f Lv.3 Frost Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§bIce Staff Lv.3",
        element: "ice",
        spellPower: 10,
        spellSlots: 3
    },
    {
        identifier: "pb_scraft:air_staff_1",
        name: "§r§eStormcore Staff\n§6§l[§e)(§6]§r§f Lv.1 Storm Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§eAir Staff Lv.1",
        element: "air",
        spellPower: 0,
        spellSlots: 1
    },
    {
        identifier: "pb_scraft:air_staff_2",
        name: "§r§eSerpent Staff\n§6§l[§e)(§6]§r§f Lv.2 Storm Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§eAir Staff Lv.2",
        element: "air",
        spellPower: 5,
        spellSlots: 2
    },
    {
        identifier: "pb_scraft:air_staff_3",
        name: "§r§eTempest Staff\n§6§l[§e)(§6]§r§f Lv.3 Storm Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§eAir Staff Lv.3",
        element: "air",
        spellPower: 10,
        spellSlots: 3
    },
    {
        identifier: "pb_scraft:earth_staff_1",
        name: "§r§aTerracore Staff\n§6§l[§a()§6]§r§f Lv.1 Earth Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§aEarth Staff Lv.1",
        element: "earth",
        spellPower: 0,
        spellSlots: 1
    },
    {
        identifier: "pb_scraft:earth_staff_2",
        name: "§r§aCrystal Staff\n§6§l[§a()§6]§r§f Lv.2 Earth Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§aEarth Staff Lv.2",
        element: "earth",
        spellPower: 5,
        spellSlots: 2
    },
    {
        identifier: "pb_scraft:earth_staff_3",
        name: "§r§aVerdant Gem Staff\n§6§l[§a()§6]§r§f Lv.3 Earth Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§aEarth Staff Lv.3",
        element: "earth",
        spellPower: 10,
        spellSlots: 3
    },
    {
        identifier: "pb_scraft:twilight_staff_1",
        name: "§r§dDawncore Staff\n§6§l[§d{}§6]§r§f Lv.1 Twilight Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§dTwilight Staff Lv.1",
        element: "twilight",
        spellPower: 0,
        spellSlots: 1
    },
    {
        identifier: "pb_scraft:twilight_staff_2",
        name: "§r§de§Eclipse Staff\n§6§l[§d{}§6]§r§f Lv.2 Twilight Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§dTwilight Staff Lv.2",
        element: "twilight",
        spellPower: 5,
        spellSlots: 2
    },
    {
        identifier: "pb_scraft:twilight_staff_3",
        name: "§r§dNemesis Staff\n§6§l[§d{}§6]§r§f Lv.3 Twilight Staff\nSPELLINFO\n§o§uMagic",
        shortname: "§dTwilight Staff Lv.3",
        element: "twilight",
        spellPower: 10,
        spellSlots: 3
    }
]

export const SHOW_MANA_ITEMS = [
    "pb_scraft:air_staff_1",
    "pb_scraft:air_staff_2",
    "pb_scraft:air_staff_3",

    "pb_scraft:fire_staff_1",
    "pb_scraft:fire_staff_2",
    "pb_scraft:fire_staff_3",

    "pb_scraft:earth_staff_1",
    "pb_scraft:earth_staff_2",
    "pb_scraft:earth_staff_3",

    "pb_scraft:ice_staff_1",
    "pb_scraft:ice_staff_2",
    "pb_scraft:ice_staff_3",

    "pb_scraft:twilight_staff_1",
    "pb_scraft:twilight_staff_2",
    "pb_scraft:twilight_staff_3"
]

export const SPELL_LIST = [
    {
        identifier: "pb_scraft:fireball",
        display_name: "Spell: §cFireball",
        element: "fire",
        manacost: 15,
        castTime: 12,
        cooldown: 0,
        soundCast: "pb_scraft.fireball_cast",
        projectile: "pb_scraft:projectile_fireball",
        type: "projectile"
    },
    {
        identifier: "pb_scraft:pyroball",
        display_name: "Spell: §cPyroball",
        element: "fire",
        manacost: 40,
        castTime: 45,
        cooldown: 0,
        soundCast: "pb_scraft.pyroball_cast",
        projectile: "pb_scraft:projectile_pyroball",
        type: "projectile"
    },
    {
        identifier: "pb_scraft:firebolt",
        display_name: "Spell: §cFirebolt",
        element: "fire",
        manacost: 5,
        castTime: 25,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.firebolt_cast",
        projectile: "pb_scraft:projectile_firebolt",
        type: "channel"
    },
    {
        identifier: "pb_scraft:tornado_fire",
        display_name: "Spell: §cFire Tornado",
        element: "fire",
        manacost: 25,
        castTime: 18,
        damageTick: 8,
        cooldown: 0,
        particlesCast: [
            "pb_scraft:cast_circle_fire",
            "pb_scraft:cast_embers_fire_forward"
        ],
        soundCast: "pb_scraft.tornado_cast",
        projectile: "pb_scraft:effect_tornado",
        type: "raycast"
    },
    {
        identifier: "pb_scraft:comet",
        display_name: "Spell: §cComet",
        element: "fire",
        manacost: 20,
        castTime: 30,
        damageTick: 10,
        cooldown: 0,
        particlesCast: [],
        soundCast: "pb_scraft.comet_cast",
        projectile: "pb_scraft:effect_fireorb",
        type: "raycast"
    },
    {
        identifier: "pb_scraft:aura_fire",
        display_name: "Spell: §cFire Aura",
        element: "fire",
        manacost: 65,
        castTime: 50,
        damageTick: 12,
        cooldown: 0,
        ignite: 10,
        soundCast: "pb_scraft.fiery_spin_cast",
        projectile: "pb_scraft:effect_aura_fire",
        particlesSetup: [
            "pb_scraft:aura_fire_rune"
        ],
        particlesTarget: [
            "pb_scraft:aura_fire",
            "pb_scraft:aura_fire_slash",
            "pb_scraft:aura_fire_embers",
        ],
        type: "aura"
    },
    //ICE
    {
        identifier: "pb_scraft:freeze",
        display_name: "Spell: §bFreeze",
        element: "ice",
        manacost: 5,
        castTime: 25,
        damageTick: 5,
        cooldown: 0,
        soundCast: "pb_scraft.freeze_cast",
        projectile: "pb_scraft:cone_freeze",
        type: "channel"
    },
    {
        identifier: "pb_scraft:ice_spike",
        display_name: "Spell: §bIce Spike",
        element: "ice",
        manacost: 8,
        castTime: 30,
        damageTick: 12,
        cooldown: 0,
        soundCast: "pb_scraft.ice_spike_cast",
        projectile: "pb_scraft:projectile_ice_spike",
        type: "channel"
    },
    {
        identifier: "pb_scraft:ice_pillar",
        display_name: "Spell: §bIce Pillars",
        element: "ice",
        manacost: 25,
        castTime: 20,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.ice_pillars_cast",
        projectile: "pb_scraft:effect_ice_spike",
        amount: 5,
        radius: 2,
        particlesTarget: [
            "pb_scraft:ice_summoning_rune",
        ],
        shape: "circle",
        type: "ground"
    },
    {
        identifier: "pb_scraft:ice_wall",
        display_name: "Spell: §bIce Wall",
        element: "ice",
        manacost: 15,
        castTime: 20,
        damageTick: 12,
        cooldown: 0,
        soundCast: "pb_scraft.ice_wall_cast",
        projectile: "pb_scraft:effect_ice_wall",
        amount: 10,
        radius: 3,
        particlesTarget: [],
        shape: "wall",
        type: "ground"
    },
    {
        identifier: "pb_scraft:aura_frost",
        display_name: "Spell: §bFrost Aura",
        element: "ice",
        manacost: 50,
        castTime: 40,
        damageTick: 7,
        cooldown: 0,
        soundCast: "pb_scraft.frost_aura_cast",
        projectile: "pb_scraft:effect_aura_frost",
        particlesSetup: [
            "pb_scraft:aura_frost_rune"
        ],
        particlesTarget: [
            "pb_scraft:aura_frost_snowflakes_2",
            "pb_scraft:aura_frost_windstripes",
        ],
        type: "aura"
    },
    {
        identifier: "pb_scraft:aura_heal",
        display_name: "Spell: §bHealing Aura",
        element: "ice",
        manacost: 35,
        castTime: 15,
        damageTick: 10,
        cooldown: 0,
        soundCast: "pb_scraft.healing_aura_cast",
        projectile: "pb_scraft:effect_aura_heal",
        particlesSetup: [
            "pb_scraft:aura_frost_rune"
        ],
        particlesTarget: [
            "pb_scraft:aura_bubbles",
            "pb_scraft:aura_bubbles_embers",
        ],
        type: "aura"
    },
    {
        identifier: "pb_scraft:area_heal",
        display_name: "Spell: §bArea Heal",
        element: "ice",
        manacost: 10,
        castTime: 10,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.cast_loop_4",
        projectile: "pb_scraft:area_heal",
        amount: 8,
        radius: 3,
        particlesCast: [],
        particlesTarget: [],
        shape: "heal",
        type: "ground"
    },
    //STORM
    {
        identifier: "pb_scraft:lightning",
        display_name: "Spell: §eLightning",
        element: "air",
        manacost: 15,
        castTime: 10,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.lightning_strike_cast",
        projectile: "pb_scraft:lightning",
        range: 32,
        amount: 8,
        radius: 3,
        particlesCast: [],
        particlesTarget: [],
        shape: "instant",
        type: "ground"
    },
    {
        identifier: "pb_scraft:tornado_air",
        display_name: "Spell: §eTornado",
        element: "air",
        manacost: 20,
        castTime: 30,
        damageTick: 10,
        cooldown: 0,
        particlesCast: [],
        soundCast: "pb_scraft.air_tornado_cast",
        projectile: "pb_scraft:effect_tornado_air",
        type: "raycast"
    },
    {
        identifier: "pb_scraft:windsickle",
        display_name: "Spell: §eWind Sickle",
        element: "air",
        manacost: 15,
        castTime: 15,
        cooldown: 0,
        soundCast: "pb_scraft.pyroball_cast",
        projectile: "pb_scraft:projectile_windsickle",
        type: "projectile"
    },
    {
        identifier: "pb_scraft:flash",
        display_name: "Spell: §eFlash",
        element: "air",
        manacost: 25,
        castTime: 15,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.lightning_strike_cast",
        projectile: "pb_scraft:flash",
        amount: 8,
        radius: 3,
        particlesCast: [],
        particlesTarget: [],
        shape: "teleport",
        type: "ground"
    },
    {
        identifier: "pb_scraft:upwind",
        display_name: "Spell: §eUpwind",
        element: "air",
        manacost: 15,
        castTime: 3,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.twilight_explosion_cast",
        projectile: "pb_scraft:upwind",
        amount: 8,
        radius: 3,
        particlesCast: [],
        particlesTarget: [],
        shape: "jump",
        type: "ground"
    },
    //EARTH
    {
        identifier: "pb_scraft:rock_sling",
        display_name: "Spell: §aRock Sling",
        element: "earth",
        manacost: 15,
        castTime: 18,
        cooldown: 0,
        soundCast: "pb_scraft.rock_spell_cast",
        projectile: "pb_scraft:projectile_stone",
        type: "projectile"
    },
    {
        identifier: "pb_scraft:earthquake",
        display_name: "Spell: §aEarthquake",
        element: "earth",
        manacost: 25,
        castTime: 25,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.rock_spell_cast",
        projectile: "pb_scraft:effect_earthquake",
        particlesTarget: [],
        type: "raycast"
    },
    //TWILIGHT
    {
        identifier: "pb_scraft:twilight_explosion",
        display_name: "Spell: §dTwilight Explosion",
        element: "twilight",
        manacost: 12,
        castTime: 5,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.twilight_explosion_cast",
        projectile: "pb_scraft:twilight_explosion",
        amount: 8,
        particlesCast: [],
        particlesTarget: [],
        shape: "self",
        type: "ground"
    },
    {
        identifier: "pb_scraft:light_arc",
        display_name: "Spell: §dLight Arc",
        element: "twilight",
        manacost: 4,
        castTime: 30,
        damageTick: 3,
        cooldown: 0,
        soundCast:  "pb_scraft.twilight_explosion_cast",
        projectile: "pb_scraft:light_arc",
        type: "channel"
    },
    {
        identifier: "pb_scraft:moonbeam",
        display_name: "Spell: §dMoonbeam",
        element: "twilight",
        manacost: 35,
        castTime: 35,
        damageTick: 8,
        cooldown: 0,
        soundCast: "pb_scraft.twilight_explosion_cast",
        projectile: "pb_scraft:effect_moonbeam",
        amount: 24,
        radius: 3,
        particlesTarget: [],
        shape: "circle",
        type: "ground"
    }

    //additional spells

    /*
    {
        identifier: "pb_scraft:gnaw",
        display_name: "Spell: §dGnaw",
        element: "twilight",
        manacost: 30,
        castTime: 30,
        damageTick: 10,
        cooldown: 0,
        particlesCast: [],
        soundCast: "pb_scraft.pyroball_cast",
        projectile: "pb_scraft:projectile_gnaw",
        type: "raycast"
    },
    */
]

export const EFFECT_LIST = [
    {
        identifier: "pb_scraft:projectile_fireball",
        soundLaunch: "pb_scraft.fireball_launch",
        soundImpact: "pb_scraft.fireball_impact",
        particle_impact: [
            "pb_scraft:darkfire_explosion_medium",
            "pb_scraft:darkfireball_impact_ember",
            "pb_scraft:darkfireball_sparks_small"
        ],
        particle_tick: [
            "pb_scraft:darkfireball_spherical",
            "pb_scraft:darkfireball_embers",
            "pb_scraft:darkfireball_trail_instant"
        ],
        damage: 8,
        radius: 3,
        impulse: 2.0,
        spellpower: 0.3,
        knockback_horizontal: 0.7,
        knockback_vertical: 0.5,
        type: "projectile"
    },
    {
        identifier: "pb_scraft:projectile_beam",
        soundLaunch: "pb_scraft.spell_launch_4",
        soundImpact: "pb_scraft.spell_impact_4",
        particle_impact: [
            "pb_scraft:beam_impact_ember",
            "pb_scraft:beam_sparks_small"
        ],
        particle_track: [
            "pb_scraft:beam",
            "pb_scraft:beam_90"
        ],
        damage: 4,
        radius: 2,
        impulse: 1.8,
        spellpower: 0.5,
        knockback_horizontal: 0.7,
        knockback_vertical: 0.5,
        type: "projectile"
    },
    {
        identifier: "pb_scraft:cone_freeze",
        soundLaunch: "pb_scraft.freeze_launch",
        soundImpact: "pb_scraft.freeze_impact",
        particle_cast: [
            "pb_scraft:wind_stripes",
            "pb_scraft:freezing_fog"
        ],
        particle_impact: [
            "pb_scraft:freeze_hit"
        ],
        damage: 3,
        radius: 10,
        angle: 120,
        spellpower: 0.2,
        knockback_horizontal: 0.3,
        knockback_vertical: 0.3,
        type: "cone"
    },
    {
        identifier: "pb_scraft:projectile_firebolt",
        soundLaunch: "pb_scraft.firebolt_launch",
        soundImpact: "pb_scraft.firebolt_impact",
        particle_impact: [
            "pb_scraft:darkfire_explosion_small",
            "pb_scraft:darkfireball_impact_ember"
        ],
        particle_track: [
            "pb_scraft:darkfirebolt_beam",
            "pb_scraft:darkfirebolt_beam_90"
        ],
        particle_tick: [
            "pb_scraft:darkfirebolt_trail_instant"
        ],
        damage: 3,
        radius: 2,
        impulse: 2.8,
        spellpower: 0.3,
        knockback_horizontal: 0.3,
        knockback_vertical: 0.3,
        type: "projectile"
    },
    {
        identifier: "pb_scraft:projectile_pyroball",
        soundLaunch: "pb_scraft.pyroball_launch",
        soundImpact: "pb_scraft.pyroball_impact",
        particle_impact: [
            "pb_scraft:darkpyroball_explosion",
            "pb_scraft:darkpyroball_sheetsphere",
            "pb_scraft:darkpyroball_sparks",
            "pb_scraft:darkfireball_impact_ember",
            "pb_scraft:fireburst_embers",

            "pb_scraft:darkfireball_satellite",
            "pb_scraft:darkfireball_satellite",
            "pb_scraft:darkfireball_satellite",
            "pb_scraft:darkfireball_satellite",
            "pb_scraft:darkfireball_satellite"

        ],
        particle_tick: [
            "pb_scraft:darkpyroball_trail_instant_2",
            "pb_scraft:darkpyroball_spherical_ex_2",
            "pb_scraft:darkpyroball_embers"
        ],
        damage: 14,
        radius: 4,
        impulse: 1.0,
        spellpower: 0.6,
        knockback_horizontal: 0.5,
        knockback_vertical: 0.5,
        type: "projectile"
    },
    {
        identifier: "pb_scraft:effect_tornado",
        soundLaunch: "pb_scraft.tornado_launch",
        soundImpact: "pb_scraft.firebolt_impact",
        particle_impact: [],
        particle_tick: [],
        direction_multiplier: { x: 1, y: 0, z: 1 },
        range: 3,
        damage: 10,
        radius: 4,
        impulse: 2.2,
        spellpower: 0.6,
        knockback_horizontal: 0.5,
        knockback_vertical: 0.5,
        type: "summon"
    },
    {
        identifier: "pb_scraft:effect_fireorb",
        soundLaunch: "pb_scraft.comet_launch",
        soundImpact: "pb_scraft.firebolt_impact",
        particle_impact: [],
        particle_tick: [],
        direction_multiplier: { x: 0, y: 0, z: 0 },
        range: 32,
        damage: 6,
        radius: 4,
        impulse: 0,
        spellpower: 0.6,
        knockback_horizontal: 0.5,
        knockback_vertical: 0.5,
        type: "summon"
    },
    {
        identifier: "pb_scraft:projectile_ice_spike",
        soundLaunch: "pb_scraft.ice_spike_launch",
        soundImpact: "pb_scraft.ice_spike_impact",
        particle_impact: [
            "pb_scraft:ice_impact_crystals",
            "pb_scraft:ice_spike_dust_small"
        ],
        particle_track: [
            "pb_scraft:beam_ice",
            "pb_scraft:beam_ice_90"
        ],
        particle_tick: [
            "pb_scraft:ice_spike_trail_instant"
        ],
        damage: 5,
        radius: 3,
        impulse: 2.1,
        spellpower: 0.2,
        knockback_horizontal: 0.3,
        knockback_vertical: 0.3,
        type: "projectile"
    },
    {
        identifier: "pb_scraft:effect_ice_spike",
        soundLaunch: "pb_scraft.ice_pillars_launch",
        soundImpact: "pb_scraft.ice_pillars_out",
        particle_impact: [
            "pb_scraft:ice_impact_crystals",
            "pb_scraft:ice_spike_dust_small"
        ],
        range: 32,
        damage: 6,
        radius: 2,
        impulse: 0,
        spellpower: 0.30,
        knockback_horizontal: 0.5,
        knockback_vertical: 1.1,
        type: "summon"
    },
    {
        identifier: "pb_scraft:effect_ice_wall",
        soundLaunch: "pb_scraft.ice_wall_launch",
        soundImpact: "pb_scraft.ice_wall_launch",
        particle_impact: [
            "pb_scraft:ice_impact_crystals",
            "pb_scraft:ice_spike_dust_small"
        ],
        range: 32,
        damage: 4,
        radius: 2,
        impulse: 0,
        spellpower: 0.5,
        knockback_horizontal: 1.5,
        knockback_vertical: 0.5,
        type: "summon"
    },
    {
        identifier: "pb_scraft:effect_aura_fire",
        soundLaunch: "pb_scraft.fiery_spin_launch",
        soundImpact: "pb_scraft.fiery_spin_impact",
        particle_impact: [
            "pb_scraft:aura_fire_impact_embers",
            "pb_scraft:aura_fire_impact"
        ],
        range: 0,
        damage: 4,
        radius: 3.5,
        impulse: 0,
        spellpower: 0.2,
        knockback_horizontal: 0.0,
        knockback_vertical: 0.0,
        target: "other",
        type: "aura"
    },
    {
        identifier: "pb_scraft:effect_aura_frost",
        soundLaunch: "pb_scraft.frost_aura_launch",
        soundImpact: "pb_scraft.frost_aura_impact",
        particle_impact: [
            "pb_scraft:ice_impact_crystals",
            "pb_scraft:ice_spike_dust_small"
        ],
        effect: {
            type: "slowness",
            duration: 5 * mc.TicksPerSecond,
            options: { amplifier: 2, showParticles: false }
        },
        range: 0,
        damage: 1,
        radius: 4.0,
        impulse: 0,
        spellpower: 0.1,
        knockback_horizontal: 0.4,
        knockback_vertical: 0.1,
        target: "other",
        type: "aura"
    },
    {
        identifier: "pb_scraft:effect_aura_heal",
        soundLaunch: "pb_scraft.healing_aura_launch",
        soundImpact: "pb_scraft.heal_bubble_impact",
        particle_impact: [
            "pb_scraft:aura_bubbles_impact"
        ],
        effect: {
            type: "regeneration",
            duration: 1 * mc.TicksPerSecond,
            options: { amplifier: 2, showParticles: false }
        },
        range: 0,
        damage: 0,
        radius: 3.5,
        impulse: 0,
        spellpower: 0.3,
        knockback_horizontal: 0.0,
        knockback_vertical: 0.0,
        target: "self",
        type: "aura"
    },
    {
        identifier: "pb_scraft:lightning",
        soundLaunch: "pb_scraft.lightning_strike_launch",
        soundImpact: "pb_scraft.lightning_strike_launch",
        particle_impact: [
            "pb_scraft:lightning_y_main",
            "pb_scraft:lightning_y_impact_main",
            "pb_scraft:lightning_y_shockwave",
            "pb_scraft:lightning_rune"
        ],
        damage: 10,
        radius: 3,
        spellpower: 0.2,
        knockback_horizontal: 0.3,
        knockback_vertical: 0.3,
        type: "instant"
    },
    {
        identifier: "pb_scraft:area_heal",
        soundLaunch: "pb_scraft.fire_launch",
        soundImpact: "pb_scraft.fire_impact",
        particle_impact: [
            "pb_scraft:bubbles_shine",
            "pb_scraft:twirl_bubbles",
            "pb_scraft:water_summoning_rune"
        ],
        damage: 6, //this is the amount of damage healed, undead take this amount of damage
        radius: 4,
        spellpower: 0.2,
        knockback_horizontal: 0.1,
        knockback_vertical: 0.1,
        type: "instant"
    },
    {
        identifier: "pb_scraft:twilight_explosion",
        soundLaunch: "pb_scraft.twilight_explosion_launch",
        soundImpact: "pb_scraft.twilight_explosion_launch",
        particle_impact: [
            "pb_scraft:twilight_explosion_impact",
            "pb_scraft:twilight_explosion_rune",
            "pb_scraft:twilight_explosion_spherical"
        ],
        particle_hit: [
            "pb_scraft:twilight_explosion_hit"
        ],
        range: 0,
        damage: 8,
        radius: 6,
        spellpower: 0.4,
        knockback_horizontal: 0.3,
        knockback_vertical: 0.3,
        type: "instant"
    },
    {
        identifier: "pb_scraft:effect_tornado_air",
        soundLaunch: "pb_scraft.air_tornado_launch",
        soundImpact: "pb_scraft.air_tornado_launch",
        particle_impact: [],
        particle_tick: [],
        direction_multiplier: { x: 0.5, y: 0, z: 0.5 },
        range: 24,
        damage: 5,
        radius: 5,
        impulse: 2.2,
        spellpower: 0.6,
        knockback_horizontal: 0.2,
        knockback_vertical: 1.0,
        type: "summon"
    },
    {
        identifier: "pb_scraft:projectile_stone",
        soundLaunch: "pb_scraft.rock_spell_launch",
        soundImpact: "pb_scraft.rock_spell_impact",
        particle_impact: [
            "pb_scraft:rock_explosion",
            "pb_scraft:huge_rocks",
            "pb_scraft:rock_sparks",
            "pb_scraft:rock_dust",
            "pb_scraft:rock_shockwave"
        ],
        particle_tick: [],
        damage: 12,
        radius: 3,
        impulse: 1,
        spellpower: 0.2,
        knockback_horizontal: 2.2,
        knockback_vertical: 0.8,
        type: "projectile"
    },
    {
        identifier: "pb_scraft:light_arc",
        soundLaunch: "pb_scraft.light_arc_impact",
        soundImpact: "pb_scraft.twilight_explosion_launch",
        particle_impact: [
            "pb_scraft:arc_light_impact",
            "pb_scraft:arc_light_shine"
        ],
        particle_track: [
            "pb_scraft:arc_light",
            "pb_scraft:arc_light_90"
        ],
        range: 48,
        damage: 8,
        radius: 2,
        spellpower: 0.2,
        knockback_horizontal: 0.1,
        knockback_vertical: 0.0,
        type: "raycast"
    },
    //additions
    {
        identifier: "pb_scraft:projectile_windsickle",
        soundLaunch: "pb_scraft.air_tornado_launch",
        soundImpact: "pb_scraft.pyroball_impact",
        particle_impact: [
            "pb_scraft:rock_dust",
            "pb_scraft:rock_shockwave"
        ],
        particle_tick: [
            "pb_scraft:windsickle_ex",
            "pb_scraft:windsickle_trail"
        ],
        damage: 2,
        radius: 6,
        impulse: 2.3,
        spellpower: 0.2,
        knockback_horizontal: 2.4,
        knockback_vertical: 0.6,
        type: "projectile"
    },
    {
        identifier: "pb_scraft:flash",
        soundLaunch: "pb_scraft.lightning_strike_launch",
        soundImpact: "pb_scraft.lightning_strike_launch",
        particle_impact: [
            "pb_scraft:lightning_y_impact_main",
            "pb_scraft:lightning_y_shockwave",
            "pb_scraft:lightning_rune"
        ],
        range: 32,
        damage: 6,
        radius: 3,
        spellpower: 0.2,
        knockback_horizontal: 0.6,
        knockback_vertical: 0.6,
        type: "instant"
    },
    {
        identifier: "pb_scraft:upwind",
        soundLaunch: "pb_scraft.upwind",
        soundImpact: "pb_scraft.upwind",
        particle_impact: [
            "pb_scraft:pb_scraft:windsickle_trail"
        ],
        range: 0,
        damage: 0,
        radius: 0,
        impulse: 1.2,
        spellpower: 0.2,
        knockback_horizontal: 0.6,
        knockback_vertical: 0.6,
        type: "instant"
    },
    {
        identifier: "pb_scraft:projectile_gnaw",
        soundLaunch: "pb_scraft.twilight_explosion_launch",
        soundImpact: "pb_scraft.lifesteal_bite",
        particle_impact: [
            "pb_scraft:twilight_explosion_impact",
            "pb_scraft:twilight_explosion_sheetsphere"
        ],
        particle_tick: [],
        direction_multiplier: { x: 1, y: 1, z: 1 },
        range: 3,
        damage: 13,
        radius: 4,
        impulse: 2.2,
        spellpower: 0.6,
        knockback_horizontal: 0.5,
        knockback_vertical: 0.5,
        type: "summon"
    },
    {
        identifier: "pb_scraft:effect_moonbeam",
        soundLaunch: "pb_scraft.twilight_explosion_launch",
        soundImpact: "pb_scraft.arc_light_impact",
        particle_impact: [],
        range: 32,
        damage: 6,
        radius: 2.5,
        impulse: 0,
        spellpower: 0.30,
        knockback_horizontal: 0.2,
        knockback_vertical: 0.2,
        type: "summon"
    },
    {
        identifier: "pb_scraft:effect_earthquake",
        soundLaunch: "pb_scraft.rock_spell_impact",
        soundImpact: "pb_scraft.rock_spell_impact",
        particle_impact: [],
        direction_multiplier: { x: 0, y: 0, z: 0 },
        effect: {
            type: "slowness",
            duration: 5 * mc.TicksPerSecond,
            options: { amplifier: 2, showParticles: false }
        },
        range: 32,
        damage: 5,
        radius: 5,
        impulse: 0,
        spellpower: 0.30,
        knockback_horizontal: 0.1,
        knockback_vertical: 0.3,
        type: "summon"
    }
]