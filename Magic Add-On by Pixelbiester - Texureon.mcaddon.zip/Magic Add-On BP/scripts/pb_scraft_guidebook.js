import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as config from "./pb_scraft_config.js";

const GUIDEBOOK_ITEM = "pb_scraft:guidebook";   //id of your guidebook item
const GUIDEBOOK_TAG = "pb_scraft_book";    //tag that gets applied to the player after first book drop
const SOUND_TURN_PAGE = "item.book.page_turn";
const SOUND_OPTIONS = { pitch: 1.0, volume: 5.0, };

export const MENUS = [
    {
        menuID: "pb_scraft:main",
        title: "§l§uMagic Spells",
        body: "Welcome to §u§lMagic!§r\n\n§6Craft, §6modify§r & §6assemble§r spells through the power of §u~Arcane Mana~§r\n\nFor a quick lookup you can also use this book on §umagic blocks§r to open up its info page.\n\nRead the §6Tutorial§r to get started.",
        buttons: [
            {
                title: "Tutorial",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_tutorial",
                connectID: "pb_scraft:tutorial"
            },
            {
                title: "Crafting",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_orb_twilight",
                connectID: "pb_scraft:content"
            },
            {
                title: "Config",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_configuration",
                connectID: "pb_scraft:config"
            },
            {
                title: "About",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_about",
                connectID: "pb_scraft:about"
            }
        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // CATEGORY SECTION
    // PRE-SECTION
    // ADDTIONAL SEPERATOR SPACE

    // Tutorial Section

    {
        menuID: "pb_scraft:tutorial",
        title: "§l§uTutorial",
        body: "To cast §uSpells§r, you will first need to understand how to make and use an §6Arcane Altar§r.\n\nThis section will teach you how. First, you should look at §6Magic Devices§r.",
        buttons: [
            {
                title: "Magic Devices",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_magic_devices",
                connectID: "pb_scraft:magic_devices"
            },
            {
                title: "Crafting Magic",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_crafting_magic",
                connectID: "pb_scraft:crafting_magic"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:main"
            }
        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Content Section

    {
        menuID: "pb_scraft:content",
        title: "§u§lCrafting",
        body: "§6Choose a §uTopic§r§6:",
        buttons: [
            {
                title: "Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spells",
                connectID: "pb_scraft:spells"
            },
            {
                title: "Staffs",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_staffs",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Armor",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_armors",
                connectID: "pb_scraft:armor"
            },
            {
                title: "Magic Items",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_items",
                connectID: "pb_scraft:items"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:main"
            }
        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // MAGIC DEVICES SECTION
    // MAIN SECTION 1
    // ADDITIONAL SEPERATOR SPACE

    {
        menuID: "pb_scraft:magic_devices",
        title: "§u§lMagic Devices",
        body: "Start with the §6Magic Workbench§r.",
        buttons: [
            {
                title: "Magic Workbench",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_magic_workbench",
                connectID: "pb_scraft:magic_workbench"
            },
            {
                title: "Magifier & Glyph Press",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_glyph_press",
                connectID: "pb_scraft:glyph_press"
            },
            {
                title: "Mana Harvesting",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_mana_harvesting",
                connectID: "pb_scraft:mana_harvesting"
            },
            {
                title: "Mana Condenser",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_mana_condenser",
                connectID: "pb_scraft:mana_condenser"
            },
            {
                title: "Arcane Altar",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_arcane_altar",
                connectID: "pb_scraft:arcane_altar"
            },
            {
                title: "Odds & Ends",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_odds_ends",
                connectID: "pb_scraft:odds_ends"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:tutorial"
            }
        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Magic Workbench / Section 1.1

    {
        menuID: "pb_scraft:magic_workbench",
        title: "§l§uMagic Workbench",
        body: "With some §6iron§r and an §uamethyst shard§r you can craft a §6Magic Workbench§r.\n\nYou can use it to craft all of the other §6Magic Devices§r, so you'll want to use it as a §ubase of operations§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r The recipe for it should show up in your §6Crafting Table§r menu.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:magic_devices"
            }

        ],
        type: "form",
        openOnBlock: [
            "pb_scraft:magic_workbench_base",
            "pb_scraft:magic_workbench_scope"
        ],
        openOnEntity: []
    },

    // Glyph Press / Section 1.2

    {
        menuID: "pb_scraft:glyph_press",
        title: "§l§uMagifier & Glyph Press",
        body: "To craft §6Runes§r & §uGlyphs§r, you'll need 2 more crafting devices:\n\n§6[§u-§6]§r §6Magifier§r:\nMakes crystals & rune bases.\n\n§6[§u-§6]§r §uGlyph Press§r\nPresses glyphs & runes onto bases.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §6Runes§r & §uGlyphs§r are used as the basis for all spell crafting.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:magic_devices"
            }

        ],
        type: "form",
        openOnBlock: ["pb_scraft:magic_workbench_press",],
        openOnEntity: []
    },

    // Mana Harvesting / Section 1.3

    {
        menuID: "pb_scraft:mana_harvesting",
        title: "§u§lMana Harvesting",
        body: "§6Arcane Altars§r are fueled by §uMana§r collected with a §6Mana Harvester§r.\n\nTo get one working, you need to set it up with a §6Scope§r and connect it to a §6Mana Tank§r via §uMana Pipes§r.\n\nIf it's set up properly, the §6Mana Tank§r should slowly fill up with §uMana§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §6Mana Tanks§r consist of multiple §6Mana Tank Blocks§r and must be at least §u2 blocks§r tall to function. Each block can store up to 1000 §uMana§r\n\n§6[§u-§6]§r §uMana Pipes§r have a maximum range of §u16 blocks§r.",
        buttons: [
            {
                title: "Mana Scopes",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_mana_scopes",
                connectID: "pb_scraft:mana_scopes"
            },
            {
                title: "Mana Meter",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_mana_meter",
                connectID: "pb_scraft:mana_meter"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:magic_devices"
            }

        ],
        type: "form",
        openOnBlock: [
            "pb_scraft:mana_harvester",
            "pb_scraft:mana_harvester_flora",
            "pb_scraft:mana_harvester_scope",
            "pb_scraft:creative_mana_harvester",
            "pb_scraft:pipe",
            "pb_scraft:mana_tank_top",
            "pb_scraft:mana_tank_bottom",
            "pb_scraft:tank_block"
        ],
        openOnEntity: []
    },

    // Mana Condenser / Section 1.3(5)

    {
        menuID: "pb_scraft:mana_condenser",
        title: "§l§uMana Condenser",
        body: "The §uMana Condenser§r consumes §uamethyst shards§r directly to produce §6Mana§r as an alternative method.\n\n§6[§u-§6]§r Like §uMana Harvesters§r it needs a connection to a §uMana Tank§r via §uMana Pipes§r.\n\n§6[§u-§6]§r Each consumed §ushard§r produces §61000 Mana§r for connected §uMana Tanks§r.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:magic_devices"
            }

        ],
        type: "form",
        openOnBlock: ["pb_scraft:mana_condenser"],
        openOnEntity: []
    },

    // Mana Scopes / Section 1.3.1

    {
        menuID: "pb_scraft:mana_scopes",
        title: "§u§lMana Scopes",
        body: "§6Mana Scopes§r need to be put §uon top§r of a §6Mana Harvester§r for it to work.\n\nDifferent scopes pull §uMana§r from different sources.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §6Moonlight Scope§r:\nDraws §uMana§r from moonlight. Only works at §unighttime§r.\n\n§6[§u-§6]§r §6Flora Scope§r:\nDraws §uMana§r from surrounding plant life. Works better if many §uflowers§r and §utrees§r are near it.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:mana_harvesting"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Mana Meter / Section 1.3.2

    {
        menuID: "pb_scraft:mana_meter",
        title: "§u§lMana Meter",
        body: "The §6Mana Meter§r is an invaluable tool to check the §uMana§r contents of your tanks & devices.\n\nInteract with §6Magic Devices§r while holding it to gain various information.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r Use on a §6Mana Tank§r to see how much §uMana§r it holds.\n\n§6[§u-§6]§r use on §6Mana Harvesters§r to see if they are working properly.\n\n§6[§u-§6]§r Use on an §6Arcane Altar§r to highlight connected §6Arcane Pedestals§r.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:mana_harvesting"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    //Arcane Altar / Section 1.4

    {
        menuID: "pb_scraft:arcane_altar",
        title: "§u§lArcane Altar",
        body: "The §6Arcane Altar§r is the heart of the spellcrafting operation.\n\nIt works by drawing §uMana§r from connected tanks to infuse §uInfusion Items§r that are placed on nearby §6Arcane Pedestals§r into a §uBase Item§r.\n\nThe §uBase Item§r must be held while interacting with the §6Altar§r to create a new §umagic item§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r The §6Altar§r will spark §umagic energy§r if it has enough §uMana§r to infuse.\n\n§6[§u-§6]§r There should be between §u§l3§r and §u§l5§r §uPedestals§r around the §6Altar§r.\n\n§6[§u-§6]§r The §6Pedestals§r need to be within a §u4-radius cube§r around the §6Altar§r, but their exact postion and order don't matter.\n\n§6[§u-§6]§r Use a §6Mana Meter§r on the §6Altar§r, to highlight connected §6Pedestals§r.\n\n§6[§u-§6]§rThe §6Altar§r needs to be connected to a tank or a harvester via §uMana Pipes§r.\n\n§6[§u-§6]§r Check the §6Content§r section to see the §uAltar Recipes§r for each item.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:magic_devices"
            }

        ],
        type: "form",
        openOnBlock: [
            "pb_scraft:arcane_altar",
            "pb_scraft:arcane_pedestal"
        ],
        openOnEntity: []
    },

    // Odds & Ends / section 1.5

    {
        menuID: "pb_scraft:odds_ends",
        title: "§u§lOdds & Ends",
        body: "There are many additional §6decorative§r blocks to craft that will bring a §umagical charm§r to your base.\n\nFrom §6Chandeliers§r to §uMagic Cauldrons§r, they can all be crafted from the §uMagic Workbench§r.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:magic_devices"
            }

        ],
        type: "form",
        openOnBlock: ["pb_scraft:magic_cauldron",
            "pb_scraft:chandelier",
            "pb_scraft:candelabrum",
            "pb_scraft:jar"
        ],
        openOnEntity: []
    },

    // CRAFTING MAGIC SECTION
    // MAIN SECTION 2
    // ADDITIONAL SEPERATOR SPACE

    {
        menuID: "pb_scraft:crafting_magic",
        title: "§u§lCrafting Magic",
        body: "How to craft §6Staffs§r & §uSpells§r",
        buttons: [
            {
                title: "Altar Basics",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_altar_configuration",
                connectID: "pb_scraft:altar_configuration"
            },
            {
                title: "Staffmaking",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_staffs",
                connectID: "pb_scraft:crafting_staffs"
            },
            {
                title: "Crafting Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_crafting_spells",
                connectID: "pb_scraft:crafting_spells"
            },
            {
                title: "Implementing Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_implementing_spells",
                connectID: "pb_scraft:implementing_spells"
            },
            {
                title: "Modifying Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_runes_glyphs",
                connectID: "pb_scraft:modifying_spells"
            },
            {
                title: "Creative Spellcrafting",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_creative_crafting",
                connectID: "pb_scraft:creative"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:tutorial"
            },

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Altar Configuration / Section 2.1

    {
        menuID: "pb_scraft:altar_configuration",
        title: "§u§lAltar Basics",
        body: "Before using an §6Arcane Altar§r, connect it to §uMana§r via pipes and place enough §6Arcane Pedestals§r.\n\nThen follow these steps:\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u1§6]§r Check the §uAltar Recipe§r for the item you want to make in the §6Content§r section of this guidebook.\n\n§6[§u2§6]§r It will tell you to infuse a §6Base Item§r with a list of §uInfusion Items§r.\n\n§6[§u3§6]§r Place all required §uInfusion Items§r on §6Arcane Pedestals§r connected to the §6Altar§r.\n\n§6[§u4§6]§r Interact with the §&Arcane Altar§r while holding the §uBase Item§r.\n\n§6[§u5§6]§r Witness the §6Spectacle§r of §uMagic Infusion§r and take your new item.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r Each §6Arcane Infusion§r draws 1000 §uMana§r.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:crafting_magic"
            }

        ],
        type: "form",
        openOnBlock: "pb_scraft:arcane_altar",
        openOnEntity: ""
    },

    // Staff Crafting / Section 2.2

    {
        menuID: "pb_scraft:crafting_staffs",
        title: "§u§lStaffmaking",
        body: "§6Staffs§r are used to cast a §uSpell§r by storing it inside them.\n\nThey are crafted via §uMagic Infusion§r at the §6Arcane Altar§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r There are basic §6Level 1 Staffs§r that can be upgraded to §6Level 2 & 3§r with more §uMagic Infusion§r.\n\n§6[§u-§6]§r Higher Level §6Staffs§r have more §uSpell Power§r, which increases their §6damage.\n\n§6[§u-§6]§r They typically require §6crafting items§r found in your world that are related to their §uelement.§r\n\n§6[§u-§6]§r Higher §6Levels§r require rarer items.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:crafting_magic"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Crafting Spells / Section 2.3

    {
        menuID: "pb_scraft:crafting_spells",
        title: "§u§lCrafting Spells",
        body: "§uSpells§r are created by crafting their §uSpell §6Orb§r via §uMagic Infusion§r at the §6Arcane Altar§r.\n\n§uSpell §6Orbs§r can be put into §6Staffs§r from which their §uSpell§r can be cast.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §uSpell §6Orbs§r always use the §6Rune§r of their element as a base item and §uGlyphs§r as infusion items.\n\n§6[§u-§6]§r The recipe also always needs 2 §uAmethyst Shards§r.\n\n§6[§u-§6]§r There are §uBase Glyphs§r used to craft §uSpells§r and §uModifier Glyphs§r used to alter them.\n\n§6[§u-§6]§r §uSpell §6Orbs§r can only hold up to 2 §uModifier Glyphs§r.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:crafting_magic"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Implementing Spells / Section 2.4

    {
        menuID: "pb_scraft:implementing_spells",
        title: "§u§lImplementing Spells",
        body: "To put a §uSpell§r onto a §rStaff§r, you need to infuse the staff with the spell at the §6Arcane Altar§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r Uses the §uSpell §6Orb§r as infusion item and the §6Staff§r as base item.\n\n§6[§u-§6]§r To remove a spell from a staff, you can infuse the staff with a single §uAmethyst Shard§r\n\n§6[§u-§6]§r Upgrading a staff that has a spell, will keep that §uspell§r on it.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:crafting_magic"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Modifying Spells / Section 2.5

    {
        menuID: "pb_scraft:modifying_spells",
        title: "§u§lModifying Spells",
        body: "§uSpells§r can be modified by infusing them with §uModifier Glyphs§r at the §6Arcane Altar§r.\n\nTo do so, use the §uSpell §6Orb§r with your §uSpell§r as a §6Base Item§r and the §uModifier Glyph§r you want to put on it as an §uInfusion Item§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §6§oAccelerate Glyph:§r\nDecreases the spell's §uCast Time§r.\n\n§6[§u-§6]§r §6§oIntensify Glyph:§r\nIncreases the spell's §6Damage§r.\n\n§6[§u-§6]§r §6§oAlleviate Glyph:§r\nDecreases the spell's §uMana Cost§r.\n\n§6[§u-§6]§r §6§oMirror Glyph:§r\nChanges the §uSpell§r entirely!\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r Not all §uSpells§r will benefit from every §uGlyph§r effect.\n\n§6[§u-§6]§r All §uMirror Glyph§r spells are also listed in the list of spells in the §6Content§r section.\n\n§6[§u-§6]§r §uSpell §6Orbs§r can only hold up to 2 §uModifier Glyphs§r, including the §uMirror Glyph§r.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:crafting_magic"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Creative Spellcrafting / Section 2.6

    {
        menuID: "pb_scraft:creative",
        title: "§u§lCreative Spellcrafting",
        body: "If you want to craft §uspells§r in §6Creative Mode§r, you can use special devices.\n\nVia the creative item menu, you can spawn an §uArcana Altar [Creative]§r and a §uMana Harvester [Creative]§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r The §ucreative harvester§r always produces the maximum amount of §6Mana§r.\n\n§6[§u-§6]§r The §ucreative Altar§r opens a §6Spellcrafting Menu§r on interact.\n\n§6[§u-§6]§r The §6Spellcrafting Menu§r can be used to spawn a §ustaff§r with a §uspell§r & §uglyphs§r already set on it.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:crafting_magic"
            }

        ],
        type: "form",
        openOnBlock: ["pb_scraft:creative_mana_harvester",
            "pb_scraft:creative_arcane_altar"
        ],
        openOnEntity: []
    },

    // SPELLS SECTION
    // MAIN SECTION 3
    // CONTAINS ALTAR RECIPES FOR ALL SPELLS

    {
        menuID: "pb_scraft:spells",
        title: "§u§lSpell Categories",
        body: "§6Choose an §uElement§r§6:",
        buttons: [
            {
                title: "Fire Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_orb_fire",
                connectID: "pb_scraft:spells_fire"
            },
            {
                title: "Frost Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_orb_ice",
                connectID: "pb_scraft:spells_frost"
            },
            {
                title: "Storm Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_orb_air",
                connectID: "pb_scraft:spells_storm"
            },
            {
                title: "Earth Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_orb_earth",
                connectID: "pb_scraft:spells_earth"
            },
            {
                title: "Twilight Spells",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_orb_twilight",
                connectID: "pb_scraft:spells_twilight"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:content"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // FIRE SPELLS SECTION
    // SUBSECTION 3a

    {
        menuID: "pb_scraft:spells_fire",
        title: "§u§lFire Spell List",
        body: "§6Choose a §cSpell§r§6:",
        buttons: [
            {
                title: "Fireball",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_fireball",
                connectID: "pb_scraft:spell_fireball"
            },
            {
                title: "Pyroball",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_pyroball",
                connectID: "pb_scraft:spell_pyroball"
            },
            {
                title: "Firebolt",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_firebolt",
                connectID: "pb_scraft:spell_firebolt"
            },
            {
                title: "Fiery Spin",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_fiery_spin",
                connectID: "pb_scraft:spell_fiery_spin"
            },
            {
                title: "Fire Tornado",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_fire_tornado",
                connectID: "pb_scraft:spell_fire_tornado"
            },
            {
                title: "Comet",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_comet",
                connectID: "pb_scraft:spell_comet"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Fireball / Section 3a.1

    {
        menuID: "pb_scraft:spell_fireball",
        title: "§u§lFireball",
        body: "§cFireball§r §l§6[§c><§6]§r §uFire Arc Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §cFire Rune§r with:\n§d - §uArc Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nShoots a ball of fire.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   8 \n§6[§uMana Cost§6: ]   15\n§6[§uCast Time§6:  ]   12",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_fire"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_pyroball"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Pyroball / Section 3a.2

    {
        menuID: "pb_scraft:spell_pyroball",
        title: "§u§lPyroball",
        body: "§cPyroball§r §l§6[§c><§6]§r §uFire Touch Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §cFire Rune§r with:\n§d - §uTouch Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nShoots a large, erupting ball of fire.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   14 \n§6[§uMana Cost§6: ]   40\n§6[§uCast Time§6:  ]   45",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_fire"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_firebolt"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Firebolt / Section 3a.3

    {
        menuID: "pb_scraft:spell_firebolt",
        title: "§u§lFirebolt",
        body: "§cFirebolt§r §l§6[§c>|<§6]§r §uFire Arc Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §cFireball§r with:\n§d - §uMirror Glyph\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nShoots a continuous burst of fire.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   3 \n§6[§uMana Cost§6: ]   5\n§6[§uCast Time§6:  ]   25",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_fire"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_fiery_spin"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Fire Aura / Section 3a.4

    {
        menuID: "pb_scraft:spell_fiery_spin",
        title: "§u§lFiery Spin",
        body: "§cFiery Spin§r §l§6[§c><§6]§r §uFire Aura Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §cFire Rune§r with:\n§d - §uAura Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a circle of flames that follows the caster.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   4 \n§6[§uMana Cost§6: ]   65\n§6[§uCast Time§6:  ]   50",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_fire"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_fire_tornado"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Fire Tornado / Section 3a.5

    {
        menuID: "pb_scraft:spell_fire_tornado",
        title: "Fire Tornado",
        body: "§cFire Tornado§r §l§6[§c>|<§6]§r §uFire Aura Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §cFiery Spin§r with:\n§d - §uMirror Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a flaming tornado that lingers and ignites its surroundings.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   3 \n§6[§uMana Cost§6: ]   25\n§6[§uCast Time§6:  ]   18",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_fire"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_comet"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Comet / Section 3a.6

    {
        menuID: "pb_scraft:spell_comet",
        title: "Comet",
        body: "§cComet§r §l§6[§c>|<§6]§r §uFire Touch Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §cPyroball§r with:\n§d - §uMirror Glyph\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a flaming sphere that explodes in multiple bursts.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   6 \n§6[§uMana Cost§6: ]   20\n§6[§uCast Time§6:  ]   30",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_fire"
            },
            {
                title: "Back to Start",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_fireball"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // ICE SPELLS SECTION
    // SUBSECTION 3b

    {
        menuID: "pb_scraft:spells_frost",
        title: "§u§LFrost Spell List",
        body: "§6Choose a §bSpell§r§6:",
        buttons: [

            {
                title: "Freeze",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_freeze",
                connectID: "pb_scraft:spell_freeze"
            },
            {
                title: "Ice Spike",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_ice_spike",
                connectID: "pb_scraft:spell_ice_spike"
            },
            {
                title: "Ice Pillar",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_ice_pillar",
                connectID: "pb_scraft:spell_ice_pillar"
            },
            {
                title: "Ice Wall",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_ice_wall",
                connectID: "pb_scraft:spell_ice_wall"
            },
            {
                title: "Frost Aura",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_frost_aura",
                connectID: "pb_scraft:spell_frost_aura"
            },
            {
                title: "Healing Aura",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_healing_aura",
                connectID: "pb_scraft:spell_healing_aura"
            },
            {
                title: "Healing Area",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_healing_area",
                connectID: "pb_scraft:spell_healing_area"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells"
            },

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Freeze / Section 3b.1

    {
        menuID: "pb_scraft:spell_freeze",
        title: "§u§lFreeze",
        body: "§bFreeze§r §6[§b<>§6]§r §uFrost Touch Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bFrost Rune§r with:\n§d - §uTouch Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCasts freezing cold out from the caster.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   3 \n§6[§uMana Cost§6: ]   25\n§6[§uCast Time§6:  ]   18",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_frost"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_ice_spike"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Ice Spike / Section 3b.2

    {
        menuID: "pb_scraft:spell_ice_spike",
        title: "§l§uIce Spike",
        body: "§bIce Spike§r §6[§b<>§6]§r §uFrost Arc Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bFrost Rune§r with:\n§d - §uArc Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nShoots a continuous burst of ice cold energy.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   5 \n§6[§uMana Cost§6: ]   8\n§6[§uCast Time§6:  ]   30",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_frost"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_ice_pillar"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Ice Pillar / Section 3b.3

    {
        menuID: "pb_scraft:spell_ice_pillar",
        title: "§u§lIce Pillar",
        body: "§bIce Pillar§r §6[§b<>§6]§r §uFrost Self Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bFrost Rune§r with:\n§d - §uSelf Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a burst of damaging ice spikes emerging from the ground. \n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   6 \n§6[§uMana Cost§6: ]   25\n§6[§uCast Time§6:  ]   20",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_frost"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_ice_wall"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Ice Wall / Section 3b.4

    {
        menuID: "pb_scraft:spell_ice_wall",
        title: "§u§lIce Wall",
        body: "§bIce Wall§r §6[§b<|>§6]§r §uFrost Self Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bIce Pillar§r with:\n§d - §uMirror Glyph\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a wall of ice that blocks enemies.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   4 \n§6[§uMana Cost§6: ]   15\n§6[§uCast Time§6:  ]   20",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_frost"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_frost_aura"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Frost Aura / Section 3b.5

    {
        menuID: "pb_scraft:spell_frost_aura",
        title: "§u§lFrost Aura",
        body: "§bFrost Aura§r §6[§b<>§6]§r §uFrost Aura Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bFrost Rune§r with:\n§d - §uAura Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a vortex of slowing ice that follows the caster.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   1 \n§6[§uMana Cost§6: ]   50\n§6[§uCast Time§6:  ]   40",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_frost"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_healing_aura"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Healing Aura / Section 3b.6

    {
        menuID: "pb_scraft:spell_healing_aura",
        title: "§u§lHealing Aura",
        body: "§bHealing Aura§r §6[§b<|>§6]§r §uFrost Aura Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bFrost Aura§r with:\n§d - §uMirror Glyph\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a whirlpool of regenerating waters that follows the caster.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   0 \n§6[§uMana Cost§6: ]   35\n§6[§uCast Time§6:  ]   15",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_frost"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_healing_area"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Healing Area / Section 3b.7

    {
        menuID: "pb_scraft:spell_healing_area",
        title: "§u§lHealing Area",
        body: "§bHealing Area§r §6[§b<|>§6]§r §uFrost Touch Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bFreeze§r with:\n§d - §uMirror Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a burst of regenerating water ermerging from the ground that damages undead & heals everything else.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   6 \n§6[§uMana Cost§6: ]   10\n§6[§uCast Time§6:  ]   10",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_frost"
            },
            {
                title: "Back to Start",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_freeze"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // STORM SPELLS SECTION
    // SUBSECTION 3c

    {
        menuID: "pb_scraft:spells_storm",
        title: "§u§lStorm Spell List",
        body: "§6Choose a §eSpell§r§6:",
        buttons: [

            {
                title: "Air Tornado",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_air_tornado",
                connectID: "pb_scraft:spell_air_tornado"
            },
            {
                title: "Wind Sickle",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_wind_sickle",
                connectID: "pb_scraft:spell_wind_sickle"
            },
            {
                title: "Lightning",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_lightning",
                connectID: "pb_scraft:spell_lightning"
            },
            {
                title: "Upwind",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_upwind",
                connectID: "pb_scraft:spell_upwind"
            },
            {
                title: "Flash",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_flash",
                connectID: "pb_scraft:spell_flash"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells"
            },

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Air Tornado / Section 3c.1

    {
        menuID: "pb_scraft:spell_air_tornado",
        title: "§u§LAir Tornado",
        body: "§eAir Tornado§r §6[§e)(§6]§r §uStorm Aura Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §eStorm Rune§r with:\n§d - §uAura Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a tornado that dances around and damages enemies.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   5 \n§6[§uMana Cost§6: ]   20\n§6[§uCast Time§6:  ]   30",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_storm"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_wind_sickle"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Wind Sickle / Section 3c.2

    {
        menuID: "pb_scraft:spell_wind_sickle",
        title: "§u§lWind Sickle",
        body: "§eWind Sickle§r §6[§e)(§6]§r §uStorm Arc Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §eStorm Rune§r with:\n§d - §uArc Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nShoots a cutting blade of wind that releases a blowing burst on impact.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   2 \n§6[§uMana Cost§6: ]   15\n§6[§uCast Time§6:  ]   15",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_storm"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_lightning"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Lightning / Section 3c.3

    {
        menuID: "pb_scraft:spell_lightning",
        title: "§u§lFlash",
        body: "§eLightning§r §6[§e)|(§6]§r §uStorm Arc Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §eWind Sickle§r with:\n§d - §uMirror Glyph\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCauses a lightning burst to hit the ground.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   6 \n§6[§uMana Cost§6: ]   25\n§6[§uCast Time§6:  ]   15",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_storm"
            },
            {
                title: "Back to Start",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_air_tornado"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Upwind / Section 3c.6

    {
        menuID: "pb_scraft:spell_upwind",
        title: "Upwind",
        body: "§eUpwind§r §6[§e)(§6]§r §uStorm Self Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §eStorm Rune§r with:\n§d - §uSelf Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nWith a gust of wind, boosts the caster into the direction they're looking.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   0 \n§6[§uMana Cost§6: ]   15\n§6[§uCast Time§6:  ]   3",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_storm"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_air_tornado"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Flash / Section 3c.5

    {
        menuID: "pb_scraft:spell_flash",
        title: "Lightning",
        body: "§eFlash§r §6[§e)|(§6]§r §uStorm Self Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §eUpwind§r with:\n§d - §uMirror Glyph\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nTeleports the caster in a flash at their target location and releases a damaging lightning burst.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   10 \n§6[§uMana Cost§6: ]   15\n§6[§uCast Time§6:  ]   10",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_storm"
            },
            {
                title: "Back to Start",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_air_tornado"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    //EARTH SPELLS SECTION
    //SUBSECTION 3d

    {
        menuID: "pb_scraft:spells_earth",
        title: "§u§lEarth Spell List",
        body: "§6Choose a §aSpell§r§6:",
        buttons: [

            {
                title: "Rock Sling",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_rock_sling",
                connectID: "pb_scraft:spell_rock_sling"
            },
            {
                title: "Earthquake",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_earthshaker",
                connectID: "pb_scraft:spell_earthquake"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells"
            },

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Rock Sling / Section 3d.1

    {
        menuID: "pb_scraft:spell_rock_sling",
        title: "§u§lRock Sling",
        body: "§aRock Sling§r §6[§a()§6]§r §uEarth Arc Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §aEarth Rune§r with:\n§d - §uArc Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nShoots a large boulder that bursts on impact.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   12 \n§6[§uMana Cost§6: ]   15\n§6[§uCast Time§6:  ]   18",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_earth"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_rock_sling"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Earthquake / Section 3d.2

    {
        menuID: "pb_scraft:spell_earthquake",
        title: "§u§lEarthquake",
        body: "§aEarthquake§r §6[§a()§6]§r §uEarth Aura Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §aEarth Rune§r with:\n§d - §uAura Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCreates a lingering earthquake at the target location.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   6 \n§6[§uMana Cost§6: ]   25\n§6[§uCast Time§6:  ]   25",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_earth"
            },
            {
                title: "Back to Start",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_rock_sling"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    //TWILIGHT SPELLS
    //SUBSECTION 3e

    {
        menuID: "pb_scraft:spells_twilight",
        title: "§u§lTwilight Spell List",
        body: "§6Choose a §dSpell§r§6:",
        buttons: [

            {
                title: "Light Arc",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_beam",
                connectID: "pb_scraft:spell_beam"
            },
            {
                title: "Twilight Burst",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_twilight_explosion",
                connectID: "pb_scraft:spell_twilight_explosion"
            },
            {
                title: "Moonbeam",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_spell_moonbeam",
                connectID: "pb_scraft:spell_moonbeam"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Beam / Section 3e.1

    {
        menuID: "pb_scraft:spell_beam",
        title: "§u§lLight Arc",
        body: "§dLight Arc§r §6[§d{}§6]§r §uTwilight Arc Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §dTwilight Rune§r with:\n§d - §uArc Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nCauses an eruption of light and dark energy around the caster.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   8 \n§6[§uMana Cost§6: ]   4\n§6[§uCast Time§6:  ]   30",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_twilight"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_twilight_explosion"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Twilight Explosion / Section 3e.2

    {
        menuID: "pb_scraft:spell_twilight_explosion",
        title: "§u§lTwilight Burst",
        body: "§dTwilight Burst§r §6[§d{}§6]§r §uTwilight Aura Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §dTwilight Rune§r with:\n§d - §uAura Glyph\n§d - §uAmethyst Shard x2\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nFires a continuous light beam.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   8 \n§6[§uMana Cost§6: ]   12\n§6[§uCast Time§6:  ]   5",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_twilight"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_beam"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Moonbeam / Section 3e.3

    {
        menuID: "pb_scraft:spell_moonbeam",
        title: "§u§lMoonbeam",
        body: "§dMoonbeam§r §6[§d{|}§6]§r §uTwilight Arc Spell\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §dLight Arc§r with:\n§d - §uMirror Glyph\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\nRains down light beams in an area.\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§uDamage§6::    ]   6 \n§6[§uMana Cost§6: ]   25\n§6[§uCast Time§6:  ]   35",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:spells_twilight"
            },
            {
                title: "Back to Start",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:spell_twilight_explosion"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // STAFFS
    // MAIN SECTION 4
    // ADDITIONAL SEPERATOR

    {
        menuID: "pb_scraft:staffs",
        title: "§u§lStaffs",
        body: "§6Choose a §uStaff§r§6:",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:content"
            },
            {
                title: "Flamecore Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_fire_staff_1",
                connectID: "pb_scraft:staff_flamecore"
            },
            {
                title: "Phoenix Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_fire_staff_2",
                connectID: "pb_scraft:staff_phoenix"
            },
            {
                title: "Sun Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_fire_staff_3",
                connectID: "pb_scraft:staff_sun"
            },
            {
                title: "Frostcore Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_ice_staff_1",
                connectID: "pb_scraft:staff_frostcore"
            },
            {
                title: "Zephyr Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_ice_staff_2",
                connectID: "pb_scraft:staff_zephyr"
            },
            {
                title: "Vortex Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_ice_staff_3",
                connectID: "pb_scraft:staff_vortex"
            },
            {
                title: "Stormcore Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_air_staff_1",
                connectID: "pb_scraft:staff_stormcore"
            },
            {
                title: "Serpent Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_air_staff_2",
                connectID: "pb_scraft:staff_serpent"
            },
            {
                title: "Tempest Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_air_staff_3",
                connectID: "pb_scraft:staff_tempest"
            },
            {
                title: "Terracore Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_earth_staff_1",
                connectID: "pb_scraft:staff_terracore"
            },
            {
                title: "Crystal Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_earth_staff_2",
                connectID: "pb_scraft:staff_crystal"
            },
            {
                title: "Verdant Gem Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_earth_staff_3",
                connectID: "pb_scraft:staff_verdant_gem"
            },
            {
                title: "Dawncore Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_twilight_staff_1",
                connectID: "pb_scraft:staff_dawncore"
            },
            {
                title: "Eclipse Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_twilight_staff_2",
                connectID: "pb_scraft:staff_eclipse"
            },
            {
                title: "Nemesis Staff",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_twilight_staff_3",
                connectID: "pb_scraft:staff_nemesis"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:content"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Flamecore Staff / Section 4.1

    {
        menuID: "pb_scraft:staff_flamecore",
        title: "§u§LFlamecore Staff",
        body: "§6Lv.1 §6[§c><§6]§r §cFlamecore Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §uStaff Base§r with:\n§d - §uGold Ingot x2\n§d - §uFire Crystal\n§d - §uCoal\n§d - §uFlint\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_phoenix"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Phoenix Staff / Section 4.2

    {
        menuID: "pb_scraft:staff_phoenix",
        title: "§u§lPhoenix Staff",
        body: "§6Lv.2 §6[§c><§6]§r §cPheonix Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §cFlamecore Staff§r with:\n§d - §uFire Rune\n§d - §uCoal\n§d - §uGhast Tear\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_sun"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Sun Staff / Section 4.3

    {
        menuID: "pb_scraft:staff_sun",
        title: "§u§lSun Staff",
        body: "§6Lv.3 §6[§c><§6]§r §cSun Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §cPhoenix Staff§r with:\n§d - §uPentacore Essence\n§d - §uCoal\n§d - §uHoneycomb\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §uPentacore Essence§r can be made at the §6Arcane Altar§r. Check the §uMagic Items§r section for the recipe.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_frostcore"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Frostcore Staff / Section 4.4

    {
        menuID: "pb_scraft:staff_frostcore",
        title: "§u§lFrostcore Staff",
        body: "§6Lv.1 §6[§b<>§6]§r §bFrostcore Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §uStaff Base§r with:\n§d - §uGold Ingot x2\n§d - §uFrost Crystal\n§d - §uLapis Lazulil\n§d - §uPacked Ice\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_zephyr"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Zephyr Staff / Section 4.5

    {
        menuID: "pb_scraft:staff_zephyr",
        title: "§u§lZephyr Staff",
        body: "§6Lv.2 §6[§b<>§6]§r §bZephyr Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bFrostcore Staff§r with:\n§d - §uFrost Rune\n§d - §uLapis Lazulil\n§d - §uPrismarine Crystals\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_vortex"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Vortex Staff / Section 4.6

    {
        menuID: "pb_scraft:staff_vortex",
        title: "Vortex Staff",
        body: "§6Lv.3 §6[§b<>§6]§r §bVortex Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §bZephyr Staff§r with:\n§d - §uPentacore Essence\n§d - §uLapis Lazulil\n§d - §uNautilus Shell\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §uPentacore Essence§r can be made at the §6Arcane Altar§r. Check the §uMagic Items§r section for the recipe.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_stormcore"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Stormcore Staff / Section 4.7

    {
        menuID: "pb_scraft:staff_stormcore",
        title: "§u§lStormcore Staff",
        body: "§6Lv.1 §6[§e)(§6]§r §eStormcore Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §uStaff Base§r with:\n§d - §uGold Ingot x2\n§d - §uStorm Crystal\n§d - §uCopper Ingot\n§d - §uFeather\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_serpent"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Serpent Staff / Section 4.8

    {
        menuID: "pb_scraft:staff_serpent",
        title: "§u§lSerpent Staff",
        body: "§6Lv.2 §6[§e)(§6]§r §eSerpent Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §eStormcore Staff§r with:\n§d - §uStorm Rune\n§d - §uCopper Ingot\n§d - §uGunpowder\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_tempest"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Tempest Staff / Section 4.9

    {
        menuID: "pb_scraft:staff_tempest",
        title: "§u§lTempest Staff",
        body: "§6Lv.3 §6[§e)(§6]§r §eTempest Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §eSerpent Staff§r with:\n§d - §uPentacore Essence\n§d - §uCopper Ingot\n§d - §uShulker Shell\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §uPentacore Essence§r can be made at the §6Arcane Altar§r. Check the §uMagic Items§r section for the recipe.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_terracore"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Terracore Staff / Section 4.10

    {
        menuID: "pb_scraft:staff_terracore",
        title: "§u§lTerracore Staff",
        body: "§6Lv.1 §6[§a()§6]§r §aTerracore Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §uStaff Base§r with:\n§d - §uGold Ingot x2\n§d - §uEarth Crystal\n§d - §uEmerald\n§d - §uStone\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_crystal"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Crystal Staff / Section 4.11

    {
        menuID: "pb_scraft:staff_crystal",
        title: "§u§lCrystal Staff",
        body: "§6Lv.2 §6[§a()§6]§r §aCrystal Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §aTerracore Staff§r with:\n§d - §uEarth Rune\n§d - §uEmerald\n§d - §uMoss Block\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_verdant_gem"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Verdant Gem Staff / Section 4.12

    {
        menuID: "pb_scraft:staff_verdant_gem",
        title: "Verdant Gem Staff",
        body: "§6Lv.3 §6[§a()§6]§r §aVerdant Gem Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §aCrystal Staff§r with:\n§d - §uPentacore Essence\n§d - §uEmerald\n§d - §uPitcher Plant\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §uPentacore Essence§r can be made at the §6Arcane Altar§r. Check the §uMagic Items§r section for the recipe.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_dawncore"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Dawncore Staff / Section 4.13

    {
        menuID: "pb_scraft:staff_dawncore",
        title: "§u§ldawncore Staff",
        body: "§6Lv.1 §6[§d{}§6]§r §dDawncore Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §uStaff Base§r with:\n§d - §uGold Ingot x2\n§d - §uTwilight Crystal\n§d - §uEnder Pearl\n§d - §uSpider Eye\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_eclipse"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Eclipse Staff / Section 4.14

    {
        menuID: "pb_scraft:staff_eclipse",
        title: "§u§lEclipse Staff",
        body: "§6Lv.2 §6[§d{}§6]§r §dEclipse Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §dDawncore Staff§r with:\n§d - §uTwilight Rune\n§d - §uEnder Pearl\n§d - §uHeavy Core\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_nemesis"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Nemesis Staff / Section 4.15

    {
        menuID: "pb_scraft:staff_nemesis",
        title: "§u§lNemesis Staff",
        body: "§6Lv.3 §6[§d{}§6]§r §dNemesis Staff\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §dEclipse Staff§r with:\n§d - §uPentacore Essence\n§d - §uEnder Pearl\n§d - §uDragon's Breath\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r §uPentacore Essence§r can be made at the §6Arcane Altar§r. Check the §uMagic Items§r section for the recipe.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:staffs"
            },
            {
                title: "Back to Start",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:staff_flamecore"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // ARMOR
    // MAIN SECTION 5
    // ADDITIONAL SEPERATOR

    {
        menuID: "pb_scraft:armor",
        title: "§u§LArmor",
        body: "§6Choose an §uArmor Set§r§6:",
        buttons: [
            {
                title: "Dark Mage Set",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_dark_wizard",
                connectID: "pb_scraft:armor_dark_mage"
            },
            {
                title: "High Wizard Set",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_wizard",
                connectID: "pb_scraft:armor_high_wizard"
            },
            {
                title: "Skull Sorcerer Set",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_skull_wizard",
                connectID: "pb_scraft:armor_skull_sorcerer"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:content"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Dark Mage Set / Section 5.1

    {
        menuID: "pb_scraft:armor_dark_mage",
        title: "§u§lDark Mage Set",
        body: "The robes of a common §uDark Mage§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r Requires §uMagic Cloth§r, which can be made at the §6Arcane Altar§r. Check the §6Magic Items§r section for the recipe.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:armor"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:armor_high_wizard"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // High Wizard Set / Section 5.2

    {
        menuID: "pb_scraft:armor_high_wizard",
        title: "§u§lHigh Wizard Set",
        body: "Magically weaved robes of a §uMighty Wizard§r.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r Requires §uMagic Cloth§r, which can be made at the §6Arcane Altar§r. Check the §6Magic Items§r section for the recipe.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:armor"
            },
            {
                title: "Next",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:armor_skull_sorcerer"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Skull Sorcerer Set / Section 5.3

    {
        menuID: "pb_scraft:armor_skull_sorcerer",
        title: "§u§lSkull Sorcerer Set",
        body: "The armor and mask of a §uSkull Sorcerer§r, reinforced by a dark energy.\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r\n§6[§u-§6]§r Requires §uMagic Cloth§r, which can be made at the §6Arcane Altar§r. Check the §6Magic Items§r section for the recipe.",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:armor"
            },
            {
                title: "Back to Start",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_next",
                connectID: "pb_scraft:armor_dark_mage"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // MAGIC ITEMS
    // MAIN SECTION 6
    // ADDITIONAL SEPERATOR SPACE

    {
        menuID: "pb_scraft:items",
        title: "§u§lMagic Items",
        body: "§6Choose a §uMagic Item§r§6:",
        buttons: [
            {
                title: "Magic Cloth",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_magic_cloth",
                connectID: "pb_scraft:magic_cloth"
            },
            {
                title: "Pentacore Essence",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_pentacore_essence",
                connectID: "pb_scraft:pentacore_essence"
            },
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:content"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Magic Cloth / Section 6.1

    {
        menuID: "pb_scraft:magic_cloth",
        title: "§u§lMagic Cloth",
        body: "§6[§u-§6]§r §uMagic Cloth\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §dAmethyst Shard§r with:\n§d - §uString x2\n§d - §uPoppy\n§d - §uDandelion\n§d - §uCornflower\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:items"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // Pentacore Essence / Section 6.2

    {
        menuID: "pb_scraft:pentacore_essence",
        title: "§u§lPentacore Essence",
        body: "§6[§u-§6]§r §uPentacore Essence\n\n§6[§u-§6]§r §6Crafting§r:\nInfuse §dAmethyst Shard§r with:\n§d - §uMagma Cream\n§d - §uGlow Ink Sac\n§d - §uWind Charge\n§d - §uSlime Ball\n§d - §uSculk\n\n§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§u~§d~§r",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:items"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // ABOUT SECTION
    // MAIN SECTION 7
    // JUST THE REST OF IT BABY

    {
        menuID: "pb_scraft:about",
        title: "§l§6[§c><§6] §6[§b<>§6] §6[§e)(§6] §6[§a()§6] §6[§d{}§6]",
        body: "Version: §u1.0.0§r\n\n§6Magic Add-On!§r created by Pixelbiester.§r\n\nFollow us:\n§r§dInstagram§r §o@pixelbiesterofficial§r\n§cYoutube§r §oPixelBiester§r\n§eWebsite§r §opixelbiester.net§r\n§sDiscord§r §opixelbiester.net/discord§r\n\n",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:main"
            }

        ],
        type: "form",
        openOnBlock: [],
        openOnEntity: []
    },

    // CONFIG SECTION
    // MAIN SECTION 8
    // CONFIG STUFF

    {
        menuID: "pb_scraft:config",
        title: "§u§lConfig",
        body: "",
        buttons: [
            {
                title: "Return",
                icon: "textures/pb/scraft/icons/pb_scraft_icon_return",
                connectID: "pb_scraft:main"
            }

        ],
        type: "function",
        openOnBlock: [],
        openOnEntity: []
    },


];

guidebookModule();
interactionModule();

function openMenu(player, menuID) {
    player.playSound(SOUND_TURN_PAGE, SOUND_OPTIONS);

    const menu_data = MENUS.find((f) => f.menuID == menuID);
    if (menu_data == undefined) return;
    //exceptions for functional menus
    if (menu_data.type == "function") {
        if (menu_data.menuID == "pb_scraft:config") configMenu(player);
        return;
    }
    //construct menu from array
    const menu = new ui.ActionFormData();
    menu.title(menu_data.title);
    menu.body(menu_data.body);
    menu_data.buttons.forEach((button) => {
        menu.button(button.title, button.icon);
    });

    menu.show(player).then(result => {
        if (result.canceled) return;

        let response = result.selection;
        openMenu(player, menu_data.buttons[response].connectID);
    });
}

function guidebookModule() {
    //drop guidebook on player first spawn only
    mc.world.afterEvents.playerSpawn.subscribe((eventData) => {
        if (eventData.player.hasTag(GUIDEBOOK_TAG)) { }
        else {
            mc.world.getDimension(eventData.player.dimension.id).spawnItem(new mc.ItemStack(GUIDEBOOK_ITEM, 1), eventData.player.location);
            eventData.player.addTag(GUIDEBOOK_TAG);
        }
    })

    //guidebook entity check
    mc.world.beforeEvents.playerInteractWithEntity.subscribe((eventData) => {
        const player = eventData.player;
        const item = eventData.itemStack;
        const entity = eventData.target;
        if (item == undefined) return;
        if (item.type.id != GUIDEBOOK_ITEM) return;

        let menu;
        MENUS.forEach(menudata => { if (menudata.openOnEntity.includes(entity.typeId)) menu = menudata; });

        if (menu == undefined) return;
        eventData.cancel = true;
        mc.system.runTimeout(() => { openMenu(player, menu.menuID); }, 0)
    });
}
function interactionModule() {
    //guidebook block check
    mc.world.beforeEvents.playerInteractWithBlock.subscribe((eventData) => {
        const player = eventData.player;
        const item = eventData.itemStack;
        const block = eventData.block;
        if (item == undefined) return;
        if (item.type.id != GUIDEBOOK_ITEM) return;

        let menu;
        MENUS.forEach(menudata => { if (menudata.openOnBlock.includes(block.typeId)) menu = menudata; });

        if (menu == undefined) return;
        eventData.cancel = true;
        mc.system.runTimeout(() => { openMenu(player, menu.menuID); }, 0)
    });

    //guidebook activation listener
    mc.world.afterEvents.itemUse.subscribe((eventData) => {
        let player = eventData.source;
        let itemUse = eventData.itemStack;
        if (itemUse === undefined) return;
        if (itemUse.typeId == GUIDEBOOK_ITEM) mc.system.runTimeout(() => { openMenu(player, "pb_scraft:main"); }, 1)
    })
}

//special menus
function configMenu(player) {
    player.playSound(SOUND_TURN_PAGE, SOUND_OPTIONS);

    const MANA_REG = mc.world.scoreboard.getObjective("pb_scraft_settings").getScore("MANA_REG");
    const DMG_SCALING = mc.world.scoreboard.getObjective("pb_scraft_settings").getScore("DMG_SCALING");
    const PVP_SCALING = mc.world.scoreboard.getObjective("pb_scraft_settings").getScore("PVP_SCALING");

    let form = new ui.ModalFormData();
    form.title("§u§lConfig");
    form.slider("§6[§uBase Player Mana Regeneration§6]§r ", 1, 10, 1, MANA_REG);
    form.slider("§6[§uOverall Add-On Damage Scaling§6]§r\n§6[§uPercent§6]§r ", 50, 150, 5, DMG_SCALING);
    form.slider("§6[§uPlayer vs Player Damage Scaling§6]§r\n§o§7Any value above §u0§7 will enable spell effects and damage on players.§r\n§6[§uPercent§6]§r ", 0, 100, 5, PVP_SCALING);
    form.submitButton("Confirm");

    form.show(player).then(result => {
        if (result.canceled) return;

        mc.world.scoreboard.getObjective("pb_scraft_settings").setScore("MANA_REG", result.formValues[0])
        mc.world.scoreboard.getObjective("pb_scraft_settings").setScore("DMG_SCALING", result.formValues[1])
        mc.world.scoreboard.getObjective("pb_scraft_settings").setScore("PVP_SCALING", result.formValues[2])

        config.updateGlobalSettings();
    });
}