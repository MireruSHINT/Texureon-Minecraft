import * as mc from '@minecraft/server';

export const PEDESTAL_ITEMS = [
    "pb_scraft:rune_air",
    "pb_scraft:rune_base",
    "pb_scraft:rune_earth",
    "pb_scraft:rune_fire",
    "pb_scraft:rune_ice",
    "pb_scraft:rune_twilight",

    "pb_scraft:glyph_touch",
    "pb_scraft:glyph_self",
    "pb_scraft:glyph_mirror",
    "pb_scraft:glyph_intensify",
    "pb_scraft:glyph_base",
    "pb_scraft:glyph_aura",
    "pb_scraft:glyph_arc",
    "pb_scraft:glyph_alleviate",
    "pb_scraft:glyph_accelerate",

    "pb_scraft:crystal_twilight",
    "pb_scraft:crystal_ice",
    "pb_scraft:crystal_fire",
    "pb_scraft:crystal_earth",
    "pb_scraft:crystal_air",

    "minecraft:iron_ingot",
    "minecraft:gold_ingot",
    "minecraft:netherite_ingot",
    "minecraft:copper_ingot",

    "pb_scraft:spellorb_fire",
    "pb_scraft:spellorb_ice",
    "pb_scraft:spellorb_air",
    "pb_scraft:spellorb_earth",
    "pb_scraft:spellorb_twilight",
    
    //new additions
    "minecraft:feather",
    "minecraft:amethyst_shard",
    "minecraft:sculk",
    "minecraft:wind_charge",
    "minecraft:magma_cream",
    "minecraft:glow_ink_sac",
    "minecraft:slime_ball",
    "minecraft:shulker_shell",
    "pb_scraft:pentacore_essence",
    "minecraft:gunpowder",
    "minecraft:poppy",
    "minecraft:dandelion",
    "minecraft:cornflower",
    "minecraft:string",
    "minecraft:coal",
    "minecraft:flint",
    "minecraft:ghast_tear",
    "minecraft:honeycomb",
    "minecraft:emerald",
    "minecraft:stone",
    "minecraft:moss_block",
    "minecraft:pitcher_plant",
    "minecraft:lapis_lazuli",
    "minecraft:packed_ice",
    "minecraft:prismarine_crystals",
    "minecraft:nautilus_shell",
    "minecraft:ender_pearl",
    "minecraft:spider_eye",
    "minecraft:heavy_core",
    "minecraft:dragon_breath",

    //for fun
    "pb_scraft:candelabrum",
    "pb_scraft:chandelier",
    "pb_scraft:jar",
    "pb_scraft:magic_cauldron",
    "pb_scraft:mana_meter"
]

//up to 5 pestal items
//recipe triggers when altarItem is interacted with altar
export const ALTAR_RECIPES = [

// STAFF RECIPES

    { // Pentacore Essence
        result: "pb_scraft:pentacore_essence",
        altarItem: "minecraft:amethyst_shard",
        pedestalItems: [
            "minecraft:sculk",
            "minecraft:wind_charge",
            "minecraft:magma_cream",
            "minecraft:glow_ink_sac",
            "minecraft:slime_ball"
        ],
        manacost: 1000,
        castTime: 1,
        type: "generic"
    },
    { // Magic Cloth
        result: "pb_scraft:magic_cloth",
        altarItem: "minecraft:amethyst_shard",
        pedestalItems: [
            "minecraft:string",
            "minecraft:string",
            "minecraft:poppy",
            "minecraft:dandelion",
            "minecraft:cornflower"
        ],
        manacost: 1000,
        castTime: 1,
        type: "generic"
    },
     { // Air 1 -  Stormcore
        result: "pb_scraft:air_staff_1",
        altarItem: "pb_scraft:staff_base",
        pedestalItems: [
            "minecraft:gold_ingot",
            "minecraft:gold_ingot",
            "minecraft:copper_ingot",
            "minecraft:feather",
            "pb_scraft:crystal_air"
        ],
        manacost: 1000,
        castTime: 1,
        type: "generic"
    },
    { // Air 2 -  Serpent
        result: "pb_scraft:air_staff_2",
        altarItem: "pb_scraft:air_staff_1",
        pedestalItems: [
            "minecraft:gunpowder",
            "minecraft:copper_ingot",
            "pb_scraft:rune_air"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { // Air 3 -  Tempest
        result: "pb_scraft:air_staff_3",
        altarItem: "pb_scraft:air_staff_2",
        pedestalItems: [
            "minecraft:shulker_shell",
            "minecraft:copper_ingot",
            "pb_scraft:pentacore_essence",
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { //Fire 1 - Flamecore
        result: "pb_scraft:fire_staff_1",
        altarItem: "pb_scraft:staff_base",
        pedestalItems: [
            "minecraft:gold_ingot",
            "minecraft:gold_ingot",
            "minecraft:coal",
            "minecraft:flint",
            "pb_scraft:crystal_fire"
        ],
        manacost: 1000,
        castTime: 1,
        type: "generic"
    },
    { //Fire 2 - Phoenix
        result: "pb_scraft:fire_staff_2",
        altarItem: "pb_scraft:fire_staff_1",
        pedestalItems: [
            "minecraft:coal",
            "minecraft:ghast_tear",
            "pb_scraft:rune_fire"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { //Fire 3 - Sun
        result: "pb_scraft:fire_staff_3",
        altarItem: "pb_scraft:fire_staff_2",
        pedestalItems: [
            "minecraft:coal",
            "minecraft:honeycomb",
            "pb_scraft:pentacore_essence"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { //Earth 1 - Terracore
        result: "pb_scraft:earth_staff_1",
        altarItem: "pb_scraft:staff_base",
        pedestalItems: [
            "minecraft:iron_ingot",
            "minecraft:iron_ingot",
            "minecraft:emerald",
            "minecraft:stone",
            "pb_scraft:crystal_earth"
        ],
        manacost: 1000,
        castTime: 1,
        type: "generic"
    },
    { //Earth 2 - Crystal
        result: "pb_scraft:earth_staff_2",
        altarItem: "pb_scraft:earth_staff_1",
        pedestalItems: [
            "minecraft:emerald",
            "minecraft:moss_block",
            "pb_scraft:rune_earth"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { //Earth 3 - Verdant Gem
        result: "pb_scraft:earth_staff_3",
        altarItem: "pb_scraft:earth_staff_2",
        pedestalItems: [
            "minecraft:emerald",
            "minecraft:pitcher_plant",
            "pb_scraft:pentacore_essence"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { //Ice 1 - Frostcore
        result: "pb_scraft:ice_staff_1",
        altarItem: "pb_scraft:staff_base",
        pedestalItems: [
            "minecraft:iron_ingot",
            "minecraft:iron_ingot",
            "minecraft:lapis_lazuli",
            "minecraft:packed_ice",
            "pb_scraft:crystal_ice"
        ],
        manacost: 1000,
        castTime: 1,
        type: "generic"
    },
    { //Ice 2 - Zephyr
        result: "pb_scraft:ice_staff_2",
        altarItem: "pb_scraft:ice_staff_1",
        pedestalItems: [
            "minecraft:lapis_lazuli",
            "minecraft:prismarine_crystals",
            "pb_scraft:rune_ice"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { //Ice  3 - Vortex
        result: "pb_scraft:ice_staff_3",
        altarItem: "pb_scraft:ice_staff_2",
        pedestalItems: [
            "minecraft:lapis_lazuli",
            "minecraft:nautilus_shell",
            "pb_scraft:pentacore_essence"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { //Twilight 1 - Dawncore
        result: "pb_scraft:twilight_staff_1",
        altarItem: "pb_scraft:staff_base",
        pedestalItems: [
            "minecraft:gold_ingot",
            "minecraft:gold_ingot",
            "minecraft:ender_pearl",
            "minecraft:spider_eye",
            "pb_scraft:crystal_twilight"
        ],
        manacost: 1000,
        castTime: 1,
        type: "generic"
    },
    { //Twilight 2 - Eclipse
        result: "pb_scraft:twilight_staff_2",
        altarItem: "pb_scraft:twilight_staff_1",
        pedestalItems: [
            "minecraft:ender_pearl",
            "minecraft:heavy_core",
            "pb_scraft:rune_twilight"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },
    { //Twilight  3 - Nemesis
        result: "pb_scraft:twilight_staff_3",
        altarItem: "pb_scraft:twilight_staff_2",
        pedestalItems: [
            "minecraft:ender_pearl",
            "minecraft:dragon_breath",
            "pb_scraft:pentacore_essence"
        ],
        manacost: 1000,
        castTime: 1,
        type: "staffup"
    },

// Spells --FIRE--

    { // Fireball
        result: "pb_scraft:spellorb_fire",
        altarItem: "pb_scraft:rune_fire",
        pedestalItems: [
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard",
            "pb_scraft:glyph_arc"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:fireball",
        type: "spell"
    },
    { // Pyroball
        result: "pb_scraft:spellorb_fire",
        altarItem: "pb_scraft:rune_fire",
        pedestalItems: [
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard",
            "pb_scraft:glyph_touch"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:pyroball",
        type: "spell"
    },
    { // Firebolt
        result: "pb_scraft:spellorb_fire",
        altarItem: "pb_scraft:spellorb_fire",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:fireball",
        spell_result: "pb_scraft:firebolt",
        type: "mirror"
    },
    { // Fiery Spin
        result: "pb_scraft:spellorb_fire",
        altarItem: "pb_scraft:rune_fire",
        pedestalItems: [
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard",
            "pb_scraft:glyph_aura"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:aura_fire",
        type: "spell"
    },
    { // Fire Tornado
        result: "pb_scraft:spellorb_fire",
        altarItem: "pb_scraft:spellorb_fire",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:aura_fire",
        spell_result: "pb_scraft:tornado_fire",
        type: "mirror"
    },
    { // Comet
        result: "pb_scraft:spellorb_fire",
        altarItem: "pb_scraft:spellorb_fire",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:pyroball",
        spell_result: "pb_scraft:comet",
        type: "mirror"
    },

    //Spells --Ice--

    { // Freeze
        result: "pb_scraft:spellorb_ice",
        altarItem: "pb_scraft:rune_ice",
        pedestalItems: [
            "pb_scraft:glyph_touch",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:freeze",
        type: "spell"
    },
    { // Ice Spike
        result: "pb_scraft:spellorb_ice",
        altarItem: "pb_scraft:rune_ice",
        pedestalItems: [
            "pb_scraft:glyph_arc",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:ice_spike",
        type: "spell"
    },
    { // Ice Pillar
        result: "pb_scraft:spellorb_ice",
        altarItem: "pb_scraft:rune_ice",
        pedestalItems: [
            "pb_scraft:glyph_self",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:ice_pillar",
        type: "spell"
    },
    { // Ice Wall
        result: "pb_scraft:spellorb_ice",
        altarItem: "pb_scraft:spellorb_ice",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:ice_pillar",
        spell_result: "pb_scraft:ice_wall",
        type: "mirror"
    },
    { // Frost Aura
        result: "pb_scraft:spellorb_ice",
        altarItem: "pb_scraft:rune_ice",
        pedestalItems: [
            "pb_scraft:glyph_aura",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:aura_frost",
        type: "spell"
    },
    { // Healing Aura
        result: "pb_scraft:spellorb_ice",
        altarItem: "pb_scraft:spellorb_ice",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:aura_frost",
        spell_result: "pb_scraft:aura_heal",
        type: "mirror"
    },
    { // Healing Area
        result: "pb_scraft:spellorb_ice",
        altarItem: "pb_scraft:spellorb_ice",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:freeze",
        spell_result: "pb_scraft:area_heal",
        type: "mirror"
    },

    //spells --Air--

    { // Air Tornado
        result: "pb_scraft:spellorb_air",
        altarItem: "pb_scraft:rune_air",
        pedestalItems: [
            "pb_scraft:glyph_aura",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:tornado_air",
        type: "spell"
    },
    { // Wind Sickle
        result: "pb_scraft:spellorb_air",
        altarItem: "pb_scraft:rune_air",
        pedestalItems: [
            "pb_scraft:glyph_arc",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:windsickle",
        type: "spell"
    },
    { // Lightning
        result: "pb_scraft:spellorb_air",
        altarItem: "pb_scraft:spellorb_air",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:wind_sickle",
        spell_result: "pb_scraft:lightning",
        type: "mirror"
    },
    { // Upwind
        result: "pb_scraft:spellorb_air",
        altarItem: "pb_scraft:rune_air",
        pedestalItems: [
            "pb_scraft:glyph_self",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:upwind",
        type: "spell"
    },
    { // Flash
        result: "pb_scraft:spellorb_air",
        altarItem: "pb_scraft:spellorb_air",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:upwind",
        spell_result: "pb_scraft:flash",
        type: "spell"
    },

    //spells --Earth--

    { // Rock Sling
        result: "pb_scraft:spellorb_earth",
        altarItem: "pb_scraft:rune_earth",
        pedestalItems: [
            "pb_scraft:glyph_arc",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:rock_sling",
        type: "spell"
    },

    //spells --Twilight--

    { // Beam
        result: "pb_scraft:spellorb_twilight",
        altarItem: "pb_scraft:rune_twilight",
        pedestalItems: [
            "pb_scraft:glyph_arc",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:light_arc",
        type: "spell"
    },
    { // Twilight Explosion
        result: "pb_scraft:spellorb_twilight",
        altarItem: "pb_scraft:rune_twilight",
        pedestalItems: [
            "pb_scraft:glyph_aura",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:twilight_explosion",
        type: "spell"
    },
    { // Moonbeam
        result: "pb_scraft:spellorb_twilight",
        altarItem: "pb_scraft:spellorb_twilight",
        pedestalItems: [
            "pb_scraft:glyph_mirror"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:light_arc",
        spell_result: "pb_scraft:moonbeam",
        type: "mirror"
    },
    { // Earthquake
        result: "pb_scraft:spellorb_earth",
        altarItem: "pb_scraft:rune_earth",
        pedestalItems: [
            "pb_scraft:glyph_aura",
            "minecraft:amethyst_shard",
            "minecraft:amethyst_shard"
        ],
        manacost: 1000,
        castTime: 1,
        spell_base: "pb_scraft:empty",
        spell_result: "pb_scraft:earthquake",
        type: "spell"
    },

    //orb recipes to tune spells
    {
        result: "pb_scraft:spellorb_air",
        altarItem: "pb_scraft:spellorb_twilight",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "spellmod"
    },
    {
        result: "pb_scraft:spellorb_fire",
        altarItem: "pb_scraft:spellorb_twilight",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "spellmod"
    },
    {
        result: "pb_scraft:spellorb_ice",
        altarItem: "pb_scraft:spellorb_twilight",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "spellmod"
    },
    {
        result: "pb_scraft:spellorb_earth",
        altarItem: "pb_scraft:spellorb_twilight",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "spellmod"
    },
    {
        result: "pb_scraft:spellorb_twilight",
        altarItem: "pb_scraft:spellorb_twilight",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "spellmod"
    },

    //staff recipes to apply spells
    {
        result: "pb_scraft:air_staff_1",
        altarItem: "pb_scraft:air_staff_1",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:air_staff_2",
        altarItem: "pb_scraft:air_staff_2",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:air_staff_3",
        altarItem: "pb_scraft:air_staff_3",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:fire_staff_1",
        altarItem: "pb_scraft:fire_staff_1",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:fire_staff_2",
        altarItem: "pb_scraft:fire_staff_2",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:fire_staff_3",
        altarItem: "pb_scraft:fire_staff_3",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:earth_staff_1",
        altarItem: "pb_scraft:earth_staff_1",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:earth_staff_2",
        altarItem: "pb_scraft:earth_staff_2",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:earth_staff_3",
        altarItem: "pb_scraft:earth_staff_3",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:ice_staff_1",
        altarItem: "pb_scraft:ice_staff_1",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:ice_staff_2",
        altarItem: "pb_scraft:ice_staff_2",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:ice_staff_3",
        altarItem: "pb_scraft:ice_staff_3",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:twilight_staff_1",
        altarItem: "pb_scraft:twilight_staff_1",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:twilight_staff_2",
        altarItem: "pb_scraft:twilight_staff_2",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    },
    {
        result: "pb_scraft:twilight_staff_3",
        altarItem: "pb_scraft:twilight_staff_3",
        pedestalItems: [],
        manacost: 1000,
        castTime: 1,
        type: "apply"
    }
]